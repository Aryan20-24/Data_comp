# Databricks notebook source
# DBTITLE 1,Intelligent Chunking for RAG
# MAGIC %md
# MAGIC # SamarthVaani - Intelligent Chunking Pipeline
# MAGIC
# MAGIC **Goal**: Split documents into optimal chunks for Vector Search and RAG
# MAGIC
# MAGIC ## Why Chunking Matters for RAG
# MAGIC * **Too large**: Irrelevant info dilutes context, LLM gets confused
# MAGIC * **Too small**: Loses context, incomplete information
# MAGIC * **Optimal**: 300-500 words with context preservation
# MAGIC
# MAGIC ## Our Chunking Strategy
# MAGIC 1. **Semantic Splitting**: Split on paragraphs, then sentences
# MAGIC 2. **Size Control**: Target 300-500 words per chunk
# MAGIC 3. **Context Preservation**: Add section titles as metadata
# MAGIC 4. **Overlap**: 50-word overlap between chunks to preserve context
# MAGIC 5. **Topic Tagging**: Auto-detect topics (education, employment, etc.)
# MAGIC
# MAGIC ## What This Notebook Does
# MAGIC 1. Reads from `bronze.raw_documents`
# MAGIC 2. Splits text into chunks
# MAGIC 3. Adds metadata (topic, section, source)
# MAGIC 4. Stores in `silver.document_chunks`
# MAGIC 5. Promotes to `gold.rpwd_chunks_enriched` for Vector Search

# COMMAND ----------

# DBTITLE 1,Import Libraries
from pyspark.sql.functions import col, udf, explode, array, struct, lit
from pyspark.sql.types import ArrayType, StructType, StructField, StringType, IntegerType
import uuid
import re

print("✅ Libraries imported")

# COMMAND ----------

# DBTITLE 1,Define Chunking Functions
def intelligent_chunk(text, target_words=400, overlap_words=50):
    """
    Split text into chunks of approximately target_words with overlap.
    Preserves sentence boundaries.
    
    Args:
        text: Input text to chunk
        target_words: Target words per chunk (default 400)
        overlap_words: Overlap between chunks (default 50)
    
    Returns:
        List of text chunks
    """
    if not text or len(text.strip()) == 0:
        return []
    
    # Split into sentences (simple approach)
    sentences = re.split(r'(?<=[.!?])\s+', text)
    
    chunks = []
    current_chunk = []
    current_word_count = 0
    
    for sentence in sentences:
        sentence_words = len(sentence.split())
        
        # If adding this sentence exceeds target, finalize current chunk
        if current_word_count + sentence_words > target_words and current_chunk:
            chunks.append(' '.join(current_chunk))
            
            # Keep last few sentences for overlap
            overlap_sentences = []
            overlap_count = 0
            for s in reversed(current_chunk):
                s_words = len(s.split())
                if overlap_count + s_words <= overlap_words:
                    overlap_sentences.insert(0, s)
                    overlap_count += s_words
                else:
                    break
            
            current_chunk = overlap_sentences
            current_word_count = overlap_count
        
        current_chunk.append(sentence)
        current_word_count += sentence_words
    
    # Add final chunk
    if current_chunk:
        chunks.append(' '.join(current_chunk))
    
    return chunks

# Test the function
test_text = "This is sentence one. This is sentence two. This is sentence three. " * 50
test_chunks = intelligent_chunk(test_text, target_words=100, overlap_words=20)
print(f"✅ Chunking function defined")
print(f"   Test: {len(test_text.split())} words → {len(test_chunks)} chunks")

# COMMAND ----------

# DBTITLE 1,Define Topic Detection Function
def detect_topic(text):
    """
    Detect topic/category from text using keyword matching.
    Useful for metadata filtering in Vector Search.
    
    Returns: topic string or 'general'
    """
    text_lower = text.lower()
    
    # Education keywords
    if any(kw in text_lower for kw in ['education', 'school', 'student', 'children', 'learning', 'teacher']):
        return 'education'
    
    # Employment keywords
    elif any(kw in text_lower for kw in ['employment', 'job', 'work', 'employer', 'career', 'occupation']):
        return 'employment'
    
    # Reservation keywords
    elif any(kw in text_lower for kw in ['reservation', 'quota', 'seat', 'post', 'vacancy']):
        return 'reservation'
    
    # Certification keywords
    elif any(kw in text_lower for kw in ['certificate', 'udid', 'disability certificate', 'assessment']):
        return 'certification'
    
    # Healthcare keywords
    elif any(kw in text_lower for kw in ['health', 'medical', 'treatment', 'hospital', 'rehab']):
        return 'healthcare'
    
    # Rights keywords
    elif any(kw in text_lower for kw in ['right', 'act', 'law', 'provision', 'section']):
        return 'rights'
    
    # Schemes/Benefits keywords
    elif any(kw in text_lower for kw in ['scheme', 'benefit', 'pension', 'allowance', 'grant']):
        return 'schemes'
    
    else:
        return 'general'

print("✅ Topic detection function defined")

# COMMAND ----------

# DBTITLE 1,Read Raw Documents from Bronze
# Read all documents from bronze table
raw_docs_df = spark.table("samarthvaani.bronze.raw_documents")

doc_count = raw_docs_df.count()
print(f"📂 Found {doc_count} documents in bronze.raw_documents")

if doc_count > 0:
    print("\n👀 Document Summary:")
    display(raw_docs_df.select("doc_id", "filename", "doc_type", "page_count").limit(10))
else:
    print("⚠️ No documents found! Run Notebook 02_PDF_Ingestion first.")

# COMMAND ----------

# DBTITLE 1,Process Documents and Create Chunks
from pyspark.sql.functions import pandas_udf, PandasUDFType
import pandas as pd

# Register chunking function as UDF
def chunk_document_row(doc_id, doc_type, filename, raw_text):
    """
    Process a single document row and return chunks.
    """
    if not raw_text:
        return []
    
    # Create chunks
    chunks = intelligent_chunk(raw_text, target_words=400, overlap_words=50)
    
    results = []
    for idx, chunk_text in enumerate(chunks):
        chunk_id = f"{doc_id}_{idx}"
        word_count = len(chunk_text.split())
        topic = detect_topic(chunk_text)
        
        # Extract section title (first line or first 100 chars)
        section_title = chunk_text.split('\n')[0][:100] if '\n' in chunk_text else chunk_text[:100]
        
        results.append({
            'chunk_id': chunk_id,
            'doc_id': doc_id,
            'chunk_index': idx,
            'chunk_text': chunk_text,
            'word_count': word_count,
            'section_title': section_title,
            'topic': topic,
            'source_doc': filename,
            'doc_type': doc_type
        })
    
    return results

# Process all documents
all_chunks = []

for row in raw_docs_df.collect():
    doc_chunks = chunk_document_row(
        row['doc_id'],
        row['doc_type'],
        row['filename'],
        row['raw_text']
    )
    all_chunks.extend(doc_chunks)

print(f"✅ Generated {len(all_chunks)} chunks from {doc_count} documents")
print(f"   Average: {len(all_chunks) / max(doc_count, 1):.1f} chunks per document")

# COMMAND ----------

# DBTITLE 1,Save Chunks to Silver Table
if len(all_chunks) > 0:
    from pyspark.sql.types import StructType, StructField, StringType, IntegerType
    
    schema = StructType([
        StructField("chunk_id", StringType(), False),
        StructField("doc_id", StringType(), False),
        StructField("chunk_index", IntegerType(), False),
        StructField("chunk_text", StringType(), False),
        StructField("word_count", IntegerType(), True),
        StructField("section_title", StringType(), True),
        StructField("topic", StringType(), True),
        StructField("source_doc", StringType(), True),
        StructField("doc_type", StringType(), True)
    ])
    
    chunks_df = spark.createDataFrame(all_chunks, schema=schema)
    
    # Write to Silver table
    chunks_df.write \
        .format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .saveAsTable("samarthvaani.silver.document_chunks")
    
    print(f"✅ Saved {len(all_chunks)} chunks to silver.document_chunks")
    
    # Show sample
    print("\n👀 Sample chunks:")
    display(chunks_df.select("chunk_id", "topic", "word_count", "section_title").limit(10))
else:
    print("⚠️ No chunks created!")

# COMMAND ----------

# DBTITLE 1,Promote to Gold Table for Vector Search
# Read silver chunks
silver_chunks = spark.table("samarthvaani.silver.document_chunks")

# Select and rename columns for gold table (Vector Search compatible)
gold_chunks = silver_chunks.select(
    col("chunk_id"),
    col("chunk_text"),
    col("section_title"),
    col("topic"),
    col("source_doc").alias("source"),
    col("doc_type"),
    col("word_count")
)

# Write to gold table (CDF already enabled)
gold_chunks.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("samarthvaani.gold.rpwd_chunks_enriched")

print("✅ Promoted chunks to gold.rpwd_chunks_enriched")
print("   → Ready for Vector Search Delta Sync Index")

# Show sample
print("\n👀 Gold table sample:")
display(spark.table("samarthvaani.gold.rpwd_chunks_enriched").limit(5))

# COMMAND ----------

# DBTITLE 1,Analysis and Summary
print("=" * 80)
print("✅ CHUNKING COMPLETE")
print("=" * 80)

# Total chunks
total_chunks = spark.table("samarthvaani.gold.rpwd_chunks_enriched").count()
print(f"\n📊 Total Chunks: {total_chunks}")

# Topic breakdown
print("\n📊 Topic Distribution:")
topic_dist = spark.table("samarthvaani.gold.rpwd_chunks_enriched") \
    .groupBy("topic") \
    .count() \
    .orderBy("count", ascending=False)
display(topic_dist)

# Word count statistics
print("\n📊 Word Count Statistics:")
word_stats = spark.table("samarthvaani.gold.rpwd_chunks_enriched") \
    .selectExpr(
        "min(word_count) as min_words",
        "max(word_count) as max_words",
        "avg(word_count) as avg_words"
    )
display(word_stats)

# Sample chunk text
print("\n📝 Sample Chunk (first 500 chars):")
sample = spark.table("samarthvaani.gold.rpwd_chunks_enriched").first()
if sample:
    print(f"Topic: {sample['topic']}")
    print(f"Words: {sample['word_count']}")
    print(f"Text: {sample['chunk_text'][:500]}...")

print("\n" + "=" * 80)
print("🚀 NEXT STEP: Run Notebook 04_Vector_Search_Setup")
print("=" * 80)