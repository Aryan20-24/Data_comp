# Quick Start Demo - Notebook Cells

Copy and paste these cells into the `Quick_Start_Demo` notebook in order.

---

## CELL 1: Title (Markdown)

```markdown
%md
# 🚀 Quick Start Demo - Integrated Voice RAG Pipeline

**Welcome!** This notebook will help you get started with the voice-enabled multilingual RAG pipeline in just a few minutes.

## What You'll Learn

1. ✅ Validate your setup
2. 🔧 Load the RAG pipeline
3. 💬 Run text-to-text examples
4. 🎤 Run text-to-voice examples
5. 🧪 Use the interactive test script

---

## Prerequisites

Before running this notebook:
- ✅ API keys configured in `sarvam_code/.env`
- ✅ Notebooks 01-04 completed (Unity Catalog + Vector Search)
- ✅ Vector index created: `samarthvaani.gold.rpwd_chunks_index`

---

**⚡ Ready? Let's go! Run each cell in order.**
```

---

## CELL 2: Setup Paths (Python)

```python
# Setup paths and imports
import sys
import os

# Add parent directory to path
parent_dir = '/Users/am1221830@iitd.ac.in'
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

print("✅ Path configured")
print(f"   Parent directory: {parent_dir}")
```

---

## CELL 3: Quick Validation (Python)

```python
# Quick validation check
print("=" * 80)
print("🔍 QUICK VALIDATION CHECK")
print("=" * 80)
print()

# Check sarvam_code
try:
    from sarvam_code import process_input, process_output
    from sarvam_code.config import SUPPORTED_LANGUAGES, SARVAM_STT_API_KEY, SARVAM_TTS_API_KEY
    print("✅ sarvam_code module - Available")
    print(f"   Supported languages: {len(SUPPORTED_LANGUAGES)}")
    
    # Check API keys
    api_keys_ok = bool(SARVAM_STT_API_KEY and SARVAM_TTS_API_KEY)
    if api_keys_ok:
        print("✅ API keys - Configured")
    else:
        print("⚠️  API keys - Not configured (see setup instructions)")
        
except ImportError as e:
    print(f"❌ sarvam_code module - Not available: {e}")
    print("   Check that sarvam_code folder exists")

# Check Vector Search
try:
    from databricks.vector_search.client import VectorSearchClient
    vsc = VectorSearchClient(disable_notice=True)
    print("✅ Vector Search - Available")
except Exception as e:
    print(f"⚠️  Vector Search - Error: {e}")

print()
print("=" * 80)
print("📋 If all checks pass, continue to next cell!")
print("   If any failed, see 00_Setup_Validation notebook")
print("=" * 80)
```

---

## CELL 4: Load RAG Pipeline (Markdown + Python)

```markdown
%md
## Step 1: Load RAG Pipeline

Loading the complete RAG pipeline from notebook 05...
```

```python
# Load the RAG pipeline from notebook 05
print("📥 Loading RAG pipeline from notebook 05...")
print("   This may take a few seconds...")
print()

%run ../05_Complete_RAG_Pipeline

print()
print("=" * 80)
print("✅ RAG PIPELINE LOADED")
print("=" * 80)
print()
print("Available functions:")
print("  • retrieve_context()")
print("  • build_rag_prompt()")
print("  • generate_answer()")
print("  • rag_pipeline()")
print()
```

---

## CELL 5: Load Integrated Pipeline (Python)

```python
# Load integrated pipeline functions
print("=" * 80)
print("🔧 LOADING INTEGRATED PIPELINE")
print("=" * 80)
print()

from final_work.integrated_pipeline import (
    voice_rag_query,
    load_rag_pipeline,
    format_result,
    save_audio
)

# Connect to RAG pipeline
load_rag_pipeline()

print()
print("=" * 80)
print("✅ INTEGRATED PIPELINE READY")
print("=" * 80)
print()
print("Available function:")
print("  • voice_rag_query() - Complete pipeline orchestrator")
print()
print("You can now run queries in any supported language!")
print()
```

---

## CELL 6: Example 1 - Hindi Text to English Text (Markdown + Python)

```markdown
%md
## 📝 Example 1: Text → Text (Hindi → English)

Let's test a simple text query in Hindi and get an English response.
```

```python
print("=" * 80)
print("🧪 EXAMPLE 1: Hindi Text → English Text")
print("=" * 80)
print()

# Query in Hindi about education rights
query_hindi = "विकलांग बच्चों के लिए शिक्षा अधिकार क्या हैं?"

print(f"📝 Input Query (Hindi):")
print(f"   {query_hindi}")
print()
print("⏳ Processing... (this takes ~4-6 seconds)")
print()

result = voice_rag_query(
    user_input=query_hindi,
    input_mode="text",
    input_lang="hi-IN",
    output_mode="text",
    output_lang="en-IN",
    top_k=3,
    verbose=False
)

print("=" * 80)
print("✅ RESULT")
print("=" * 80)
print()
print(f"📝 English Query (translated):")
print(f"   {result['query_english']}")
print()
print(f"💬 Answer:")
print(f"   {result['answer']}")
print()
print(f"⏱️  Total time: {result['latency']['total']:.2f}s")
print()
```

---

## CELL 7: Example 2 - Tamil Text to Telugu Text (Markdown + Python)

```markdown
%md
## 📝 Example 2: Cross-Language Text (Tamil → Telugu)

Testing translation between two Indian languages.
```

```python
print("=" * 80)
print("🧪 EXAMPLE 2: Tamil Text → Telugu Text")
print("=" * 80)
print()

# Query in Tamil about employment schemes
query_tamil = "மாற்றுத்திறனாளிகளுக்கான வேலைவாய்ப்பு திட்டங்கள் என்ன?"

print(f"📝 Input Query (Tamil):")
print(f"   {query_tamil}")
print()
print("⏳ Processing...")
print()

result = voice_rag_query(
    user_input=query_tamil,
    input_mode="text",
    input_lang="ta-IN",
    output_mode="text",
    output_lang="te-IN",
    top_k=3,
    verbose=False
)

print("=" * 80)
print("✅ RESULT")
print("=" * 80)
print()
print(f"📝 English Query (intermediate):")
print(f"   {result['query_english']}")
print()
print(f"💬 Answer (Telugu):")
print(f"   {result['answer']}")
print()
print(f"⏱️  Latency Breakdown:")
print(f"   Input processing:  {result['latency']['input_processing']:.2f}s")
print(f"   RAG pipeline:      {result['latency']['rag_pipeline']:.2f}s")
print(f"   Output processing: {result['latency']['output_processing']:.2f}s")
print(f"   Total:             {result['latency']['total']:.2f}s")
print()
```

---

## CELL 8: Example 3 - English Text to Hindi Voice (Markdown + Python)

```markdown
%md
## 🔊 Example 3: Text → Voice (English → Hindi Voice)

Generating voice output in Hindi from an English text query.
```

```python
print("=" * 80)
print("🧪 EXAMPLE 3: English Text → Hindi Voice")
print("=" * 80)
print()

# Query in English
query_english = "What are the disability benefits available under RPWD Act?"

print(f"📝 Input Query (English):")
print(f"   {query_english}")
print()
print("⏳ Processing... (voice generation takes ~6-8 seconds)")
print()

result = voice_rag_query(
    user_input=query_english,
    input_mode="text",
    input_lang="en-IN",
    output_mode="voice",
    output_lang="hi-IN",
    top_k=3,
    verbose=False
)

print("=" * 80)
print("✅ RESULT")
print("=" * 80)
print()
print(f"💬 Answer (Hindi text):")
print(f"   {result['answer'][:200]}...")
print()

# Save audio
if result['audio']:
    output_file = "example_hindi_output.wav"
    save_audio(result['audio'], output_file)
    print(f"🔊 Audio size: {len(result['audio'])} bytes")
    print(f"📁 Audio file: {output_file}")
else:
    print("⚠️  No audio generated (check API keys)")

print()
print(f"⏱️  Total time: {result['latency']['total']:.2f}s")
print()
```

---

## CELL 9: Interactive Test Script (Markdown + Python)

```markdown
%md
## 🎮 Interactive Testing

Ready to test with your own queries? Run the interactive test script!

The script provides:
- ✅ Interactive language selection
- ✅ All 4 modes (text→text, text→voice, voice→text, voice→voice)
- ✅ Safety guardrails
- ✅ Audio file support
```

```python
# Run the interactive test script
print("=" * 80)
print("🎮 STARTING INTERACTIVE TEST SCRIPT")
print("=" * 80)
print()
print("The script will guide you through:")
print("  1. Selecting input/output modes")
print("  2. Choosing languages")
print("  3. Entering your query")
print("  4. Viewing results")
print()
print("Press Ctrl+C to exit the script at any time.")
print()

%run ./demo_test.py
```

---

## CELL 10: Next Steps (Markdown)

```markdown
%md
## 🎉 Congratulations!

You've successfully run the integrated voice RAG pipeline!

---

## 📚 What's Next?

### 1. Explore More Features

**Full Documentation:**
- Read: `final_work/README.md`
- Complete API reference
- All parameters explained

**Validation Notebook:**
- Run: `00_Setup_Validation.ipynb`
- Comprehensive system checks
- Troubleshooting guide

### 2. Test Different Scenarios

**All 4 Modes:**
1. ✅ Text → Text (done in examples above)
2. ✅ Text → Voice (done in examples above)
3. 🎤 Voice → Text (requires audio file)
4. 🎤 Voice → Voice (requires audio file)

**11 Supported Languages:**
- English, Hindi, Tamil, Telugu, Marathi
- Bengali, Kannada, Malayalam, Gujarati
- Punjabi, Odia

### 3. Advanced Usage

**Programmatic Usage:**
```python
from final_work.integrated_pipeline import voice_rag_query

result = voice_rag_query(
    user_input="your query here",
    input_mode="text",
    input_lang="hi-IN",
    output_mode="voice",
    output_lang="ta-IN",
    top_k=5,
    topic_filter="education",
    fast_mode=True,
    verbose=True
)
```

**Voice Input Example:**
```python
# Load audio file
with open("question.wav", "rb") as f:
    audio_bytes = f.read()

result = voice_rag_query(
    user_input=audio_bytes,
    input_mode="voice",
    input_lang="hi-IN",
    output_mode="voice",
    output_lang="ta-IN"
)

# Save response audio
with open("answer.wav", "wb") as f:
    f.write(result["audio"])
```

---

## 🔧 Troubleshooting

**Common Issues:**

1. **API Keys Not Working**
   - Check `sarvam_code/.env` file
   - Ensure keys are valid (not placeholders)
   - Restart kernel after changing keys

2. **Vector Search Errors**
   - Run notebook `04_Vector_Search_Setup`
   - Check index exists: `samarthvaani.gold.rpwd_chunks_index`
   - Verify endpoint is online

3. **Translation Slow (First Time)**
   - IndicTrans2 downloads models (~2GB each)
   - Only happens once, then cached
   - Be patient on first run

4. **Voice Generation Fails**
   - Check Sarvam TTS API key
   - Verify language is supported
   - Check network connectivity

---

## 📞 Support

For more help:
- Review: `00_Setup_Validation.ipynb`
- Check: `final_work/README.md`
- See: Troubleshooting section in README

---

**🎤 Happy Querying! Enjoy your multilingual voice-enabled RAG system!**
```

---

## 🎯 Summary

This Quick Start Demo includes:

1. ✅ **Setup validation** - Check all components
2. ✅ **RAG pipeline loading** - Import existing functions
3. ✅ **3 Working examples** - Text-to-text and text-to-voice
4. ✅ **Interactive testing** - Full demo script
5. ✅ **Complete documentation** - Next steps and troubleshooting

Copy each cell above into your `Quick_Start_Demo` notebook in order and run!
