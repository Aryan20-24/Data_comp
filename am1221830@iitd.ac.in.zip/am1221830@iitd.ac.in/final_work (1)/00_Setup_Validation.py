# Databricks notebook source
# DBTITLE 1,Validation Overview
# MAGIC %md
# MAGIC # 🔍 Integrated Voice RAG Pipeline - Setup Validation
# MAGIC
# MAGIC **Purpose**: Validate that all components are properly configured before using the integrated pipeline.
# MAGIC
# MAGIC ## What This Notebook Checks:
# MAGIC
# MAGIC 1. ✅ **Python Dependencies** - Required packages installed
# MAGIC 2. ✅ **sarvam_code Module** - Voice & translation components available
# MAGIC 3. ✅ **API Keys** - Sarvam API keys configured
# MAGIC 4. ✅ **Supported Languages** - Multilingual support ready
# MAGIC 5. ✅ **Vector Search** - RAG database connectivity
# MAGIC 6. ✅ **LLM Access** - Foundation Model API available
# MAGIC 7. ✅ **IndicTrans2** - Translation models ready
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **Run all cells in order** to validate your setup. Each section will show ✅ (pass) or ❌ (fail) with helpful messages.
# MAGIC
# MAGIC If any checks fail, see the **Troubleshooting** section at the end.

# COMMAND ----------

# DBTITLE 1,Check 1: Python Dependencies
# MAGIC %md
# MAGIC ## 1. Python Dependencies
# MAGIC
# MAGIC Checking if all required Python packages are installed...

# COMMAND ----------

# DBTITLE 1,Check Required Packages
import sys

print("=" * 80)
print("1. CHECKING PYTHON DEPENDENCIES")
print("=" * 80)
print()

required_packages = [
    ("databricks", "Databricks SDK"),
    ("openai", "OpenAI client"),
    ("transformers", "HuggingFace Transformers"),
    ("torch", "PyTorch"),
    ("sentencepiece", "SentencePiece tokenizer"),
    ("requests", "HTTP requests"),
]

missing_packages = []
passed = 0
total = len(required_packages)

for package, description in required_packages:
    try:
        __import__(package)
        print(f"✅ {package:20s} - {description}")
        passed += 1
    except ImportError:
        print(f"❌ {package:20s} - NOT INSTALLED")
        missing_packages.append(package)

print()
print(f"Result: {passed}/{total} packages available")

if missing_packages:
    print("\n⚠️  Missing packages - Install with:")
    print(f"   %pip install {' '.join(missing_packages)}")
    print("   Then restart the kernel: dbutils.library.restartPython()")
else:
    print("\n🎉 All required packages are installed!")

# COMMAND ----------

# DBTITLE 1,Check 2: sarvam_code Module
# MAGIC %md
# MAGIC ## 2. sarvam_code Module
# MAGIC
# MAGIC Checking if the voice and translation module is available...

# COMMAND ----------

# DBTITLE 1,Check sarvam_code Availability
import sys
import os

print("=" * 80)
print("2. CHECKING SARVAM_CODE MODULE")
print("=" * 80)
print()

# Add parent directory to path
parent_dir = '/Users/am1221830@iitd.ac.in'
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
    print(f"📁 Added to path: {parent_dir}")
    print()

# Try importing sarvam_code components
try:
    from sarvam_code import process_input, process_output
    print("✅ sarvam_code.process_input - Input processor imported")
    print("✅ sarvam_code.process_output - Output processor imported")
    
    from sarvam_code.config import (
        SUPPORTED_LANGUAGES,
        SARVAM_STT_API_KEY,
        SARVAM_TTS_API_KEY,
        INDICTRANS2_LANG_MAP
    )
    print("✅ sarvam_code.config - Configuration imported")
    
    from sarvam_code.stt import speech_to_text
    print("✅ sarvam_code.stt - Speech-to-Text imported")
    
    from sarvam_code.tts import text_to_speech
    print("✅ sarvam_code.tts - Text-to-Speech imported")
    
    from sarvam_code.translate import translate
    print("✅ sarvam_code.translate - Translation imported")
    
    print("\n🎉 sarvam_code module is fully available!")
    sarvam_code_available = True
    
except ImportError as e:
    print(f"❌ sarvam_code import failed: {e}")
    print("\n⚠️  Make sure:")
    print("   1. sarvam_code/ folder exists at: /Users/am1221830@iitd.ac.in/sarvam_code")
    print("   2. All files are present (stt.py, tts.py, translate.py, etc.)")
    print("   3. __init__.py exports process_input and process_output")
    sarvam_code_available = False

# COMMAND ----------

# DBTITLE 1,Check 3: API Keys Configuration
# MAGIC %md
# MAGIC ## 3. API Keys Configuration
# MAGIC
# MAGIC Checking if Sarvam AI API keys are properly configured...

# COMMAND ----------

# DBTITLE 1,Validate API Keys
print("=" * 80)
print("3. CHECKING API KEYS CONFIGURATION")
print("=" * 80)
print()

if sarvam_code_available:
    # Check STT API Key
    stt_configured = bool(
        SARVAM_STT_API_KEY and 
        SARVAM_STT_API_KEY.strip() and 
        "your_" not in SARVAM_STT_API_KEY.lower() and
        len(SARVAM_STT_API_KEY) > 10
    )
    
    if stt_configured:
        print(f"✅ SARVAM_STT_API_KEY - Configured ({len(SARVAM_STT_API_KEY)} chars)")
    else:
        print("❌ SARVAM_STT_API_KEY - Not configured or placeholder")
    
    # Check TTS API Key
    tts_configured = bool(
        SARVAM_TTS_API_KEY and 
        SARVAM_TTS_API_KEY.strip() and 
        "your_" not in SARVAM_TTS_API_KEY.lower() and
        len(SARVAM_TTS_API_KEY) > 10
    )
    
    if tts_configured:
        print(f"✅ SARVAM_TTS_API_KEY - Configured ({len(SARVAM_TTS_API_KEY)} chars)")
    else:
        print("❌ SARVAM_TTS_API_KEY - Not configured or placeholder")
    
    if stt_configured and tts_configured:
        print("\n🎉 All API keys are properly configured!")
    else:
        print("\n⚠️  Configure API keys:")
        print("   1. Copy template: cp final_work/.env.template ../sarvam_code/.env")
        print("   2. Edit: ../sarvam_code/.env")
        print("   3. Add your actual Sarvam API keys")
        print("   4. Restart kernel: dbutils.library.restartPython()")
        
else:
    print("❌ Cannot check API keys - sarvam_code not available")
    stt_configured = False
    tts_configured = False

# COMMAND ----------

# DBTITLE 1,Check 4: Supported Languages
# MAGIC %md
# MAGIC ## 4. Supported Languages
# MAGIC
# MAGIC Checking available languages for voice and text processing...

# COMMAND ----------

# DBTITLE 1,Display Supported Languages
print("=" * 80)
print("4. SUPPORTED LANGUAGES")
print("=" * 80)
print()

if sarvam_code_available:
    num_languages = len(SUPPORTED_LANGUAGES)
    print(f"✅ {num_languages} languages supported\n")
    
    print("Available Languages:")
    print("-" * 80)
    for code, name in sorted(SUPPORTED_LANGUAGES.items(), key=lambda x: x[1]):
        indictrans_code = INDICTRANS2_LANG_MAP.get(code, "N/A")
        print(f"  • {name:15s} | Sarvam: {code:8s} | IndicTrans2: {indictrans_code}")
    
    print("\n🎉 Multilingual support ready!")
    print(f"\nYou can use any of these {num_languages} languages for:")
    print("  • Text input → Text output")
    print("  • Text input → Voice output")
    print("  • Voice input → Text output")
    print("  • Voice input → Voice output")
    
else:
    print("❌ Cannot check languages - sarvam_code not available")

# COMMAND ----------

# DBTITLE 1,Check 5: Vector Search
# MAGIC %md
# MAGIC ## 5. Vector Search Connectivity
# MAGIC
# MAGIC Checking connection to Databricks Vector Search for RAG...

# COMMAND ----------

# DBTITLE 1,Test Vector Search
print("=" * 80)
print("5. CHECKING VECTOR SEARCH CONNECTIVITY")
print("=" * 80)
print()

try:
    from databricks.vector_search.client import VectorSearchClient
    print("✅ VectorSearchClient imported")
    
    vsc = VectorSearchClient(disable_notice=True)
    print("✅ VectorSearchClient initialized")
    
    # List endpoints
    try:
        endpoints = vsc.list_endpoints()
        print(f"✅ List endpoints successful - Found {len(endpoints)} endpoint(s)")
        
        # Check for our specific endpoint
        endpoint_name = "samarthvaani_vs_endpoint"
        endpoint_found = any(ep.get('name') == endpoint_name for ep in endpoints)
        
        if endpoint_found:
            print(f"✅ Endpoint '{endpoint_name}' - Found")
            
            # Try to access the index
            try:
                index_name = "samarthvaani.gold.rpwd_chunks_index"
                index = vsc.get_index(
                    endpoint_name=endpoint_name,
                    index_name=index_name
                )
                print(f"✅ Index '{index_name}' - Accessible")
                
                # Get index details if available
                try:
                    describe = index.describe()
                    status = describe.get('status', {}).get('state', 'UNKNOWN')
                    print(f"   Status: {status}")
                    if 'index_type' in describe:
                        print(f"   Type: {describe['index_type']}")
                except:
                    pass
                
                print("\n🎉 Vector Search is fully operational!")
                vector_search_ok = True
                
            except Exception as e:
                print(f"❌ Index access failed: {e}")
                print("\n⚠️  Make sure notebook 04_Vector_Search_Setup was run successfully")
                vector_search_ok = False
        else:
            print(f"❌ Endpoint '{endpoint_name}' - Not found")
            print("\n⚠️  Available endpoints:")
            for ep in endpoints:
                print(f"   • {ep.get('name')}")
            vector_search_ok = False
            
    except Exception as e:
        print(f"❌ List endpoints failed: {e}")
        vector_search_ok = False
        
except ImportError:
    print("❌ databricks-vectorsearch package not installed")
    print("\n⚠️  Install with:")
    print("   %pip install databricks-vectorsearch")
    vector_search_ok = False
except Exception as e:
    print(f"❌ Vector Search error: {e}")
    vector_search_ok = False

# COMMAND ----------

# DBTITLE 1,Check 6: LLM Access
# MAGIC %md
# MAGIC ## 6. LLM Access (Foundation Model API)
# MAGIC
# MAGIC Checking access to Databricks Foundation Models for answer generation...

# COMMAND ----------

# DBTITLE 1,Test LLM Access
print("=" * 80)
print("6. CHECKING LLM ACCESS")
print("=" * 80)
print()

try:
    from openai import OpenAI
    print("✅ OpenAI client library imported")
    
    # Try to get Databricks token
    try:
        token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
        print("✅ Databricks authentication token retrieved")
        
        # Try to create OpenAI client
        # Note: This doesn't make an actual API call, just creates the client
        print("✅ Ready to call Foundation Model API")
        print("   Model: databricks-meta-llama-3-3-70b-instruct")
        
        print("\n🎉 LLM access is configured!")
        print("\n   Note: Actual LLM functionality will be tested when running")
        print("   the RAG pipeline in notebook 05_Complete_RAG_Pipeline")
        
        llm_ok = True
        
    except Exception as e:
        print(f"❌ Token retrieval failed: {e}")
        llm_ok = False
        
except ImportError:
    print("❌ openai package not installed")
    print("\n⚠️  Install with:")
    print("   %pip install openai")
    llm_ok = False
except Exception as e:
    print(f"❌ LLM access error: {e}")
    llm_ok = False

# COMMAND ----------

# DBTITLE 1,Check 7: IndicTrans2 Models
# MAGIC %md
# MAGIC ## 7. IndicTrans2 Translation Models
# MAGIC
# MAGIC Checking translation model availability (used for multilingual support)...

# COMMAND ----------

# DBTITLE 1,Verify Translation Models
print("=" * 80)
print("7. CHECKING INDICTRANS2 TRANSLATION MODELS")
print("=" * 80)
print()

if sarvam_code_available:
    try:
        from sarvam_code.translate import translate
        print("✅ Translation function imported")
        
        print("\n   Note: IndicTrans2 models (~2GB each) will be downloaded")
        print("   on first use. This is normal and happens only once.")
        print("\n   Translation models support:")
        print("   • English ↔ All Indian languages")
        print("   • Indian language ↔ Indian language (via English pivot)")
        print("\n   Models are cached locally for fast subsequent use.")
        
        print("\n🎉 Translation is ready!")
        print("\n   Will be tested with actual text in the demo notebook.")
        
        translation_ok = True
        
    except Exception as e:
        print(f"❌ Translation module error: {e}")
        translation_ok = False
else:
    print("❌ Cannot check translation - sarvam_code not available")
    translation_ok = False

# COMMAND ----------

# DBTITLE 1,Validation Summary
# MAGIC %md
# MAGIC ## 📊 Validation Summary
# MAGIC
# MAGIC Overall status of all validation checks...

# COMMAND ----------

# DBTITLE 1,Display Validation Summary
print("=" * 80)
print("VALIDATION SUMMARY")
print("=" * 80)
print()

# Collect all check results
checks = {
    "Python Dependencies": passed == total if 'passed' in locals() else False,
    "sarvam_code Module": sarvam_code_available if 'sarvam_code_available' in locals() else False,
    "API Keys (STT)": stt_configured if 'stt_configured' in locals() else False,
    "API Keys (TTS)": tts_configured if 'tts_configured' in locals() else False,
    "Supported Languages": sarvam_code_available and num_languages > 0 if 'num_languages' in locals() else False,
    "Vector Search": vector_search_ok if 'vector_search_ok' in locals() else False,
    "LLM Access": llm_ok if 'llm_ok' in locals() else False,
    "Translation (IndicTrans2)": translation_ok if 'translation_ok' in locals() else False,
}

passed_checks = sum(1 for v in checks.values() if v)
total_checks = len(checks)

print(f"Passed: {passed_checks}/{total_checks} checks\n")

for check_name, status in checks.items():
    status_icon = "✅" if status else "❌"
    print(f"{status_icon} {check_name}")

print("\n" + "=" * 80)

if passed_checks == total_checks:
    print("\n🎉 ALL CHECKS PASSED!")
    print("\nYou are ready to use the Integrated Voice RAG Pipeline.")
    print("\nNext steps:")
    print("  1. Open: 01_Integrated_Voice_RAG_Demo.ipynb")
    print("  2. Run the demo examples")
    print("  3. Try your own queries!")
else:
    print("\n⚠️  SOME CHECKS FAILED")
    print("\nPlease review the failed checks above and follow the")
    print("troubleshooting instructions in each section.")
    print("\nSee the 'Troubleshooting' section below for common issues.")

print("\n" + "=" * 80)

# COMMAND ----------

# DBTITLE 1,Troubleshooting Guide
# MAGIC %md
# MAGIC ## 🔧 Troubleshooting Common Issues
# MAGIC
# MAGIC ### ❌ sarvam_code module not found
# MAGIC
# MAGIC **Solution:**
# MAGIC 1. Verify the folder exists:
# MAGIC    ```
# MAGIC    /Users/am1221830@iitd.ac.in/sarvam_code/
# MAGIC    ```
# MAGIC 2. Check that all files are present:
# MAGIC    - `__init__.py` (exports process_input, process_output)
# MAGIC    - `input_processor.py`
# MAGIC    - `output_processor.py`
# MAGIC    - `stt.py`
# MAGIC    - `tts.py`
# MAGIC    - `translate.py`
# MAGIC    - `config.py`
# MAGIC 3. Restart the kernel: `dbutils.library.restartPython()`
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### ❌ API Keys not configured
# MAGIC
# MAGIC **Solution:**
# MAGIC 1. Copy the template:
# MAGIC    ```bash
# MAGIC    cp final_work/.env.template ../sarvam_code/.env
# MAGIC    ```
# MAGIC 2. Edit `../sarvam_code/.env` with actual keys:
# MAGIC    ```
# MAGIC    SARVAM_STT_API_KEY=your_actual_saarika_key_here
# MAGIC    SARVAM_TTS_API_KEY=your_actual_bulbul_key_here
# MAGIC    ```
# MAGIC 3. Restart kernel: `dbutils.library.restartPython()`
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### ❌ Vector Search endpoint/index not found
# MAGIC
# MAGIC **Solution:**
# MAGIC 1. Run the Vector Search setup notebook:
# MAGIC    ```
# MAGIC    04_Vector_Search_Setup.ipynb
# MAGIC    ```
# MAGIC 2. Verify the endpoint name matches: `samarthvaani_vs_endpoint`
# MAGIC 3. Verify the index name matches: `samarthvaani.gold.rpwd_chunks_index`
# MAGIC 4. Check index status in Databricks UI → Compute → Vector Search
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### ❌ Python packages missing
# MAGIC
# MAGIC **Solution:**
# MAGIC ```python
# MAGIC %pip install databricks-vectorsearch openai transformers torch sentencepiece
# MAGIC dbutils.library.restartPython()
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### ⚠️ IndicTrans2 models slow on first use
# MAGIC
# MAGIC **This is normal!**
# MAGIC - Models (~2GB each) download on first translation
# MAGIC - Takes 5-10 minutes initially
# MAGIC - Cached for fast subsequent use
# MAGIC - No action needed
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 📞 Still Having Issues?
# MAGIC
# MAGIC 1. Re-run all cells in this validation notebook
# MAGIC 2. Check the error messages carefully
# MAGIC 3. Review the README.md in final_work/ folder
# MAGIC 4. Ensure you have proper Databricks workspace permissions

# COMMAND ----------

# DBTITLE 1,Next Steps
# MAGIC %md
# MAGIC ## ✅ Next Steps
# MAGIC
# MAGIC If validation passed, you're ready to use the integrated pipeline!
# MAGIC
# MAGIC ### 1. Test the Demo Notebook
# MAGIC
# MAGIC Open and run:
# MAGIC ```
# MAGIC 01_Integrated_Voice_RAG_Demo.ipynb
# MAGIC ```
# MAGIC
# MAGIC This notebook shows:
# MAGIC - Text → Text examples (cross-language)
# MAGIC - Text → Voice examples
# MAGIC - Voice → Text examples (when you have audio)
# MAGIC - Voice → Voice examples
# MAGIC
# MAGIC ### 2. Use in Your Own Code
# MAGIC
# MAGIC ```python
# MAGIC from integrated_pipeline import voice_rag_query, load_rag_pipeline
# MAGIC
# MAGIC # Load RAG functions
# MAGIC %run ../05_Complete_RAG_Pipeline
# MAGIC load_rag_pipeline()
# MAGIC
# MAGIC # Query the pipeline
# MAGIC result = voice_rag_query(
# MAGIC     user_input="विकलांग बच्चों के अधिकार क्या हैं?",
# MAGIC     input_mode="text",
# MAGIC     input_lang="hi-IN",
# MAGIC     output_mode="voice",
# MAGIC     output_lang="ta-IN"
# MAGIC )
# MAGIC
# MAGIC print(result["answer"])
# MAGIC ```
# MAGIC
# MAGIC ### 3. Read the Documentation
# MAGIC
# MAGIC See `final_work/README.md` for:
# MAGIC - Complete API reference
# MAGIC - All parameters explained
# MAGIC - More examples
# MAGIC - Performance tips
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **🎉 Happy querying!**