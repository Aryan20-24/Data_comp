# Integrated Voice-Enabled Multilingual RAG Pipeline

**SamarthVaani** - Accessible Information System for Disability Rights and Schemes

This pipeline provides voice and text-based question answering in 11 Indian languages using Retrieval-Augmented Generation (RAG).

---

## 🎯 What This Does

Takes user queries in **any supported language** (text or voice) and returns answers from the RPWD Act knowledge base in **any supported language** (text or voice).

### Supported Modes

| Input | Output | Example |
|-------|--------|---------|
| Text | Text | Hindi text question → Telugu text answer |
| Text | Voice | Tamil text question → Hindi voice answer |
| Voice | Text | Bengali voice question → English text answer |
| Voice | Voice | Gujarati voice question → Marathi voice answer |

### Supported Languages (11)

* English (en-IN)
* Hindi (hi-IN)
* Tamil (ta-IN)
* Telugu (te-IN)
* Marathi (mr-IN)
* Bengali (bn-IN)
* Kannada (kn-IN)
* Malayalam (ml-IN)
* Gujarati (gu-IN)
* Punjabi (pa-IN)
* Odia (od-IN)

---

## 🏗️ Architecture

```
User Input (Voice/Text, Any Language)
        ↓
[sarvam_code] Input Processor
        ├── Speech-to-Text (Sarvam Saarika)
        └── Translation (IndicTrans2)
        ↓
    English Text
        ↓
[RAG Pipeline] English → English
        ├── Vector Search (1,190 chunks)
        ├── Context Retrieval
        └── LLM Generation (Llama 3.3 70B)
        ↓
    English Answer
        ↓
[sarvam_code] Output Processor
        ├── Translation (IndicTrans2)
        └── Text-to-Speech (Sarvam Bulbul)
        ↓
User Output (Voice/Text, Any Language)
```

---

## 📁 File Structure

```
final_work/
├── .env.template                       # API keys template
├── config.py                           # Configuration (imports from sarvam_code)
├── validate_setup.py                   # Validation script
├── integrated_pipeline.py              # Main orchestrator
├── 00_Setup_Validation.ipynb           # Interactive validation
├── 01_Integrated_Voice_RAG_Demo.ipynb  # Full demo with examples
└── README.md                           # This file
```

---

## 🚀 Quick Start

### Step 1: Configure API Keys

1. Copy the template:
   ```bash
   cp .env.template ../sarvam_code/.env
   ```

2. Edit `../sarvam_code/.env` with your actual API keys:
   ```bash
   SARVAM_STT_API_KEY=your_actual_saarika_key
   SARVAM_TTS_API_KEY=your_actual_bulbul_key
   ```

### Step 2: Validate Setup

Run the validation script:
```python
%run ./validate_setup.py
```

Or open the interactive notebook:
```
00_Setup_Validation.ipynb
```

### Step 3: Run Demo

Open and run:
```
01_Integrated_Voice_RAG_Demo.ipynb
```

---

## 💻 Usage

### Basic Usage

```python
# Import the pipeline
from integrated_pipeline import voice_rag_query, load_rag_pipeline

# Load RAG functions (run this after %run ../05_Complete_RAG_Pipeline)
load_rag_pipeline()

# Query the pipeline
result = voice_rag_query(
    user_input="विकलांग बच्चों के अधिकार क्या हैं?",
    input_mode="text",
    input_lang="hi-IN",
    output_mode="text",
    output_lang="en-IN",
    top_k=3
)

print(result["answer"])
```

### All Parameters

```python
result = voice_rag_query(
    user_input="...",           # Text string OR audio bytes
    input_mode="text",          # "text" or "voice"
    input_lang="hi-IN",         # Language code
    output_mode="text",         # "text" or "voice"
    output_lang="en-IN",        # Language code
    fast_mode=True,             # Fast STT (True) or Accurate (False)
    top_k=3,                    # Number of chunks to retrieve
    topic_filter=None,          # Optional: "education", "employment", etc.
    verbose=True,               # Print progress
    return_metadata=True        # Include latency info
)
```

### Result Structure

```python
{
    "answer": "...",                    # Final answer in output language
    "audio": b"..." or None,            # Audio bytes (if output_mode="voice")
    "query_original": "...",            # Original query (text inputs)
    "query_english": "...",             # English translation
    "answer_english": "...",            # English answer from RAG
    "input_mode": "text",
    "output_mode": "voice",
    "input_lang": "hi-IN",
    "output_lang": "ta-IN",
    "latency": {
        "input_processing": 1.234,
        "rag_pipeline": 2.345,
        "output_processing": 1.456,
        "total": 5.035
    },
    "config": {
        "top_k": 3,
        "topic_filter": None,
        "fast_mode": True
    }
}
```

---

## 📋 Examples

### Example 1: Text → Text (Hindi → English)

```python
result = voice_rag_query(
    user_input="विकलांग बच्चों के शिक्षा अधिकार क्या हैं?",
    input_mode="text",
    input_lang="hi-IN",
    output_mode="text",
    output_lang="en-IN"
)

print(result["answer"])
# Output: "Under RPWD Act 2016, children with disabilities have the right..."
```

### Example 2: Text → Voice (Tamil → Telugu Voice)

```python
result = voice_rag_query(
    user_input="மாற்றுத்திறனாளிகளுக்கான திட்டங்கள் என்ன?",
    input_mode="text",
    input_lang="ta-IN",
    output_mode="voice",
    output_lang="te-IN"
)

# Save audio
with open("answer.wav", "wb") as f:
    f.write(result["audio"])
```

### Example 3: Voice → Text (Bengali Voice → Gujarati Text)

```python
# Load audio file
with open("bengali_question.wav", "rb") as f:
    audio_bytes = f.read()

result = voice_rag_query(
    user_input=audio_bytes,
    input_mode="voice",
    input_lang="bn-IN",
    output_mode="text",
    output_lang="gu-IN",
    fast_mode=True
)

print(result["answer"])
```

### Example 4: Voice → Voice (Marathi → Hindi)

```python
with open("marathi_question.wav", "rb") as f:
    audio_bytes = f.read()

result = voice_rag_query(
    user_input=audio_bytes,
    input_mode="voice",
    input_lang="mr-IN",
    output_mode="voice",
    output_lang="hi-IN"
)

# Save response audio
with open("hindi_answer.wav", "wb") as f:
    f.write(result["audio"])
```

---

## ⚙️ Configuration

### Fast Mode vs Accurate Mode (Voice Input Only)

**Fast Mode (`fast_mode=True`)** - Default
* Sarvam Saarika directly translates speech → English
* Latency: ~2-3 seconds
* Best for: Real-time conversations

**Accurate Mode (`fast_mode=False`)**
* Sarvam Saarika transcribes → native language
* IndicTrans2 translates → English
* Latency: ~4-5 seconds
* Best for: Critical queries, legal compliance

### Topic Filtering

Filter retrieved documents by topic:

```python
result = voice_rag_query(
    user_input="employment schemes?",
    topic_filter="employment"  # or "education", "healthcare", etc.
)
```

---

## 🔧 Components Used

### From `sarvam_code/` (Multilingual + Voice)
* `input_processor.py` - Converts any input → English text
* `output_processor.py` - Converts English → any output
* `stt.py` - Sarvam Saarika API wrapper
* `tts.py` - Sarvam Bulbul API wrapper
* `translate.py` - IndicTrans2 wrapper
* `config.py` - Configuration

### From RAG Notebooks (English Only)
* `05_Complete_RAG_Pipeline` - Vector Search + LLM
* Vector Search Index: `samarthvaani.gold.rpwd_chunks_index`
* LLM: Meta Llama 3.3 70B Instruct

### This Package
* `integrated_pipeline.py` - Orchestrator connecting both

---

## 🧪 Testing

### Validate Setup

```python
%run ./validate_setup.py
```

Checks:
* ✅ Python dependencies
* ✅ sarvam_code availability
* ✅ API keys configured
* ✅ Vector Search connectivity
* ✅ LLM access
* ✅ IndicTrans2 models

### Test Individual Components

See notebook: `00_Setup_Validation.ipynb`

---

## 📊 Performance

Typical latencies (on standard cluster):

| Stage | Fast Mode | Accurate Mode |
|-------|-----------|---------------|
| Input Processing | 1-2s | 3-4s |
| RAG Pipeline | 2-3s | 2-3s |
| Output Processing | 1-2s | 1-2s |
| **Total** | **4-7s** | **6-9s** |

Voice processing adds ~1-3s compared to text-only.

---

## 🚨 Troubleshooting

### "sarvam_code module not found"
* Ensure `sarvam_code/` folder exists in parent directory
* Check path: `/Users/am1221830@iitd.ac.in/sarvam_code/`

### "SARVAM_STT_API_KEY not configured"
* Copy `.env.template` to `../sarvam_code/.env`
* Add your actual API keys
* Restart Python kernel

### "RAG pipeline not loaded"
* Run `%run ../05_Complete_RAG_Pipeline` first
* Then call `load_rag_pipeline()`

### "Vector Search index not found"
* Ensure notebook `04_Vector_Search_Setup` was run
* Check index exists: `samarthvaani.gold.rpwd_chunks_index`

### Translation is slow (first time)
* IndicTrans2 downloads models (~2GB each) on first use
* This is normal and only happens once
* Models are cached for subsequent use

---

## 📚 Documentation

* **Architecture**: See diagram in main README
* **API Reference**: See docstrings in `integrated_pipeline.py`
* **Examples**: See `01_Integrated_Voice_RAG_Demo.ipynb`

---

## 🎓 Citation

If you use this pipeline in your research or project:

```
SamarthVaani - Integrated Voice-Enabled Multilingual RAG Pipeline
Disability Rights Information System using Databricks, Sarvam AI, and IndicTrans2
```

---

## 📞 Support

For issues or questions:
1. Run validation script: `validate_setup.py`
2. Check troubleshooting section above
3. Review notebook: `00_Setup_Validation.ipynb`

---

## 🔄 Version

**v1.0.0** - Initial release

### Features
* ✅ 11 Indian languages + English
* ✅ Voice input/output support
* ✅ Text input/output support
* ✅ Cross-language translation
* ✅ Fast and accurate modes
* ✅ Topic filtering
* ✅ Metadata and latency tracking

---

## 📝 License

This project uses:
* Databricks Foundation Models (Meta Llama 3.3 70B)
* Sarvam AI APIs (Saarika, Bulbul)
* IndicTrans2 (AI4Bharat)

Ensure you have appropriate licenses/subscriptions for production use.

---

**Built with ❤️ for accessible information access**
