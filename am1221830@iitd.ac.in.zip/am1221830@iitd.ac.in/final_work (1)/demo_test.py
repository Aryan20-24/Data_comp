"""
Demo Test Script for Integrated Voice RAG Pipeline

This script demonstrates the complete voice-enabled multilingual RAG pipeline
with safety guardrails and interactive testing.

Usage:
    python demo_test.py

Or in Databricks notebook:
    %run ./demo_test.py
"""

import os
import sys
from pathlib import Path

# Add parent directory to path
parent_dir = '/Users/am1221830@iitd.ac.in'
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import the integrated pipeline
try:
    from final_work.integrated_pipeline import voice_rag_query, load_rag_pipeline, format_result, save_audio
    PIPELINE_AVAILABLE = True
except ImportError as e:
    print(f"⚠️  Warning: Could not import integrated_pipeline: {e}")
    PIPELINE_AVAILABLE = False

# Import sarvam_code for direct testing
try:
    from sarvam_code import process_input, process_output
    from sarvam_code.config import SUPPORTED_LANGUAGES
    SARVAM_AVAILABLE = True
except ImportError as e:
    print(f"⚠️  Warning: Could not import sarvam_code: {e}")
    SARVAM_AVAILABLE = False


# =============================================================================
# GUARDRAILS & CONFIGURATION
# =============================================================================

MAX_TEXT_LENGTH = 500
MAX_AUDIO_FILE_MB = 5
SAVE_AUDIO_OUTPUT = True
ALLOW_REAL_API_CALLS = True  # Set False for dry-run mode

# Language code mapping (short code -> Sarvam format)
LANGUAGE_MAP = {
    "en": "en-IN",
    "hi": "hi-IN",
    "ta": "ta-IN",
    "te": "te-IN",
    "mr": "mr-IN",
    "bn": "bn-IN",
    "kn": "kn-IN",
    "ml": "ml-IN",
    "gu": "gu-IN",
    "pa": "pa-IN",
    "od": "od-IN",
}


# =============================================================================
# USER INPUT HELPERS
# =============================================================================

def ask_choice(prompt, valid_choices):
    """Ask user to choose from valid options."""
    while True:
        value = input(prompt).strip().lower()
        if value in valid_choices:
            return value
        print(f"❌ Invalid choice. Allowed values: {', '.join(valid_choices)}")


def ask_bool(prompt):
    """Ask user for boolean input."""
    while True:
        value = input(prompt).strip().lower()
        if value in {"true", "t", "yes", "y", "1"}:
            return True
        if value in {"false", "f", "no", "n", "0"}:
            return False
        print("❌ Invalid input. Enter True/False or Yes/No.")


def ask_language(prompt):
    """Ask user to select a language."""
    print("\n📋 Available languages:")
    print("-" * 50)
    for code, full_code in sorted(LANGUAGE_MAP.items()):
        if SARVAM_AVAILABLE and full_code in SUPPORTED_LANGUAGES:
            lang_name = SUPPORTED_LANGUAGES[full_code]
            print(f"  {code:3s} → {lang_name:15s} ({full_code})")
        else:
            print(f"  {code:3s} → {full_code}")
    print("-" * 50)
    
    while True:
        code = input(prompt).strip().lower()
        if code in LANGUAGE_MAP:
            return LANGUAGE_MAP[code]
        print("❌ Invalid language code. Please try again.")


def ask_int(prompt, min_val=1, max_val=10):
    """Ask user for integer input within range."""
    while True:
        try:
            value = int(input(prompt).strip())
            if min_val <= value <= max_val:
                return value
            print(f"❌ Value must be between {min_val} and {max_val}")
        except ValueError:
            print("❌ Please enter a valid number")


# =============================================================================
# VALIDATION HELPERS
# =============================================================================

def validate_text(text):
    """Validate text input."""
    if not text.strip():
        raise ValueError("Text input cannot be empty.")
    if len(text) > MAX_TEXT_LENGTH:
        raise ValueError(
            f"Text too long ({len(text)} chars). Max allowed is {MAX_TEXT_LENGTH}."
        )
    return text.strip()


def validate_audio_file(audio_path):
    """Validate audio file exists and is within size limit."""
    path = Path(audio_path)
    
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")
    
    size_bytes = path.stat().st_size
    size_mb = size_bytes / (1024 * 1024)
    
    if size_mb > MAX_AUDIO_FILE_MB:
        raise ValueError(
            f"Audio file too large ({size_mb:.2f} MB). "
            f"Max allowed is {MAX_AUDIO_FILE_MB} MB."
        )
    
    print(f"✅ Audio file validated: {size_mb:.2f} MB")
    return path


def load_audio_file(audio_path):
    """Load audio file as bytes."""
    path = validate_audio_file(audio_path)
    with open(path, "rb") as f:
        return f.read()


# =============================================================================
# FAKE RAG FOR DRY RUN MODE
# =============================================================================

def fake_rag_pipeline(english_query: str) -> str:
    """Simulate RAG pipeline for testing without actual API calls."""
    return (
        f"[DRY RUN MODE] This is a simulated RAG response. "
        f"In production, this would query the vector database and LLM. "
        f"Your query was: '{english_query[:100]}...'"
    )


# =============================================================================
# MAIN TEST FUNCTIONS
# =============================================================================

def confirm_run_summary(input_mode, fast_mode, input_lang, output_lang, output_mode, top_k):
    """Display run configuration and ask for confirmation."""
    print("\n" + "=" * 70)
    print("📋 RUN CONFIGURATION SUMMARY")
    print("=" * 70)
    print(f"  Input Mode          : {input_mode}")
    print(f"  Input Language      : {input_lang}")
    print(f"  Fast Mode (voice)   : {fast_mode}")
    print(f"  Output Mode         : {output_mode}")
    print(f"  Output Language     : {output_lang}")
    print(f"  RAG Top-K Chunks    : {top_k}")
    print(f"  Real API Calls      : {ALLOW_REAL_API_CALLS}")
    print(f"  Max Text Length     : {MAX_TEXT_LENGTH}")
    print(f"  Max Audio Size      : {MAX_AUDIO_FILE_MB} MB")
    print("=" * 70)
    
    return ask_bool("\n✅ Proceed with this configuration? (yes/no): ")


def test_mode_full_pipeline():
    """Test the complete integrated pipeline (MODE 1)."""
    print("\n" + "=" * 70)
    print("🚀 MODE 1: FULL INTEGRATED PIPELINE TEST")
    print("=" * 70)
    
    if not PIPELINE_AVAILABLE:
        print("❌ Integrated pipeline not available. Check imports.")
        return
    
    try:
        # Check if RAG pipeline is loaded
        from final_work.integrated_pipeline import _rag_pipeline_loaded
        if not _rag_pipeline_loaded:
            print("\n⚠️  RAG pipeline not loaded.")
            print("   Please run this from a notebook after: %run ../05_Complete_RAG_Pipeline")
            print("   Then call: load_rag_pipeline()")
            return
        
        # Get configuration from user
        input_mode = ask_choice("\n📥 Input mode (text/voice): ", {"text", "voice"})
        input_lang = ask_language("📥 Input language: ")
        fast_mode = ask_bool("⚡ Fast mode for voice input? (yes/no): ") if input_mode == "voice" else True
        output_mode = ask_choice("📤 Output mode (text/voice): ", {"text", "voice"})
        output_lang = ask_language("📤 Output language: ")
        top_k = ask_int("🔍 Number of chunks to retrieve (1-10): ", 1, 10)
        
        # Confirm configuration
        if not confirm_run_summary(input_mode, fast_mode, input_lang, output_lang, output_mode, top_k):
            print("\n❌ Test cancelled by user.")
            return
        
        # Collect input
        print("\n" + "-" * 70)
        print("📥 INPUT COLLECTION")
        print("-" * 70)
        
        if input_mode == "text":
            user_input = input("\n💬 Enter your text query: ").strip()
            validate_text(user_input)
            print(f"✅ Text input received: {len(user_input)} characters")
        else:
            audio_path = input("\n🎤 Enter path to audio file (e.g., question.wav): ").strip()
            user_input = load_audio_file(audio_path)
            print(f"✅ Audio input loaded: {len(user_input)} bytes")
        
        # Run the pipeline
        print("\n" + "-" * 70)
        print("⚙️  PROCESSING PIPELINE")
        print("-" * 70)
        print("\nStep 1: Input Processing (Speech/Translation → English)")
        print("Step 2: RAG Pipeline (Vector Search + LLM)")
        print("Step 3: Output Processing (Translation/Speech)")
        print("\n⏳ Running... (this may take 5-10 seconds)\n")
        
        result = voice_rag_query(
            user_input=user_input,
            input_mode=input_mode,
            input_lang=input_lang,
            output_mode=output_mode,
            output_lang=output_lang,
            fast_mode=fast_mode,
            top_k=top_k,
            verbose=True,
            return_metadata=True
        )
        
        # Display results
        print("\n" + "=" * 70)
        print("✅ PIPELINE COMPLETED SUCCESSFULLY")
        print("=" * 70)
        
        print(format_result(result, show_metadata=True))
        
        # Save audio if available
        if result.get("audio") and SAVE_AUDIO_OUTPUT:
            output_file = "test_output_full.wav"
            save_audio(result["audio"], output_file)
            print(f"\n🔊 Audio saved to: {os.path.abspath(output_file)}")
        
        print("\n✅ Full pipeline test completed successfully!")
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Test interrupted by user.")
    except Exception as e:
        print(f"\n\n❌ ERROR: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()


def test_mode_components_only():
    """Test only input/output processing without RAG (MODE 2)."""
    print("\n" + "=" * 70)
    print("🧪 MODE 2: COMPONENT TESTING (Input/Output Only)")
    print("=" * 70)
    
    if not SARVAM_AVAILABLE:
        print("❌ sarvam_code not available. Check imports.")
        return
    
    try:
        # Get configuration
        input_mode = ask_choice("\n📥 Input mode (text/voice): ", {"text", "voice"})
        input_lang = ask_language("📥 Input language: ")
        fast_mode = ask_bool("⚡ Fast mode for voice input? (yes/no): ") if input_mode == "voice" else True
        output_mode = ask_choice("📤 Output mode (text/voice): ", {"text", "voice"})
        output_lang = ask_language("📤 Output language: ")
        
        # Confirm
        if not confirm_run_summary(input_mode, fast_mode, input_lang, output_lang, output_mode, 3):
            print("\n❌ Test cancelled by user.")
            return
        
        # Collect input
        print("\n" + "-" * 70)
        print("📥 INPUT COLLECTION")
        print("-" * 70)
        
        if input_mode == "text":
            user_input = input("\n💬 Enter your text: ").strip()
            validate_text(user_input)
        else:
            audio_path = input("\n🎤 Enter path to audio file: ").strip()
            user_input = load_audio_file(audio_path)
        
        # Process input
        print("\n" + "-" * 70)
        print("⚙️  STEP 1: INPUT PROCESSING")
        print("-" * 70)
        
        if ALLOW_REAL_API_CALLS:
            print("\n⏳ Processing input...\n")
            english_query = process_input(
                user_input=user_input,
                input_mode=input_mode,
                input_lang=input_lang,
                fast_mode=fast_mode
            )
            print(f"✅ Input processed successfully!")
            print(f"\n📝 English Query:")
            print(f"   {english_query}\n")
        else:
            english_query = "[DRY RUN] Mock English query"
            print(f"\n[DRY RUN] Skipping real API call")
            print(f"English Query: {english_query}\n")
        
        # Fake RAG
        print("-" * 70)
        print("⚙️  STEP 2: SIMULATED RAG (using fake response)")
        print("-" * 70)
        english_answer = fake_rag_pipeline(english_query)
        print(f"\n📝 English Answer:")
        print(f"   {english_answer}\n")
        
        # Process output
        print("-" * 70)
        print("⚙️  STEP 3: OUTPUT PROCESSING")
        print("-" * 70)
        
        if ALLOW_REAL_API_CALLS:
            print("\n⏳ Processing output...\n")
            result = process_output(
                english_text=english_answer,
                output_mode=output_mode,
                output_lang=output_lang
            )
            print("✅ Output processed successfully!")
        else:
            result = {"text": "[DRY RUN] Mock output", "audio": None}
            print("\n[DRY RUN] Skipping real API call")
        
        # Display results
        print("\n" + "=" * 70)
        print("✅ RESULTS")
        print("=" * 70)
        print(f"\n📝 Final Text ({output_lang}):")
        print(f"   {result['text']}\n")
        
        if result.get("audio") and SAVE_AUDIO_OUTPUT:
            output_file = "test_output_component.wav"
            with open(output_file, "wb") as f:
                f.write(result["audio"])
            print(f"🔊 Audio saved to: {os.path.abspath(output_file)}\n")
        
        print("✅ Component test completed successfully!")
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Test interrupted by user.")
    except Exception as e:
        print(f"\n\n❌ ERROR: {type(e).__name__}: {e}")


# =============================================================================
# MAIN MENU
# =============================================================================

def main():
    """Main test runner with interactive menu."""
    print("=" * 70)
    print("🎤 INTEGRATED VOICE RAG PIPELINE - DEMO TEST SCRIPT")
    print("=" * 70)
    print("\nThis script allows you to test the voice-enabled multilingual")
    print("RAG pipeline with different configurations and modes.\n")
    
    # Check availability
    print("📋 Component Status:")
    print(f"   • Integrated Pipeline  : {'✅ Available' if PIPELINE_AVAILABLE else '❌ Not Available'}")
    print(f"   • sarvam_code Module   : {'✅ Available' if SARVAM_AVAILABLE else '❌ Not Available'}")
    
    if SARVAM_AVAILABLE:
        print(f"   • Supported Languages  : {len(SUPPORTED_LANGUAGES)} languages")
    
    print(f"\n⚙️  Configuration:")
    print(f"   • Real API Calls       : {'✅ Enabled' if ALLOW_REAL_API_CALLS else '⚠️  Disabled (Dry Run)'}")
    print(f"   • Save Audio Output    : {'✅ Yes' if SAVE_AUDIO_OUTPUT else '❌ No'}")
    print(f"   • Max Text Length      : {MAX_TEXT_LENGTH} chars")
    print(f"   • Max Audio File Size  : {MAX_AUDIO_FILE_MB} MB")
    
    # Main menu
    while True:
        print("\n" + "=" * 70)
        print("📋 TEST MODES")
        print("=" * 70)
        print("\n  1. Full Pipeline Test (Input → RAG → Output)")
        print("  2. Component Test Only (Input → Fake RAG → Output)")
        print("  3. Exit")
        
        choice = ask_choice("\n🔹 Select test mode (1/2/3): ", {"1", "2", "3"})
        
        if choice == "1":
            test_mode_full_pipeline()
        elif choice == "2":
            test_mode_components_only()
        elif choice == "3":
            print("\n👋 Exiting test script. Goodbye!")
            break
        
        print("\n" + "-" * 70)
        cont = ask_bool("\n🔄 Run another test? (yes/no): ")
        if not cont:
            print("\n👋 Exiting test script. Goodbye!")
            break


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Script interrupted by user. Goodbye!")
    except Exception as e:
        print(f"\n\n❌ FATAL ERROR: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
