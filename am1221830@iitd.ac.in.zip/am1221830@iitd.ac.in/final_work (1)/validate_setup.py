"""
Setup Validation Script

Validates all components of the Integrated Voice RAG Pipeline:
1. Python dependencies
2. sarvam_code module availability
3. API keys configuration
4. Vector Search connectivity
5. LLM access
6. IndicTrans2 models

Run this script before using the pipeline to ensure everything is configured correctly.
"""

import sys
import os
from typing import Tuple, List

# Add current directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

print("=" * 80)
print("INTEGRATED VOICE RAG PIPELINE - SETUP VALIDATION")
print("=" * 80)
print()


def print_section(title: str):
    """Print a section header."""
    print("\n" + "-" * 80)
    print(f"  {title}")
    print("-" * 80)


def print_result(check: str, passed: bool, message: str = ""):
    """Print a validation result."""
    status = "✅" if passed else "❌"
    print(f"{status} {check}")
    if message:
        print(f"   {message}")


# ===========================================================================
# 1. Check Python Dependencies
# ===========================================================================
print_section("1. Checking Python Dependencies")

required_packages = [
    "databricks",
    "openai",
    "transformers",
    "torch",
    "sentencepiece",
    "requests",
]

missing_packages = []
for package in required_packages:
    try:
        __import__(package)
        print_result(f"{package}", True)
    except ImportError:
        print_result(f"{package}", False, "Not installed")
        missing_packages.append(package)

if missing_packages:
    print("\n⚠️  Install missing packages:")
    print(f"   %pip install {' '.join(missing_packages)}")


# ===========================================================================
# 2. Check sarvam_code Module
# ===========================================================================
print_section("2. Checking sarvam_code Module")

sarvam_code_available = False
try:
    from sarvam_code import process_input, process_output
    from sarvam_code.config import (
        SUPPORTED_LANGUAGES,
        SARVAM_STT_API_KEY,
        SARVAM_TTS_API_KEY,
    )
    print_result("sarvam_code module import", True)
    print_result("process_input function", True)
    print_result("process_output function", True)
    sarvam_code_available = True
except ImportError as e:
    print_result("sarvam_code module import", False, str(e))
    print("\n⚠️  Make sure sarvam_code folder exists in parent directory")


# ===========================================================================
# 3. Check API Keys Configuration
# ===========================================================================
print_section("3. Checking API Keys Configuration")

if sarvam_code_available:
    stt_key_valid = bool(SARVAM_STT_API_KEY and SARVAM_STT_API_KEY.strip() and 
                         "your_" not in SARVAM_STT_API_KEY.lower())
    tts_key_valid = bool(SARVAM_TTS_API_KEY and SARVAM_TTS_API_KEY.strip() and 
                         "your_" not in SARVAM_TTS_API_KEY.lower())
    
    print_result("SARVAM_STT_API_KEY", stt_key_valid, 
                 "Configured" if stt_key_valid else "Not configured or placeholder")
    print_result("SARVAM_TTS_API_KEY", tts_key_valid,
                 "Configured" if tts_key_valid else "Not configured or placeholder")
    
    if not (stt_key_valid and tts_key_valid):
        print("\n⚠️  Configure API keys in sarvam_code/.env file:")
        print("   1. Copy .env.template to sarvam_code/.env")
        print("   2. Edit sarvam_code/.env with your actual API keys")
else:
    print_result("API Keys", False, "Cannot check - sarvam_code not available")


# ===========================================================================
# 4. Check Supported Languages
# ===========================================================================
print_section("4. Checking Supported Languages")

if sarvam_code_available:
    num_languages = len(SUPPORTED_LANGUAGES)
    print_result(f"Supported Languages: {num_languages}", num_languages > 0)
    
    if num_languages > 0:
        print("\n   Available languages:")
        for code, name in sorted(SUPPORTED_LANGUAGES.items(), key=lambda x: x[1]):
            print(f"     • {name:15s} ({code})")
else:
    print_result("Supported Languages", False, "Cannot check - sarvam_code not available")


# ===========================================================================
# 5. Check Vector Search Connectivity
# ===========================================================================
print_section("5. Checking Vector Search Connectivity")

try:
    from databricks.vector_search.client import VectorSearchClient
    
    vsc = VectorSearchClient(disable_notice=True)
    print_result("Vector Search Client", True)
    
    # Try to list endpoints
    try:
        endpoints = vsc.list_endpoints()
        print_result("List endpoints", True, f"Found {len(endpoints)} endpoints")
        
        # Check if our endpoint exists
        endpoint_name = "samarthvaani_vs_endpoint"
        endpoint_exists = any(ep.get('name') == endpoint_name for ep in endpoints)
        print_result(f"Endpoint '{endpoint_name}'", endpoint_exists,
                     "Found" if endpoint_exists else "Not found")
        
        if endpoint_exists:
            # Try to get the index
            try:
                index_name = "samarthvaani.gold.rpwd_chunks_index"
                index = vsc.get_index(endpoint_name=endpoint_name, index_name=index_name)
                print_result(f"Index '{index_name}'", True, "Accessible")
            except Exception as e:
                print_result(f"Index '{index_name}'", False, str(e))
    except Exception as e:
        print_result("List endpoints", False, str(e))
        
except ImportError as e:
    print_result("Vector Search Client", False, f"databricks-vectorsearch not installed: {e}")
except Exception as e:
    print_result("Vector Search Client", False, str(e))


# ===========================================================================
# 6. Check LLM Access (Foundation Model API)
# ===========================================================================
print_section("6. Checking LLM Access")

try:
    from openai import OpenAI
    import os
    
    # Try to create client
    token = os.environ.get("DATABRICKS_TOKEN")
    if not token:
        # Try to get from notebook context
        try:
            token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
        except:
            pass
    
    if token:
        print_result("Databricks token", True)
        
        # Try a simple LLM call
        try:
            client = OpenAI(
                api_key=token,
                base_url="https://your-workspace.databricks.com/serving-endpoints"
            )
            print_result("OpenAI client", True)
            print("   Note: Actual LLM call test requires workspace URL configuration")
        except Exception as e:
            print_result("OpenAI client", False, str(e))
    else:
        print_result("Databricks token", False, "Not found in environment")
        
except ImportError as e:
    print_result("OpenAI library", False, f"Not installed: {e}")
except Exception as e:
    print_result("LLM Access", False, str(e))


# ===========================================================================
# 7. Check IndicTrans2 Models
# ===========================================================================
print_section("7. Checking IndicTrans2 Models (Translation)")

if sarvam_code_available:
    try:
        from sarvam_code.translate import translate
        
        print_result("IndicTrans2 translate function", True)
        print("\n   Note: First translation will download models (~2GB each)")
        print("   This is normal and only happens once.")
        
        # Try a simple translation test (if user wants)
        print("\n   Skipping actual translation test (can be slow on first run)")
        print("   Translation will be tested in component test notebook")
        
    except ImportError as e:
        print_result("IndicTrans2", False, f"Import error: {e}")
    except Exception as e:
        print_result("IndicTrans2", False, str(e))
else:
    print_result("IndicTrans2", False, "Cannot check - sarvam_code not available")


# ===========================================================================
# Summary
# ===========================================================================
print("\n" + "=" * 80)
print("VALIDATION SUMMARY")
print("=" * 80)

all_checks = {
    "Python Dependencies": len(missing_packages) == 0,
    "sarvam_code Module": sarvam_code_available,
    "API Keys": sarvam_code_available and stt_key_valid and tts_key_valid if sarvam_code_available else False,
    "Supported Languages": sarvam_code_available and len(SUPPORTED_LANGUAGES) > 0 if sarvam_code_available else False,
}

passed = sum(1 for v in all_checks.values() if v)
total = len(all_checks)

print(f"\nPassed: {passed}/{total} checks\n")

for check, status in all_checks.items():
    print_result(check, status)

if passed == total:
    print("\n🎉 All validation checks passed! You're ready to use the pipeline.")
else:
    print("\n⚠️  Some checks failed. Please fix the issues above before proceeding.")
    print("\n📋 Next steps:")
    if not sarvam_code_available:
        print("   1. Ensure sarvam_code folder exists in parent directory")
    if sarvam_code_available and not (stt_key_valid and tts_key_valid):
        print("   2. Configure API keys in sarvam_code/.env")
    if missing_packages:
        print("   3. Install missing Python packages")

print("\n" + "=" * 80)
