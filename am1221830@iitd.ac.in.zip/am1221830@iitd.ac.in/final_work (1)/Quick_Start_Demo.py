# Databricks notebook source
# DBTITLE 1,Quick Start Guide
# MAGIC %md
# MAGIC # 🚀 Quick Start: Integrated Voice RAG Pipeline
# MAGIC
# MAGIC **Welcome!** This notebook demonstrates the complete voice-enabled multilingual RAG pipeline.
# MAGIC
# MAGIC ## What This Pipeline Does:
# MAGIC
# MAGIC Takes user queries in **any supported language** (text or voice) and returns answers about disability rights (RPWD Act) in **any supported language** (text or voice).
# MAGIC
# MAGIC ### Supported Modes:
# MAGIC
# MAGIC | Input | Output | Example |
# MAGIC |-------|--------|----------|
# MAGIC | Text | Text | Hindi text → English text |
# MAGIC | Text | Voice | English text → Tamil audio |
# MAGIC | Voice | Text | Bengali audio → Gujarati text |
# MAGIC | Voice | Voice | Marathi audio → Hindi audio |
# MAGIC
# MAGIC ### Supported Languages (11):
# MAGIC
# MAGIC 🇮🇳 **English** • **Hindi** • **Tamil** • **Telugu** • **Marathi** • **Bengali** • **Kannada** • **Malayalam** • **Gujarati** • **Punjabi** • **Odia**
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Quick Start Steps:
# MAGIC
# MAGIC 1. ✅ **Validate Setup** - Ensure all components are ready
# MAGIC 2. 🔗 **Load RAG Pipeline** - Import the existing RAG functions
# MAGIC 3. 🎯 **Load Integration** - Import the voice integration layer
# MAGIC 4. 🧪 **Run Examples** - Test with sample queries
# MAGIC 5. 🎮 **Interactive Mode** - Try your own queries
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **Let's get started! Run each cell in order.**

# COMMAND ----------

# DBTITLE 1,Step 1: Validate Setup
# MAGIC %md
# MAGIC ## Step 1: Validate Setup ✅
# MAGIC
# MAGIC First, let's check that all required components are available and properly configured.

# COMMAND ----------

# DBTITLE 1,Quick Validation Check
import sys
import os

print("=" * 80)
print("🔍 QUICK SETUP VALIDATION")
print("=" * 80)
print()

# Add parent directory to path
parent_dir = '/Users/am1221830@iitd.ac.in'
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
    print(f"✅ Added to Python path: {parent_dir}")

# Check sarvam_code
print("\n📦 Checking Components...\n")
try:
    from sarvam_code import process_input, process_output
    from sarvam_code.config import SUPPORTED_LANGUAGES, SARVAM_STT_API_KEY, SARVAM_TTS_API_KEY
    print("✅ sarvam_code module - Available")
    print(f"   • Supported languages: {len(SUPPORTED_LANGUAGES)}")
    
    # Check API keys
    stt_ok = bool(SARVAM_STT_API_KEY and len(SARVAM_STT_API_KEY) > 10 and "your_" not in SARVAM_STT_API_KEY.lower())
    tts_ok = bool(SARVAM_TTS_API_KEY and len(SARVAM_TTS_API_KEY) > 10 and "your_" not in SARVAM_TTS_API_KEY.lower())
    
    if stt_ok and tts_ok:
        print("✅ API keys - Configured")
    else:
        print("⚠️  API keys - Not configured (needed for voice processing)")
        print("   Configure in: ../sarvam_code/.env")
    
except ImportError as e:
    print(f"❌ sarvam_code module - Not available: {e}")
    print("   Please ensure sarvam_code folder exists")

# Check integrated pipeline
try:
    from integrated_pipeline import voice_rag_query, load_rag_pipeline
    print("✅ integrated_pipeline - Available")
except ImportError as e:
    print(f"❌ integrated_pipeline - Not available: {e}")

# Check Vector Search
try:
    from databricks.vector_search.client import VectorSearchClient
    vsc = VectorSearchClient(disable_notice=True)
    print("✅ Vector Search Client - Available")
except Exception as e:
    print(f"⚠️  Vector Search Client - Issue: {e}")

print("\n" + "=" * 80)
print("\n✅ Validation complete! If all checks passed, proceed to Step 2.")
print("\n⚠️  If any checks failed, see the Setup Validation notebook for troubleshooting.")
print("=" * 80)

# COMMAND ----------

# DBTITLE 1,Step 2: Load RAG Pipeline
# MAGIC %md
# MAGIC ## Step 2: Load RAG Pipeline 🔗
# MAGIC
# MAGIC Now we'll load the existing RAG pipeline from notebook 05. This provides the English query → English answer functionality.

# COMMAND ----------

# DBTITLE 1,Load RAG Pipeline Functions
print("=" * 80)
print("📚 LOADING RAG PIPELINE")
print("=" * 80)
print()
print("Loading from: 05_Complete_RAG_Pipeline...\n")

# Load the RAG pipeline notebook
%run ../05_Complete_RAG_Pipeline

print("\n✅ RAG pipeline functions loaded!")
print("\nAvailable functions:")
print("  • retrieve_context() - Vector search for relevant chunks")
print("  • build_rag_prompt() - Format context + query for LLM")
print("  • generate_answer() - Call LLM for answer generation")
print("  • rag_pipeline() - Complete pipeline (retrieve → prompt → generate)")
print("\n" + "=" * 80)

# COMMAND ----------

# DBTITLE 1,Step 3: Load Integration Layer
# MAGIC %md
# MAGIC ## Step 3: Load Voice Integration Layer 🎯
# MAGIC
# MAGIC Load the integration layer that connects voice/translation with the RAG pipeline.

# COMMAND ----------

# DBTITLE 1,Load Integrated Pipeline
print("=" * 80)
print("🔗 LOADING INTEGRATION LAYER")
print("=" * 80)
print()

from integrated_pipeline import voice_rag_query, load_rag_pipeline, format_result, save_audio

# Connect to the RAG pipeline we just loaded
load_rag_pipeline()

print("\n✅ Integration layer loaded!")
print("\nMain function: voice_rag_query()")
print("  • Handles all input modes (text/voice)")
print("  • Supports all 11 languages")
print("  • Handles all output modes (text/voice)")
print("  • Connects seamlessly with RAG pipeline")
print("\n" + "=" * 80)