# Databricks notebook source
# DBTITLE 1,Query Your Documents - SamarthVaani RAG
# MAGIC %md
# MAGIC # 🚀 Query Your Government Policy Documents
# MAGIC
# MAGIC ## What This Notebook Does
# MAGIC Use this notebook to **ask questions** about your government policy documents on disability rights and schemes.
# MAGIC
# MAGIC ## Your Data
# MAGIC * **5 PDF documents** with 1,911 pages
# MAGIC * **2.7M characters** of government policies
# MAGIC * **1,190 semantic chunks** ready for search
# MAGIC * **8 topics**: education, employment, schemes, rights, reservation, certification, healthcare, general
# MAGIC
# MAGIC ## How It Works
# MAGIC 1. Type your question in natural language
# MAGIC 2. Vector Search finds most relevant chunks
# MAGIC 3. Results ranked by semantic similarity
# MAGIC 4. Filter by topic for focused results
# MAGIC
# MAGIC ## Quick Start
# MAGIC Run all cells below, then use `ask()` function to query!

# COMMAND ----------

# DBTITLE 1,Install Libraries and Setup
# MAGIC %pip install databricks-vectorsearch --quiet
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Define Query Function
from databricks.vector_search.client import VectorSearchClient

# Configuration
ENDPOINT_NAME = "samarthvaani_vs_endpoint"
INDEX_NAME = "samarthvaani.gold.rpwd_chunks_index"

def ask(question, num_results=3, topic=None, show_full_text=False):
    """
    Ask a question about your government policy documents.
    
    Args:
        question: Your question in natural language
        num_results: Number of results to return (default: 3)
        topic: Filter by topic (education, employment, schemes, rights, etc.)
        show_full_text: Show complete chunk text (default: False shows preview)
    
    Example:
        ask("What are education rights for disabled children?")
        ask("employment schemes", topic="employment", num_results=5)
    """
    print("\n" + "="*70)
    print("🔍 QUESTION:", question)
    if topic:
        print(f"📂 Topic Filter: {topic}")
    print("="*70 + "\n")
    
    # Initialize client
    vsc = VectorSearchClient(disable_notice=True)
    
    # Build search parameters
    search_params = {
        "query_text": question,
        "columns": ["chunk_text", "topic", "section_title", "source", "doc_type"],
        "num_results": num_results
    }
    
    if topic:
        search_params["filters"] = {"topic": topic}
    
    try:
        # Search
        results = vsc.get_index(ENDPOINT_NAME, INDEX_NAME).similarity_search(**search_params)
        result_data = results.get('result', {}).get('data_array', [])
        
        if len(result_data) == 0:
            print("⚠️  No results found. Try a different question or remove topic filter.")
            return
        
        print(f"✅ Found {len(result_data)} relevant results\n")
        
        # Display results
        for i, row in enumerate(result_data, 1):
            chunk_text = row[0]
            topic_val = row[1]
            section = row[2]
            source = row[3]
            doc_type = row[4]
            
            print(f"📄 Result {i}")
            print(f"   Source: {source}")
            print(f"   Topic: {topic_val} | Type: {doc_type}")
            print(f"   Section: {section[:80]}...")
            print("\n   Content:")
            
            if show_full_text:
                print(f"   {chunk_text}")
            else:
                # Show first 400 characters
                preview = chunk_text[:400] + "..." if len(chunk_text) > 400 else chunk_text
                print(f"   {preview}")
            
            print("\n" + "-"*70 + "\n")
        
        print("="*70)
        print("💡 TIP: Use show_full_text=True to see complete chunks")
        print("="*70)
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        print("\nMake sure Vector Search index is ready (takes 2-5 mins after setup)")

print("✅ Query function ready!")
print("\n📝 Usage: ask('your question here')")

# COMMAND ----------

# DBTITLE 1,Example Queries
# MAGIC %md
# MAGIC ## 📚 Example Queries to Try
# MAGIC
# MAGIC Run any of the cells below to test the system:

# COMMAND ----------

# DBTITLE 1,Example 1: Education Rights
# Ask about education rights
ask("What are the education rights for children with disabilities?")

# COMMAND ----------

# DBTITLE 1,Example 2: Employment Schemes
# Ask about employment schemes with topic filter
ask("What employment schemes are available for persons with disabilities?", 
    topic="employment", 
    num_results=5)

# COMMAND ----------

# DBTITLE 1,Example 3: Reservation Policy
# Ask about reservation/quota
ask("What is the reservation policy in government jobs?", 
    topic="reservation")

# COMMAND ----------

# DBTITLE 1,Example 4: Scholarships
# Ask about scholarships
ask("What scholarships are available for students with disabilities?")

# COMMAND ----------

# DBTITLE 1,Example 5: RPWD Act
# Ask about the RPWD Act
ask("What is the Rights of Persons with Disabilities Act 2016?", 
    topic="rights",
    show_full_text=True)

# COMMAND ----------

# DBTITLE 1,Your Custom Queries
# MAGIC %md
# MAGIC ## ✍️ Ask Your Own Questions
# MAGIC
# MAGIC Use the cell below to ask any question about your documents:

# COMMAND ----------

# DBTITLE 1,Ask Your Question Here
# Type your question and run this cell

ask("your question here", num_results=3)

# COMMAND ----------

# DBTITLE 1,Advanced: Browse by Topic
# MAGIC %md
# MAGIC ## 🗂️ Browse Documents by Topic
# MAGIC
# MAGIC You can explore chunks by topic:

# COMMAND ----------

# DBTITLE 1,Browse Education Content
# Show general education-related content
ask("education disability", topic="education", num_results=5)

# COMMAND ----------

# DBTITLE 1,Browse Healthcare Content
# Show healthcare-related content
ask("medical health treatment", topic="healthcare", num_results=5)

# COMMAND ----------

# DBTITLE 1,Statistics
# MAGIC %md
# MAGIC ## 📊 Document Statistics

# COMMAND ----------

# DBTITLE 1,Show Statistics
# Show statistics about your documents
print("="*70)
print("📊 SAMARTHVAANI DOCUMENT STATISTICS")
print("="*70)

# Topic distribution
print("\n📚 Content by Topic:")
topics = spark.table("samarthvaani.gold.rpwd_chunks_enriched") \
    .groupBy("topic").count() \
    .orderBy("count", ascending=False)

display(topics)

# Document sources
print("\n📄 Documents:")
sources = spark.table("samarthvaani.gold.rpwd_chunks_enriched") \
    .groupBy("source").count() \
    .orderBy("count", ascending=False)

display(sources)

# Total stats
total_chunks = spark.table("samarthvaani.gold.rpwd_chunks_enriched").count()
avg_words = spark.table("samarthvaani.gold.rpwd_chunks_enriched") \
    .selectExpr("avg(word_count) as avg").collect()[0][0]

print(f"\n✅ Total Chunks: {total_chunks}")
print(f"✅ Average Chunk Size: {avg_words:.0f} words")
print(f"\n💡 Ready to answer questions across all {total_chunks} chunks!")
print("="*70)