# Databricks notebook source
# DBTITLE 1,Install Language Support Packages
# MAGIC %pip install -q transformers sentencepiece sacremoses langdetect lingua-language-detector torch
# MAGIC print("✅ Language support packages installed")

# COMMAND ----------

# DBTITLE 1,Import Libraries and Setup
from langdetect import detect, detect_langs
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import torch

# Supported Indian languages mapping (ISO 639-1 to full name)
SUPPORTED_LANGUAGES = {
    'hi': 'Hindi',
    'ta': 'Tamil', 
    'te': 'Telugu',
    'bn': 'Bengali',
    'mr': 'Marathi',
    'gu': 'Gujarati',
    'kn': 'Kannada',
    'ml': 'Malayalam',
    'pa': 'Punjabi',
    'or': 'Odia',
    'as': 'Assamese',
    'ur': 'Urdu',
    'ks': 'Kashmiri',
    'kok': 'Konkani',
    'mni': 'Manipuri',
    'ne': 'Nepali',
    'brx': 'Bodo',
    'doi': 'Dogri',
    'mai': 'Maithili',
    'sat': 'Santali',
    'sd': 'Sindhi',
    'sa': 'Sanskrit',
    'en': 'English'
}

print("✅ Libraries imported")
print(f"📚 Supporting {len(SUPPORTED_LANGUAGES)} languages: {', '.join(SUPPORTED_LANGUAGES.values())}")

# COMMAND ----------

# DBTITLE 1,Language Detection Function
def detect_language(text):
    """
    Detect the language of input text.
    
    Args:
        text: Input text in any supported language
    
    Returns:
        ISO 639-1 language code (e.g., 'hi', 'ta', 'en')
    """
    try:
        # Use langdetect for initial detection
        detected = detect(text)
        
        # Map to our supported languages
        if detected in SUPPORTED_LANGUAGES:
            return detected
        else:
            # Default to English if unsupported
            print(f"⚠️ Detected language '{detected}' not in supported list. Defaulting to English.")
            return 'en'
    
    except Exception as e:
        print(f"⚠️ Language detection error: {e}. Defaulting to English.")
        return 'en'

print("✅ Language detection function defined")

# COMMAND ----------

# DBTITLE 1,Load IndicTrans2 Translation Models
# Load IndicTrans2 models for bidirectional translation
print("📦 Loading IndicTrans2 translation models...")
print("This may take a few minutes on first run...")

# Model for Indic languages to English
indic_to_en_model_name = "ai4bharat/indictrans2-indic-en-1B"
indic_to_en_tokenizer = AutoTokenizer.from_pretrained(indic_to_en_model_name, trust_remote_code=True)
indic_to_en_model = AutoModelForSeq2SeqLM.from_pretrained(indic_to_en_model_name, trust_remote_code=True)

# Model for English to Indic languages  
en_to_indic_model_name = "ai4bharat/indictrans2-en-indic-1B"
en_to_indic_tokenizer = AutoTokenizer.from_pretrained(en_to_indic_model_name, trust_remote_code=True)
en_to_indic_model = AutoModelForSeq2SeqLM.from_pretrained(en_to_indic_model_name, trust_remote_code=True)

# Use GPU if available
device = "cuda" if torch.cuda.is_available() else "cpu"
indic_to_en_model.to(device)
en_to_indic_model.to(device)

print(f"✅ Models loaded on device: {device}")
print(f"✅ Indic → English model: {indic_to_en_model_name}")
print(f"✅ English → Indic model: {en_to_indic_model_name}")

# COMMAND ----------

# DBTITLE 1,Translation Functions
def translate_to_english(text, source_lang):
    """
    Translate text from any Indian language to English.
    
    Args:
        text: Input text in source language
        source_lang: ISO 639-1 source language code (e.g., 'hi', 'ta')
    
    Returns:
        Translated English text
    """
    # If already English, return as-is
    if source_lang == 'en':
        return text
    
    try:
        # Prepare input with language tag
        input_text = f"{source_lang}: {text}"
        inputs = indic_to_en_tokenizer(input_text, return_tensors="pt", padding=True).to(device)
        
        # Generate translation
        with torch.no_grad():
            outputs = indic_to_en_model.generate(**inputs, max_length=512)
        
        # Decode output
        translation = indic_to_en_tokenizer.decode(outputs[0], skip_special_tokens=True)
        return translation
    
    except Exception as e:
        print(f"⚠️ Translation error (to English): {e}")
        return text  # Return original if translation fails


def translate_to_target(text, target_lang):
    """
    Translate English text to target Indian language.
    
    Args:
        text: English text to translate
        target_lang: ISO 639-1 target language code (e.g., 'hi', 'ta')
    
    Returns:
        Translated text in target language
    """
    # If target is English, return as-is
    if target_lang == 'en':
        return text
    
    try:
        # Prepare input with language tag
        input_text = f"en: {text}"
        inputs = en_to_indic_tokenizer(input_text, return_tensors="pt", padding=True).to(device)
        
        # Generate translation
        with torch.no_grad():
            outputs = en_to_indic_model.generate(**inputs, max_length=512, num_beams=5)
        
        # Decode output (target language is implicit based on model)
        translation = en_to_indic_tokenizer.decode(outputs[0], skip_special_tokens=True)
        return translation
    
    except Exception as e:
        print(f"⚠️ Translation error (from English): {e}")
        return text  # Return original if translation fails

print("✅ Translation functions defined")
print("✅ translate_to_english(text, source_lang)")
print("✅ translate_to_target(text, target_lang)")

# COMMAND ----------

# DBTITLE 1,Import RAG Pipeline from Notebook 05
# MAGIC %run /Users/am1221830@iitd.ac.in/05_Complete_RAG_Pipeline
# MAGIC
# MAGIC print("✅ RAG pipeline functions imported from notebook 05")
# MAGIC print("✅ Available functions: rag_query(), retrieve_context(), build_rag_prompt(), generate_answer()")

# COMMAND ----------

# DBTITLE 1,Multilingual RAG Wrapper Function
def multilingual_rag_query(question, source_lang=None, top_k=3, topic_filter=None, verbose=True):
    """
    Multilingual RAG query that handles any supported language.
    
    Args:
        question: User's question in any supported language
        source_lang: Optional ISO 639-1 language code (auto-detected if None)
        top_k: Number of chunks to retrieve
        topic_filter: Optional topic filter for retrieval
        verbose: Print progress information
    
    Returns:
        Dictionary with answer in both original language and English
    """
    if verbose:
        print("🌐 MULTILINGUAL RAG PIPELINE")
        print("="*80)
    
    # Step 1: Detect language if not provided
    if source_lang is None:
        source_lang = detect_language(question)
    
    detected_lang_name = SUPPORTED_LANGUAGES.get(source_lang, 'Unknown')
    
    if verbose:
        print(f"💬 Original Question ({detected_lang_name}): {question}")
    
    # Step 2: Translate to English if needed
    if source_lang != 'en':
        if verbose:
            print(f"\n🔄 Translating from {detected_lang_name} to English...")
        english_question = translate_to_english(question, source_lang)
        if verbose:
            print(f"💬 English Question: {english_question}")
    else:
        english_question = question
    
    # Step 3: Call RAG pipeline with English query
    if verbose:
        print(f"\n🔍 Retrieving context and generating answer...\n")
    
    rag_result = rag_query(
        question=english_question,
        top_k=top_k,
        topic_filter=topic_filter,
        verbose=False  # Suppress internal RAG verbosity
    )
    
    english_answer = rag_result["answer"]
    
    # Step 4: Translate answer back to source language if needed
    if source_lang != 'en':
        if verbose:
            print(f"🔄 Translating answer back to {detected_lang_name}...\n")
        translated_answer = translate_to_target(english_answer, source_lang)
    else:
        translated_answer = english_answer
    
    # Step 5: Return results
    result = {
        "question": question,
        "question_english": english_question,
        "answer": translated_answer,  # Answer in user's language
        "answer_english": english_answer,  # English version
        "detected_language": detected_lang_name,
        "language_code": source_lang,
        "sources": rag_result["sources"],
        "chunks_retrieved": rag_result["chunks_retrieved"],
        "model": rag_result["model"],
        "success": rag_result["success"]
    }
    
    if verbose:
        print("="*80)
        print(f"💬 ANSWER ({detected_lang_name}):")
        print("="*80)
        print(translated_answer)
        print("\n" + "="*80)
        print("📚 SOURCES:")
        print("="*80)
        for i, source in enumerate(result["sources"], 1):
            print(f"  {i}. {source['source']} (Topic: {source['topic']})")
        print("="*80)
    
    return result

print("✅ Multilingual RAG wrapper function defined")
print("✅ multilingual_rag_query(question, source_lang=None, top_k=3, topic_filter=None)")

# COMMAND ----------

# DBTITLE 1,Test Multilingual RAG Pipeline
# MAGIC %md
# MAGIC ## Test Queries in Multiple Languages
# MAGIC
# MAGIC Let's test the multilingual RAG pipeline with queries in Hindi, Tamil, and Bengali.

# COMMAND ----------

# DBTITLE 1,Test 1: Hindi Query
# Test with Hindi query about education rights
hindi_question = "विकलांग बच्चों के लिए शिक्षा अधिकार क्या हैं?"

result_hi = multilingual_rag_query(
    question=hindi_question,
    source_lang='hi',  # Explicitly specify Hindi
    top_k=3,
    verbose=True
)

# COMMAND ----------

# DBTITLE 1,Test 2: Tamil Query
# Test with Tamil query about employment schemes
tamil_question = "மாற்றுத்திறனாளிகளுக்கான வேலைவாய்ப்பு திட்டங்கள் என்ன?"

result_ta = multilingual_rag_query(
    question=tamil_question,
    source_lang='ta',  # Explicitly specify Tamil
    top_k=3,
    topic_filter='employment',
    verbose=True
)

# COMMAND ----------

# DBTITLE 1,Test 3: Bengali Query
# Test with Bengali query about government benefits
bengali_question = "প্রতিবন্ধী ব্যক্তিদের জন্য কি সরকারি সুবিধা আছে?"

result_bn = multilingual_rag_query(
    question=bengali_question,
    source_lang='bn',  # Explicitly specify Bengali
    top_k=3,
    verbose=True
)

# COMMAND ----------

# DBTITLE 1,Multilingual RAG Usage Guide
print("🌐 SAMARTHVAANI MULTILINGUAL RAG PIPELINE")
print("="*80)
print("\n📚 SUPPORTED LANGUAGES (23 total):")
print("-"*80)
for code, name in sorted(SUPPORTED_LANGUAGES.items(), key=lambda x: x[1]):
    print(f"  • {name:15} ({code})")

print("\n" + "="*80)
print("💡 USAGE EXAMPLES:")
print("-"*80)
print("""
# Auto-detect language
result = multilingual_rag_query("आपका सवाल यहाँ")

# Specify source language explicitly
result = multilingual_rag_query(
    question="உங்கள் கேள்வி இங்கே",
    source_lang='ta',
    top_k=5,
    topic_filter='education'
)

# Access results
print(result["answer"])  # Answer in user's language
print(result["answer_english"])  # English version
print(result["detected_language"])  # Detected language name

# View sources
for source in result["sources"]:
    print(f"{source['source']} - {source['topic']}")
""")

print("="*80)
print("✅ PIPELINE READY FOR MULTILINGUAL QUERIES")
print("="*80)
print("\n🔥 KEY FEATURES:")
print("  • Automatic language detection")
print("  • Translation using AI4Bharat IndicTrans2")
print("  • Semantic search in English knowledge base")
print("  • Answers returned in user's language + English")
print("  • Support for 22 Indian languages + English")
print("  • Topic filtering and metadata search")

# COMMAND ----------

# DBTITLE 1,Next Steps
# MAGIC %md
# MAGIC ## Next Steps
# MAGIC
# MAGIC ✅ **Completed:**
# MAGIC - Vector Search with 1,190 chunks indexed
# MAGIC - RAG pipeline with Meta Llama 3.3 70B Instruct
# MAGIC - Multilingual support for 23 languages
# MAGIC - Translation using IndicTrans2 models
# MAGIC
# MAGIC 🚀 **Coming Next:**
# MAGIC 1. **Gradio UI** - Build accessible interface with voice input
# MAGIC 2. **Voice Support** - Add speech-to-text and text-to-speech
# MAGIC 3. **Databricks App** - Deploy as production app
# MAGIC 4. **MLflow Tracking** - Log queries and responses
# MAGIC 5. **Genie Space** - Add structured scheme lookups
# MAGIC 6. **Performance Optimization** - Cache translations, optimize retrieval