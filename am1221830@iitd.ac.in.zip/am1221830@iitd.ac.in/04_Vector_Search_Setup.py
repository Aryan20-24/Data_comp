# Databricks notebook source
# DBTITLE 1,Vector Search Setup Guide
# MAGIC %md
# MAGIC # SamarthVaani - Mosaic AI Vector Search Setup
# MAGIC
# MAGIC **Goal**: Create Vector Search endpoint and Delta Sync Index for semantic RAG
# MAGIC
# MAGIC ## What is Databricks Vector Search?
# MAGIC Managed vector database that automatically:
# MAGIC * **Embeds** your text using state-of-the-art models
# MAGIC * **Syncs** with Delta tables via Change Data Feed (CDF)
# MAGIC * **Searches** using hybrid (semantic + keyword) retrieval
# MAGIC * **Governs** through Unity Catalog permissions
# MAGIC
# MAGIC ## Why Delta Sync Index?
# MAGIC * Auto-updates when your gold table changes (CDF)
# MAGIC * No manual index rebuilding needed
# MAGIC * Governed by Unity Catalog
# MAGIC * Production-ready with ACID guarantees
# MAGIC
# MAGIC ## Architecture
# MAGIC ```
# MAGIC gold.rpwd_chunks_enriched (Delta + CDF)
# MAGIC         ↓ (automatic sync)
# MAGIC Vector Search Endpoint
# MAGIC         ↓ (creates)
# MAGIC Delta Sync Index
# MAGIC         ↓ (queries)
# MAGIC RAG Pipeline
# MAGIC ```
# MAGIC
# MAGIC ## What This Notebook Does
# MAGIC 1. Create Vector Search endpoint
# MAGIC 2. Create Delta Sync Index on gold table
# MAGIC 3. Wait for initial sync to complete
# MAGIC 4. Test similarity search
# MAGIC 5. Show how to query for RAG

# COMMAND ----------

# DBTITLE 1,Install Vector Search Client
# MAGIC %pip install databricks-vectorsearch --quiet
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Import Libraries and Initialize Client
from databricks.vector_search.client import VectorSearchClient
from pyspark.sql.functions import col
import time

# Initialize Vector Search client
vsc = VectorSearchClient(disable_notice=True)

print("✅ Vector Search client initialized")

# COMMAND ----------

# DBTITLE 1,Create Vector Search Endpoint
# Define endpoint name
endpoint_name = "samarthvaani_vs_endpoint"

# Check if endpoint already exists
try:
    existing_endpoints = vsc.list_endpoints()
    endpoint_exists = any(ep.get('name') == endpoint_name for ep in existing_endpoints.get('endpoints', []))
    
    if endpoint_exists:
        print(f"✅ Endpoint '{endpoint_name}' already exists")
    else:
        print(f"🚀 Creating endpoint '{endpoint_name}'...")
        vsc.create_endpoint(
            name=endpoint_name,
            endpoint_type="STANDARD"  # or "ENTERPRISE" for higher performance
        )
        print(f"✅ Endpoint '{endpoint_name}' created successfully")
        print("   Note: Endpoint may take 2-3 minutes to become online")
except Exception as e:
    print(f"⚠️ Error: {e}")
    print("\nTrying to create endpoint...")
    try:
        vsc.create_endpoint(
            name=endpoint_name,
            endpoint_type="STANDARD"
        )
        print(f"✅ Created endpoint '{endpoint_name}'")
    except Exception as e2:
        print(f"❌ Failed to create endpoint: {e2}")

# COMMAND ----------

# DBTITLE 1,Wait for Endpoint to be Online
# Wait for endpoint to be ready
print(f"⏳ Waiting for endpoint '{endpoint_name}' to be online...")

max_wait = 300  # 5 minutes
start_time = time.time()

while time.time() - start_time < max_wait:
    try:
        endpoint = vsc.get_endpoint(endpoint_name)
        status = endpoint.get('endpoint_status', {}).get('state', 'UNKNOWN')
        
        if status == 'ONLINE':
            print(f"✅ Endpoint is ONLINE and ready!")
            break
        else:
            print(f"   Status: {status} ... waiting")
            time.sleep(10)
    except Exception as e:
        print(f"   Checking... {e}")
        time.sleep(10)
else:
    print("⚠️ Endpoint creation timed out. Check Compute > Vector Search in UI.")

# COMMAND ----------

# DBTITLE 1,Verify Gold Table is Ready
# Check gold table exists and has data
table_name = "samarthvaani.gold.rpwd_chunks_enriched"

try:
    df = spark.table(table_name)
    row_count = df.count()
    
    print(f"✅ Table: {table_name}")
    print(f"   Rows: {row_count}")
    
    if row_count == 0:
        print("\n⚠️ Warning: Table is empty!")
        print("   Run Notebook 03_Intelligent_Chunking first")
    else:
        print("\n👀 Sample rows:")
        display(df.select("chunk_id", "chunk_text", "topic").limit(3))
        
        # Verify CDF is enabled
        props = spark.sql(f"SHOW TBLPROPERTIES {table_name}").filter(
            col("key") == "delta.enableChangeDataFeed"
        ).collect()
        
        if props and props[0]['value'] == 'true':
            print("\n✅ Change Data Feed (CDF) is enabled")
        else:
            print("\n⚠️ CDF not enabled! Run this:")
            print(f"   ALTER TABLE {table_name} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)")
except Exception as e:
    print(f"❌ Error: {e}")
    print("\nRun Notebook 03_Intelligent_Chunking first!")

# COMMAND ----------

# DBTITLE 1,Create Delta Sync Index
# Define index name
index_name = "samarthvaani.gold.rpwd_chunks_index"
source_table = "samarthvaani.gold.rpwd_chunks_enriched"

print(f"🚀 Creating Delta Sync Index: {index_name}")
print(f"   Source table: {source_table}")
print(f"   Embedding model: databricks-bge-large-en")
print(f"   Pipeline type: TRIGGERED (manual sync)")

try:
    # Create the index
    index = vsc.create_delta_sync_index(
        endpoint_name=endpoint_name,
        index_name=index_name,
        source_table_name=source_table,
        pipeline_type="TRIGGERED",  # or "CONTINUOUS" for auto-sync
        primary_key="chunk_id",
        embedding_source_column="chunk_text",  # Column to embed
        embedding_model_endpoint_name="databricks-bge-large-en",  # Databricks-hosted embedding model
    )
    
    print(f"✅ Index created successfully!")
    print(f"   Index: {index_name}")
    print(f"   Embeddings will be generated from 'chunk_text' column")
    print(f"\n⏳ Initial sync started... this may take a few minutes")
    
except Exception as e:
    if "already exists" in str(e).lower():
        print(f"✅ Index '{index_name}' already exists")
    else:
        print(f"❌ Error creating index: {e}")
        print("\nMake sure:")
        print("  1. Endpoint is ONLINE")
        print("  2. Table has data")
        print("  3. CDF is enabled")

# COMMAND ----------

# DBTITLE 1,Monitor Index Sync Status
# Wait for initial sync to complete
print(f"⏳ Monitoring index sync status...\n")

max_wait = 600  # 10 minutes
start_time = time.time()

while time.time() - start_time < max_wait:
    try:
        # Get index status
        index_status = vsc.get_index(endpoint_name, index_name)
        
        status = index_status.get('status', {}).get('detailed_state', 'UNKNOWN')
        indexed_rows = index_status.get('status', {}).get('indexed_row_count', 0)
        
        print(f"   Status: {status} | Indexed rows: {indexed_rows}")
        
        if status in ['ONLINE_CONTINUOUS_UPDATE', 'ONLINE', 'ONLINE_NO_PENDING_UPDATE']:
            print(f"\n✅ Index is ready!")
            print(f"   Total indexed rows: {indexed_rows}")
            break
        elif 'FAILED' in status or 'ERROR' in status:
            print(f"\n❌ Index sync failed: {status}")
            break
        else:
            time.sleep(15)
    except Exception as e:
        print(f"   Error checking status: {e}")
        time.sleep(15)
else:
    print("\n⚠️ Sync is taking longer than expected")
    print("   Check status in Compute > Vector Search in the UI")

# COMMAND ----------

# DBTITLE 1,Test Similarity Search
# Test query
test_query = "What are the rights of persons with disabilities in education?"

print(f"🔍 Testing similarity search...")
print(f"   Query: '{test_query}'")

try:
    # Perform similarity search
    results = vsc.get_index(endpoint_name, index_name).similarity_search(
        query_text=test_query,
        columns=["chunk_id", "chunk_text", "topic", "section_title", "source"],
        num_results=3
    )
    
    print(f"\n✅ Found {len(results.get('result', {}).get('data_array', []))} results\n")
    
    # Display results
    for i, row in enumerate(results.get('result', {}).get('data_array', []), 1):
        print(f"--- Result {i} ---")
        print(f"Chunk ID: {row[0]}")
        print(f"Topic: {row[2]}")
        print(f"Section: {row[3][:100]}...")
        print(f"Text (first 300 chars): {row[1][:300]}...")
        print()
        
except Exception as e:
    print(f"❌ Search failed: {e}")
    print("\nIndex may still be syncing. Wait a few minutes and try again.")

# COMMAND ----------

# DBTITLE 1,Test with Filters (Topic-based Search)
# Test with metadata filters
test_query = "employment schemes"
filter_topic = "employment"

print(f"🔍 Testing filtered search...")
print(f"   Query: '{test_query}'")
print(f"   Filter: topic = '{filter_topic}'")

try:
    results = vsc.get_index(endpoint_name, index_name).similarity_search(
        query_text=test_query,
        columns=["chunk_id", "chunk_text", "topic", "section_title"],
        filters={"topic": filter_topic},  # Metadata filter
        num_results=3
    )
    
    print(f"\n✅ Found {len(results.get('result', {}).get('data_array', []))} results\n")
    
    for i, row in enumerate(results.get('result', {}).get('data_array', []), 1):
        print(f"--- Result {i} ---")
        print(f"Topic: {row[2]} (filtered)")
        print(f"Section: {row[3][:100]}...")
        print(f"Text: {row[1][:200]}...")
        print()
        
except Exception as e:
    print(f"❌ Search failed: {e}")

# COMMAND ----------

# DBTITLE 1,RAG Query Function (Ready to Use)
def rag_retrieve(query_text, top_k=3, topic_filter=None):
    """
    Retrieve relevant chunks for RAG pipeline.
    
    Args:
        query_text: User query (in English)
        top_k: Number of chunks to retrieve
        topic_filter: Optional topic filter ('education', 'employment', etc.)
    
    Returns:
        List of chunk texts for LLM context
    """
    try:
        # Build search parameters
        search_params = {
            "query_text": query_text,
            "columns": ["chunk_text", "section_title", "topic", "source"],
            "num_results": top_k
        }
        
        # Add topic filter if provided
        if topic_filter:
            search_params["filters"] = {"topic": topic_filter}
        
        # Search
        results = vsc.get_index(endpoint_name, index_name).similarity_search(**search_params)
        
        # Extract chunks
        chunks = []
        for row in results.get('result', {}).get('data_array', []):
            chunk_text = row[0]  # chunk_text is first column
            chunks.append(chunk_text)
        
        return chunks
    
    except Exception as e:
        print(f"Error in RAG retrieval: {e}")
        return []

# Test the function
test_chunks = rag_retrieve("education rights for disabled children", top_k=3)

print(f"✅ RAG Retrieve Function Ready")
print(f"\n📝 Retrieved {len(test_chunks)} chunks:\n")

for i, chunk in enumerate(test_chunks, 1):
    print(f"Chunk {i}: {chunk[:200]}...\n")

# COMMAND ----------

# DBTITLE 1,Summary and Next Steps
print("=" * 80)
print("✅ VECTOR SEARCH SETUP COMPLETE")
print("=" * 80)

print("\n📦 Created Resources:")
print(f"   ✓ Endpoint: {endpoint_name}")
print(f"   ✓ Index: {index_name}")
print(f"   ✓ Source: {source_table}")
print(f"   ✓ Embedding Model: databricks-bge-large-en")

print("\n🔍 Search Capabilities:")
print("   ✓ Semantic similarity search")
print("   ✓ Keyword (BM25) search")
print("   ✓ Hybrid search (semantic + keyword)")
print("   ✓ Metadata filtering (by topic)")

print("\n📚 How to Use in RAG:")
print("""   
   # Retrieve context
   chunks = rag_retrieve("user query in English", top_k=3)
   
   # Build prompt
   context = "\\n\\n".join(chunks)
   prompt = f"""Context: {context}
   
   Question: {query}
   
   Answer:"""
   
   # Pass to LLM (Param-1)
   response = llm.generate(prompt)
""")

print("\n" + "=" * 80)
print("🚀 NEXT STEP: Run Notebook 05_Complete_RAG_Pipeline")
print("=" * 80)