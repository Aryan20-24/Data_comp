# Databricks notebook source
# DBTITLE 1,PDF Ingestion Pipeline
# MAGIC %md
# MAGIC # SamarthVaani - PDF Ingestion & Text Extraction
# MAGIC
# MAGIC **Goal**: Extract text from PDFs and store in bronze.raw_documents table
# MAGIC
# MAGIC ## Where to Upload Your PDFs
# MAGIC
# MAGIC ### **Option 1: Using Databricks UI (Recommended)**
# MAGIC 1. Go to **Catalog** in left sidebar
# MAGIC 2. Navigate to: `samarthvaani` → `bronze` → `pdf_storage`
# MAGIC 3. Click **Upload** button
# MAGIC 4. Select your PDF files (RPWD Act, schemes, policies)
# MAGIC
# MAGIC ### **Option 2: Using dbutils (Programmatic)**
# MAGIC ```python
# MAGIC dbutils.fs.cp("file:/local/path/to/pdfs/", "/Volumes/samarthvaani/bronze/pdf_storage/", recurse=True)
# MAGIC ```
# MAGIC
# MAGIC ### **Path to Your Volume**
# MAGIC ```
# MAGIC /Volumes/samarthvaani/bronze/pdf_storage/
# MAGIC ```
# MAGIC
# MAGIC ## What This Notebook Does
# MAGIC 1. Scans the volume for PDF files
# MAGIC 2. Extracts text from each PDF
# MAGIC 3. Generates unique doc_id for each document
# MAGIC 4. Stores in `bronze.raw_documents` Delta table

# COMMAND ----------

# DBTITLE 1,Install Required Libraries
# MAGIC %pip install PyPDF2 pdfplumber python-magic-bin --quiet
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Import Libraries and Setup
import PyPDF2
import pdfplumber
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, current_timestamp, lit
from datetime import datetime
import uuid
import os

print("✅ Libraries imported successfully")

# COMMAND ----------

# DBTITLE 1,List PDFs in Volume
# Define volume path
volume_path = "/Volumes/samarthvaani/bronze/pdf_storage/"

# List all files in the volume
try:
    files = dbutils.fs.ls(volume_path)
    pdf_files = [f for f in files if f.name.endswith('.pdf')]
    
    print(f"📄 Found {len(pdf_files)} PDF files in volume:\n")
    for i, f in enumerate(pdf_files, 1):
        print(f"{i}. {f.name} ({f.size / 1024:.2f} KB)")
    
    if len(pdf_files) == 0:
        print("\n⚠️ No PDF files found!")
        print("\n🚀 Upload PDFs to: /Volumes/samarthvaani/bronze/pdf_storage/")
        print("   - Go to Catalog → samarthvaani → bronze → pdf_storage")
        print("   - Click 'Upload' button")
except Exception as e:
    print(f"❌ Error listing files: {e}")
    pdf_files = []

# COMMAND ----------

# DBTITLE 1,Extract Text from PDFs
def extract_text_from_pdf(pdf_path):
    """
    Extract text from PDF using pdfplumber (better handling of complex layouts)
    Falls back to PyPDF2 if pdfplumber fails
    """
    try:
        # Try pdfplumber first (better for complex PDFs)
        with pdfplumber.open(pdf_path) as pdf:
            text = ""
            page_count = len(pdf.pages)
            
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n\n"
            
            return text.strip(), page_count
    except Exception as e:
        print(f"   pdfplumber failed: {e}, trying PyPDF2...")
        
        # Fallback to PyPDF2
        try:
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                text = ""
                page_count = len(pdf_reader.pages)
                
                for page in pdf_reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n\n"
                
                return text.strip(), page_count
        except Exception as e2:
            print(f"   PyPDF2 also failed: {e2}")
            return "", 0

print("✅ PDF extraction function defined")

# COMMAND ----------

# DBTITLE 1,Process All PDFs and Store in Bronze Table
# Process each PDF
processed_docs = []

for pdf_file in pdf_files:
    print(f"\n📝 Processing: {pdf_file.name}")
    
    # Get full path (convert DBFS path to local path for reading)
    dbfs_path = pdf_file.path
    local_path = dbfs_path.replace("dbfs:", "/dbfs")
    
    # Extract text
    raw_text, page_count = extract_text_from_pdf(local_path)
    
    if raw_text:
        # Generate unique doc_id
        doc_id = str(uuid.uuid4())
        
        # Classify document type based on filename
        filename_lower = pdf_file.name.lower()
        if 'rpwd' in filename_lower or 'act' in filename_lower:
            doc_type = 'rpwd_act'
        elif 'scheme' in filename_lower or 'yojana' in filename_lower:
            doc_type = 'scheme'
        elif 'circular' in filename_lower or 'policy' in filename_lower:
            doc_type = 'circular'
        else:
            doc_type = 'other'
        
        processed_docs.append({
            'doc_id': doc_id,
            'filename': pdf_file.name,
            'doc_type': doc_type,
            'raw_text': raw_text,
            'page_count': page_count,
            'source_path': dbfs_path,
            'ingestion_timestamp': datetime.now()
        })
        
        print(f"   ✅ Extracted {len(raw_text)} characters from {page_count} pages")
        print(f"   🏷️  Document type: {doc_type}")
    else:
        print(f"   ⚠️ Failed to extract text from {pdf_file.name}")

print(f"\n✅ Processed {len(processed_docs)} PDFs successfully")

# COMMAND ----------

# DBTITLE 1,Save to Bronze Table
if len(processed_docs) > 0:
    # Create DataFrame
    from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType
    
    schema = StructType([
        StructField("doc_id", StringType(), False),
        StructField("filename", StringType(), False),
        StructField("doc_type", StringType(), True),
        StructField("raw_text", StringType(), True),
        StructField("page_count", IntegerType(), True),
        StructField("source_path", StringType(), True),
        StructField("ingestion_timestamp", TimestampType(), True)
    ])
    
    df = spark.createDataFrame(processed_docs, schema=schema)
    
    # Write to Delta table (append mode to preserve existing data)
    df.write \
        .format("delta") \
        .mode("append") \
        .saveAsTable("samarthvaani.bronze.raw_documents")
    
    print(f"✅ Successfully saved {len(processed_docs)} documents to bronze.raw_documents")
    
    # Show sample
    print("\n👀 Sample of ingested documents:")
    display(spark.table("samarthvaani.bronze.raw_documents").select(
        "doc_id", "filename", "doc_type", "page_count", "ingestion_timestamp"
    ))
else:
    print("⚠️ No documents to save. Upload PDFs first!")

# COMMAND ----------

# DBTITLE 1,Summary and Next Steps
# Display statistics
print("=" * 80)
print("✅ PDF INGESTION COMPLETE")
print("=" * 80)

total_docs = spark.table("samarthvaani.bronze.raw_documents").count()
print(f"\n📂 Total documents in bronze.raw_documents: {total_docs}")

if total_docs > 0:
    # Show document type breakdown
    doc_types = spark.table("samarthvaani.bronze.raw_documents") \
        .groupBy("doc_type") \
        .count() \
        .orderBy("count", ascending=False)
    
    print("\n📊 Document Type Breakdown:")
    display(doc_types)
    
    # Show total pages
    total_pages = spark.table("samarthvaani.bronze.raw_documents") \
        .selectExpr("sum(page_count) as total_pages") \
        .collect()[0][0]
    
    print(f"\n📝 Total Pages: {total_pages}")
    
    print("\n" + "=" * 80)
    print("🚀 NEXT STEP: Run Notebook 03_Intelligent_Chunking")
    print("=" * 80)
else:
    print("\n⚠️ No documents found. Upload PDFs to /Volumes/samarthvaani/bronze/pdf_storage/")