# 🚀 SamarthVaani Deployment Checklist

**Last Updated:** April 8, 2026, 4:15 PM GMT+5:30  
**Status:** Ready for deployment with Resources configuration

---

## ✅ PRE-DEPLOYMENT CHECKLIST

### 1. Files Ready ✅
- [x] app_voice.py (API schema bug fixed)
- [x] app.yaml (dynamic port + API keys configured)
- [x] requirements.txt (minimal 5 packages)
- [x] sarvam_code/ (all modules with lazy imports)

### 2. Configuration Ready ✅
- [x] Dynamic port configuration (DATABRICKS_APP_PORT)
- [x] Sarvam API keys in app.yaml
- [x] Error handling for all services
- [x] Graceful degradation when services unavailable

---

## ⚠️ CRITICAL: RESOURCES MUST BE ADDED IN UI

### Required in Databricks Apps → Resources Tab

You MUST add these resources in the Databricks Apps UI **BEFORE** the app will work:

#### 1. Vector Search Index ⚠️ REQUIRED
```
Type: Vector Search Index
Endpoint: samarthvaani_vs_endpoint
Index: samarthvaani.gold.rpwd_chunks_index
```

**Why needed:** For RAG retrieval (searching knowledge base)  
**If missing:** App will show "RAG services unavailable"

#### 2. Serving Endpoint ⚠️ REQUIRED  
```
Type: Serving Endpoint
Name: databricks-meta-llama-3-3-70b-instruct
```

**Why needed:** For LLM answer generation  
**If missing:** App will show "LLM service unavailable"

#### 3. Catalog (Optional but Recommended)
```
Type: Catalog
Name: samarthvaani
```

**Why needed:** For accessing vector search data  
**If missing:** May cause permission errors

---

## 📋 HOW TO ADD RESOURCES

### Step 1: Go to Databricks Apps
Navigate to: Apps → samarthvaani

### Step 2: Click "Resources" Tab
(Next to "Logs", "Environment", etc.)

### Step 3: Add Vector Search Index
1. Click "+ Add Resource"
2. Select "Vector Search Index"
3. Search for: `samarthvaani.gold.rpwd_chunks_index`
4. Select the endpoint: `samarthvaani_vs_endpoint`
5. Click "Add"

### Step 4: Add Serving Endpoint
1. Click "+ Add Resource"
2. Select "Serving Endpoint"
3. Search for: `databricks-meta-llama-3-3-70b-instruct`
4. Click "Add"

### Step 5: Add Catalog (Optional)
1. Click "+ Add Resource"
2. Select "Catalog"
3. Search for: `samarthvaani`
4. Click "Add"

---

## 🔍 SERVICE-BY-SERVICE CHECKLIST

### 1️⃣ Vector Search

**Configuration:**
- Endpoint: `samarthvaani_vs_endpoint`
- Index: `samarthvaani.gold.rpwd_chunks_index`
- Auth: Service principal (auto from Databricks Apps)

**Status Check:**
```
✅ Configured in app_voice.py lines 47-48
✅ Authentication via WorkspaceClient (lines 68-76)
✅ Error handling if unavailable (lines 86-88)
```

**Expected Logs:**
```
✅ Connected to index: samarthvaani.gold.rpwd_chunks_index
✅ Retrieved 3 chunks
```

**Troubleshooting:**
- If "Vector Search not available" → Check Resources tab
- If "Connection failed" → Check endpoint/index names
- If "Permission denied" → Add catalog resource

---

### 2️⃣ LLM Generation

**Configuration:**
- Endpoint: `databricks-meta-llama-3-3-70b-instruct`
- Model: Llama 3.3 70B Instruct
- Max tokens: 700
- Temperature: 0.1

**Status Check:**
```
✅ Configured in app_voice.py line 49
✅ Uses WorkspaceClient for auth (lines 117-132)
✅ Error handling if unavailable (line 117)
```

**Expected Logs:**
```
✅ Generated answer (XXX chars)
```

**Troubleshooting:**
- If "LLM service unavailable" → Check Resources tab
- If "Endpoint not found" → Verify endpoint name
- If "Rate limit" → Wait and retry

---

### 3️⃣ Speech-to-Text (Sarvam STT)

**Configuration:**
- API: Sarvam Saarika (saaras:v3)
- Key: sk_67mnl4xm_kMEavD8doVDVPWZdQkdT03YP
- Mode: fast_mode=True (translate to English directly)
- Languages: 11 Indian languages

**Status Check:**
```
✅ API key in app.yaml (lines 14-15)
✅ Configured in sarvam_code/config.py
✅ Error handling if unavailable (line 180)
```

**Expected Logs:**
```
✅ Transcribed: <original text>
✅ Translated to English: <english text>
```

**Troubleshooting:**
- If "Voice input requires Sarvam API" → Check API keys
- If "Audio processing error" → Check audio format
- If "API key invalid" → Verify keys in app.yaml

---

### 4️⃣ Text-to-Speech (Sarvam TTS)

**Configuration:**
- API: Sarvam Bulbul (bulbul:v3)
- Key: sk_g8d16wig_uTt8ShsVTOaWHizuWiY6Fskm
- Output: Audio file in /tmp/
- Languages: 11 Indian languages

**Status Check:**
```
✅ API key in app.yaml (lines 16-17)
✅ Configured in sarvam_code/config.py
✅ Audio saved to /tmp/ (allowed path)
✅ Error handling if unavailable (line 271)
```

**Expected Logs:**
```
✅ Audio saved (XXXX bytes)
```

**Troubleshooting:**
- If "TTS failed" → Check API keys
- If audio not playing → Check /tmp/ path permissions
- If "API key invalid" → Verify keys in app.yaml

---

### 5️⃣ Translation

**Configuration:**
- Fast mode: Sarvam API (translate mode)
- Slow mode: IndicTrans2 (disabled, packages removed)
- Languages: 11 Indian languages

**Status Check:**
```
✅ fast_mode=True in all calls
✅ IndicTrans2 imports are lazy (won't fail)
✅ Falls back to English if translation fails
```

**Expected Logs:**
```
✅ Translated: <english text>
✅ Translated answer
```

**Troubleshooting:**
- If translation fails → Falls back to English gracefully
- IndicTrans2 not available → Expected (packages removed)

---

## 🧪 TESTING PLAN

### After Deployment:

#### Test 1: Text Query (English) ✅
1. Type: "What are employment rights for disabled persons?"
2. Click "Ask SamarthVaani"
3. **Expected:** Answer with sources in ~5-10 seconds

**Success criteria:**
- Answer appears
- Sources shown (e.g., "RPWD Act 2016")
- No errors

#### Test 2: Text Query (Hindi) ✅
1. Select Input Language: "Hindi"
2. Type: "विकलांग व्यक्तियों के लिए रोजगार के अधिकार क्या हैं?"
3. Click "Ask SamarthVaani"
4. **Expected:** English answer (or Hindi if Output Language = Hindi)

**Success criteria:**
- Translation works
- Answer appears
- Sources shown

#### Test 3: Voice Input ✅
1. Click microphone icon
2. Speak: "What is RPWD Act?"
3. Click "Ask SamarthVaani"
4. **Expected:** Transcription + answer

**Success criteria:**
- Audio recorded
- Transcription shown
- Answer appears

#### Test 4: Voice Output ✅
1. Enable "🔊 Enable voice output"
2. Type any question
3. Click "Ask SamarthVaani"
4. **Expected:** Text answer + audio player

**Success criteria:**
- Text answer appears
- Audio player appears
- Audio plays

---

## 🚨 COMMON ISSUES & FIXES

### Issue 1: "RAG services unavailable"
**Cause:** Resources not added in UI  
**Fix:** Add Vector Search Index + Serving Endpoint in Resources tab

### Issue 2: "No API found"
**Cause:** Gradio API schema bug  
**Fix:** Already fixed in current app_voice.py

### Issue 3: "Voice input requires Sarvam API"
**Cause:** Sarvam API keys not loaded  
**Fix:** Check app.yaml has correct keys

### Issue 4: Empty/no answer
**Cause:** Vector Search returns no results  
**Fix:** Check if index has data, try different question

### Issue 5: "Permission denied"
**Cause:** Missing catalog access  
**Fix:** Add catalog resource in Resources tab

---

## 📊 EXPECTED BEHAVIOR MATRIX

 Feature | Resources Required | Expected Output | Failure Mode |
---------|-------------------|-----------------|--------------|
 Text query (English) | VS Index + LLM | Answer with sources | "RAG services unavailable" |
 Text query (Hindi/other) | VS Index + LLM + Sarvam keys | Translated answer | Falls back to English |
 Voice input | VS Index + LLM + Sarvam STT | Transcription + answer | "Voice input requires Sarvam API" |
 Voice output | Sarvam TTS key | Audio player | Silent failure (text still works) |
 11 languages | Sarvam keys | Multi-language I/O | English only |

---

## ✅ FINAL PRE-DEPLOYMENT CHECKLIST

Before clicking "Deploy":

- [x] app_voice.py has API schema fix
- [x] app.yaml has Sarvam API keys
- [x] requirements.txt is minimal (5 packages)
- [ ] **Resources added in Databricks Apps UI** ⚠️ MUST DO
  - [ ] Vector Search Index: samarthvaani.gold.rpwd_chunks_index
  - [ ] Serving Endpoint: databricks-meta-llama-3-3-70b-instruct
  - [ ] Catalog: samarthvaani (optional)

After clicking "Deploy":

1. Wait 2-3 minutes for startup
2. Check logs for "✅ Connected to index"
3. Check logs for "✅ Gradio server started"
4. Test public URL
5. Run Test 1 (English text query)

---

## 🎯 SUCCESS CRITERIA

**Deployment successful when:**
- ✅ Public URL loads
- ✅ Interface appears
- ✅ Button clicks work (no "No API found")
- ✅ Text queries return answers
- ✅ Sources are cited
- ✅ No error messages in logs

**Full features working when:**
- ✅ All Resources added
- ✅ Multi-language queries work
- ✅ Voice input works
- ✅ Voice output works
- ✅ All 11 languages supported

---

**Deploy now and check the Resources tab!** 🚀
