#!/usr/bin/env python3
"""
SamarthVaani Voice-Enabled Multilingual RAG Chatbot
Databricks Apps Deployment - Fixed for Dynamic Port Configuration
"""
import gradio as gr
import sys
import os
import traceback
from typing import Tuple, Optional

print("="*80)
print("🚀 SAMARTHVAANI VOICE-ENABLED CHATBOT STARTING")
print("="*80)

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Step 1: Import Vector Search and Databricks SDK
try:
    print("📦 Importing Databricks components...")
    from databricks.vector_search.client import VectorSearchClient
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.serving import ChatMessage, ChatMessageRole
    print("✅ Databricks SDK imported")
except Exception as e:
    print(f"❌ Databricks import failed: {e}")
    VectorSearchClient = None
    WorkspaceClient = None

# Step 2: Import sarvam_code (voice + translation)
try:
    print("📦 Importing sarvam_code (STT/TTS/Translation)...")
    from sarvam_code import process_input, process_output
    from sarvam_code.config import SUPPORTED_LANGUAGES
    SARVAM_AVAILABLE = True
    print(f"✅ Sarvam code imported - {len(SUPPORTED_LANGUAGES)} languages supported")
except Exception as e:
    print(f"⚠️  Sarvam code not available: {e}")
    SARVAM_AVAILABLE = False
    SUPPORTED_LANGUAGES = {
        "en-IN": "English",
        "hi-IN": "Hindi (हिंदी)",
    }

# Configuration
ENDPOINT_NAME = "samarthvaani_vs_endpoint"
INDEX_NAME = "samarthvaani.gold.rpwd_chunks_index"
LLM_MODEL = "databricks-meta-llama-3-3-70b-instruct"

# Initialize clients
vsc_client = None
ws_client = None
vs_index = None

# Initialize Workspace Client first (provides auth for Vector Search)
if WorkspaceClient:
    try:
        print("🔗 Initializing Workspace client...")
        ws_client = WorkspaceClient()
        print("✅ Workspace client initialized")
    except Exception as e:
        print(f"❌ Workspace connection failed: {e}")

# Initialize Vector Search using Workspace client's auth
if VectorSearchClient and ws_client:
    try:
        print(f"🔗 Connecting to Vector Search: {ENDPOINT_NAME}")
        vsc_client = VectorSearchClient(
            workspace_url=ws_client.config.host,
            service_principal_client_id=ws_client.config.client_id,
            service_principal_client_secret=ws_client.config.client_secret,
            disable_notice=True
        )
        vs_index = vsc_client.get_index(endpoint_name=ENDPOINT_NAME, index_name=INDEX_NAME)
        print(f"✅ Connected to index: {INDEX_NAME}")
    except Exception as e:
        print(f"❌ Vector Search connection failed: {e}")

# =============================================================================
# RAG FUNCTIONS
# =============================================================================

def retrieve_context(query: str, top_k: int = 3):
    """Retrieve from Vector Search."""
    if not vs_index:
        print("⚠️ Vector Search not available")
        return []
    
    try:
        results = vs_index.similarity_search(
            query_text=query,
            columns=["chunk_text", "topic", "source", "section_title"],
            num_results=top_k
        )
        
        chunks = []
        if results and 'result' in results and 'data_array' in results['result']:
            for row in results['result']['data_array']:
                chunks.append({
                    'text': row[0],
                    'topic': row[1],
                    'source': row[2],
                    'section': row[3]
                })
        print(f"✅ Retrieved {len(chunks)} chunks")
        return chunks
    except Exception as e:
        print(f"❌ Retrieval error: {e}")
        return []

def generate_answer(prompt: str):
    """Generate using LLM."""
    if not ws_client:
        return "⚠️ LLM service unavailable."
    
    try:
        response = ws_client.serving_endpoints.query(
            name=LLM_MODEL,
            messages=[
                ChatMessage(
                    role=ChatMessageRole.SYSTEM,
                    content="You are SamarthVaani, helping with RPWD Act 2016 and disability schemes in India."
                ),
                ChatMessage(
                    role=ChatMessageRole.USER,
                    content=prompt
                )
            ],
            max_tokens=700,
            temperature=0.1
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"❌ Generation error: {e}")
        return f"Error generating answer: {str(e)[:200]}"

def build_prompt(question: str, chunks: list) -> str:
    """Build RAG prompt."""
    if not chunks:
        return f"Question: {question}\n\nAnswer based on RPWD Act 2016."
    
    context = "\n\n".join([f"[{c['source']}]\n{c['text'][:500]}" for c in chunks[:3]])
    return f"""Context from official documents:
{context}

Question: {question}

Provide a helpful answer. Cite sources."""

# =============================================================================
# VOICE-ENABLED CHAT FUNCTIONS
# =============================================================================

def process_query(
    text_input: Optional[str],
    audio_input: Optional[str],
    input_language: str,
    output_language: str,
    enable_voice_output: bool
) -> Tuple[str, Optional[str]]:
    """Process query with text or voice input, return text and optionally audio."""
    print("\n" + "="*80)
    print("💬 NEW QUERY")
    print("="*80)
    
    if not vs_index or not ws_client:
        error_msg = "⚠️ RAG services unavailable. Please add resources in Databricks Apps UI."
        print(error_msg)
        return error_msg, None
    
    english_query = None
    original_query = None
    
    if audio_input:
        print(f"🎤 Audio input detected")
        print(f"   Language: {input_language}")
        
        if not SARVAM_AVAILABLE:
            return "⚠️ Voice input requires Sarvam API. Using text input only.", None
        
        try:
            with open(audio_input, 'rb') as f:
                audio_bytes = f.read()
            
            print(f"   Audio size: {len(audio_bytes):,} bytes")
            
            result = process_input(
                user_input=audio_bytes,
                input_mode="voice",
                input_lang=input_language,
                fast_mode=True,
                verbose=True
            )
            
            english_query = result.get("english_text")
            original_query = result.get("transcribed_text", english_query)
            
            print(f"✅ Transcribed: {original_query[:100]}...")
            print(f"✅ Translated to English: {english_query[:100]}...")
            
        except Exception as e:
            error_msg = f"❌ Audio processing error: {str(e)}"
            print(error_msg)
            traceback.print_exc()
            return error_msg, None
    
    elif text_input and text_input.strip():
        print(f"📝 Text input: {text_input}")
        original_query = text_input.strip()
        
        if input_language != "en-IN" and SARVAM_AVAILABLE:
            try:
                print(f"   Translating from {input_language} to English...")
                result = process_input(
                    user_input=original_query,
                    input_mode="text",
                    input_lang=input_language,
                    verbose=True
                )
                english_query = result.get("english_text")
                print(f"✅ Translated: {english_query}")
            except Exception as e:
                print(f"⚠️  Translation failed: {e}, using original text")
                english_query = original_query
        else:
            english_query = original_query
    
    else:
        return "Please provide text or voice input.", None
    
    print(f"\n🔍 Running RAG on: {english_query[:100]}...")
    
    chunks = retrieve_context(english_query, top_k=3)
    if not chunks:
        return "I couldn't find relevant information. Try rephrasing.", None
    
    prompt = build_prompt(english_query, chunks)
    english_answer = generate_answer(prompt)
    
    print(f"✅ Generated answer ({len(english_answer)} chars)")
    
    final_answer = english_answer
    
    if output_language != "en-IN" and SARVAM_AVAILABLE:
        try:
            print(f"\n🌐 Translating answer to {output_language}...")
            output_result = process_output(
                english_text=english_answer,
                output_mode="text",
                output_lang=output_language,
                verbose=True
            )
            final_answer = output_result.get("translated_text", english_answer)
            print(f"✅ Translated answer")
        except Exception as e:
            print(f"⚠️  Translation failed: {e}, returning English answer")
            final_answer = english_answer
    
    sources = "\n\n**📚 Sources:**\n" + "\n".join([
        f"• {c['source']} ({c['topic']})" for c in chunks[:3]
    ])
    
    final_answer += sources
    
    audio_path = None
    
    if enable_voice_output and SARVAM_AVAILABLE:
        try:
            print(f"\n🔊 Generating voice output in {output_language}...")
            voice_result = process_output(
                english_text=english_answer,
                output_mode="voice",
                output_lang=output_language,
                verbose=True
            )
            
            audio_bytes = voice_result.get("audio")
            if audio_bytes:
                audio_path = "/tmp/samarthvaani_response.wav"
                with open(audio_path, 'wb') as f:
                    f.write(audio_bytes)
                print(f"✅ Audio saved ({len(audio_bytes):,} bytes)")
            
        except Exception as e:
            print(f"⚠️  TTS failed: {e}")
    
    print("="*80)
    return final_answer, audio_path

# =============================================================================
# GRADIO UI
# =============================================================================

def create_ui():
    """Create Gradio interface."""
    
    lang_choices = [(name, code) for code, name in SUPPORTED_LANGUAGES.items()]
    
    # Use css to ensure proper rendering
    css = """
    .gradio-container {
        max-width: 100% !important;
    }
    """
    
    with gr.Blocks(theme=gr.themes.Soft(), title="SamarthVaani", css=css) as demo:
        gr.Markdown("""
        # 🤝 SamarthVaani - Voice-Enabled AI Assistant
        
        **AI assistant for India's 26 million Persons with Disabilities**
        
        Get information about RPWD Act 2016, government schemes, rights, and benefits in **11 Indian languages** with **voice or text input/output**.
        
        ---
        """)
        
        with gr.Row():
            with gr.Column(scale=1):
                gr.Markdown("### 📥 Input")
                
                input_lang = gr.Dropdown(
                    choices=lang_choices,
                    value="en-IN",
                    label="Input Language",
                    info="Select the language you'll use"
                )
                
                text_input = gr.Textbox(
                    label="Type your question",
                    placeholder="E.g., What are employment rights for disabled persons?",
                    lines=3
                )
                
                gr.Markdown("**OR**")
                
                audio_input = gr.Audio(
                    label="🎤 Speak your question",
                    type="filepath",
                    sources=["microphone"]
                )
                
                gr.Markdown("---")
                gr.Markdown("### 📤 Output")
                
                output_lang = gr.Dropdown(
                    choices=lang_choices,
                    value="en-IN",
                    label="Output Language",
                    info="Get answer in this language"
                )
                
                voice_output_toggle = gr.Checkbox(
                    label="🔊 Enable voice output (Text-to-Speech)",
                    value=False,
                    info="Hear the answer spoken"
                )
                
                submit_btn = gr.Button("🚀 Ask SamarthVaani", variant="primary", size="lg")
            
            with gr.Column(scale=2):
                gr.Markdown("### 💬 Answer")
                
                text_output = gr.Textbox(
                    label="Text Response",
                    lines=12,
                    show_copy_button=True
                )
                
                audio_output = gr.Audio(
                    label="🔊 Audio Response",
                    type="filepath",
                    visible=True
                )
        
        gr.Markdown("""
        ---
        ### 📚 Knowledge Base
        * 1,414 curated chunks from 8 official government documents (2,146 pages)
        * RPWD Act 2016, employment schemes, education benefits, healthcare, certification
        
        ### 🌐 Supported Languages (11)
        English • Hindi • Tamil • Telugu • Marathi • Bengali • Kannada • Malayalam • Gujarati • Punjabi • Odia
        
        ### 💡 Example Questions
        * **English:** What are the education rights for children with disabilities?
        * **Hindi:** विकलांग बच्चों के लिए शिक्षा के अधिकार क्या हैं?
        * **Tamil:** மாற்றுத்திறனாளி குழந்தைகளுக்கான கல்வி உரிமைகள் என்ன?
        """)
        
        submit_btn.click(
            fn=process_query,
            inputs=[text_input, audio_input, input_lang, output_lang, voice_output_toggle],
            outputs=[text_output, audio_output]
        )
    
    return demo

# =============================================================================
# MAIN - DATABRICKS APPS CONFIGURATION
# =============================================================================

if __name__ == "__main__":
    print("\n🎨 Creating Gradio interface...")
    demo = create_ui()
    
    print("✅ Interface created")
    print("\n🌐 Launching Gradio app...")
    
    # Get dynamic port from Databricks Apps (automatically set for Gradio)
    # GRADIO_SERVER_PORT and GRADIO_SERVER_NAME are automatically configured
    app_port = int(os.environ.get("DATABRICKS_APP_PORT", os.environ.get("GRADIO_SERVER_PORT", "8080")))
    app_host = os.environ.get("GRADIO_SERVER_NAME", "0.0.0.0")
    
    print(f"   Server: {app_host}:{app_port}")
    print(f"   Using Databricks-managed port configuration")
    print("="*80)
    
    # CRITICAL: Databricks Apps Configuration
    # Port is automatically managed by DATABRICKS_APP_PORT
    demo.queue()
    demo.launch(
        server_name=app_host,
        server_port=app_port,
        share=False,  # MUST be False for Databricks Apps
        show_error=True,
        show_api=False,
        allowed_paths=["/tmp"],
        inbrowser=False,
        prevent_thread_lock=False
    )
    
    print("\n✅ Gradio server started successfully!")
    print("   Databricks Apps will handle public URL routing")
    print("="*80)
