"""
Integrated Voice-Enabled Multilingual RAG Pipeline

This module orchestrates the complete pipeline:
1. Input Processing (sarvam_code): Any language/mode → English text
2. RAG Pipeline (notebooks 01-05): English query → English answer
3. Output Processing (sarvam_code): English answer → Any language/mode

Architecture:
- sarvam_code handles: Voice, Text, Translation (ANY language)
- RAG handles: English input → English output ONLY
- This module: Connects the two seamlessly

Usage:
    from integrated_pipeline import voice_rag_query
    
    result = voice_rag_query(
        user_input="विकलांग बच्चों के अधिकार क्या हैं?",
        input_mode="text",
        input_lang="hi-IN",
        output_mode="voice",
        output_lang="ta-IN",
        top_k=3
    )
"""

import sys
import os
import time
from typing import Union, Dict, Any, Optional

# Add parent directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import from sarvam_code (multilingual + voice processing)
try:
    from sarvam_code import process_input, process_output
    from sarvam_code.config import SUPPORTED_LANGUAGES
    SARVAM_AVAILABLE = True
except ImportError as e:
    print(f"⚠️  Warning: Could not import sarvam_code: {e}")
    SARVAM_AVAILABLE = False

# Import config - FIXED: Changed from 'config' to 'pipeline_config'
from pipeline_config import (
    DEFAULT_INPUT_MODE,
    DEFAULT_OUTPUT_MODE,
    DEFAULT_INPUT_LANG,
    DEFAULT_OUTPUT_LANG,
    DEFAULT_FAST_MODE,
    DEFAULT_TOP_K,
)


# ===========================================================================
# RAG Pipeline Functions
# ===========================================================================
# These will be imported from notebook 05 when running in Databricks
# For standalone Python, you need to define them or import from a module

# Placeholder for RAG functions (will be overridden by notebook)
_rag_pipeline_loaded = False
_rag_functions = {}

def load_rag_pipeline():
    """
    Load RAG pipeline functions from notebook 05.
    This should be called from a notebook using %run.
    """
    global _rag_pipeline_loaded, _rag_functions
    
    # Check if functions are available in global scope
    import __main__
    
    if hasattr(__main__, 'rag_pipeline'):
        _rag_functions['rag_pipeline'] = __main__.rag_pipeline
        _rag_pipeline_loaded = True
        print("✅ RAG pipeline functions loaded from notebook")
    else:
        print("⚠️  RAG pipeline functions not found in global scope")
        print("   Run this from a notebook after: %run ../05_Complete_RAG_Pipeline")


def _call_rag_pipeline(
    english_query: str,
    top_k: int = 3,
    topic_filter: Optional[str] = None,
    verbose: bool = False
) -> str:
    """
    Call the RAG pipeline with English input, get English output.
    
    Args:
        english_query: English text query
        top_k: Number of chunks to retrieve
        topic_filter: Optional topic filter
        verbose: Print debug info
        
    Returns:
        English text answer
    """
    if not _rag_pipeline_loaded:
        raise RuntimeError(
            "RAG pipeline not loaded. "
            "Call load_rag_pipeline() first or run from notebook after %run"
        )
    
    try:
        result = _rag_functions['rag_pipeline'](
            query=english_query,
            top_k=top_k,
            topic_filter=topic_filter,
            verbose=verbose
        )
        
        # Extract answer from result dictionary
        if isinstance(result, dict):
            return result.get('answer', str(result))
        else:
            return str(result)
            
    except Exception as e:
        raise RuntimeError(f"RAG pipeline error: {e}")


# ===========================================================================
# Main Integrated Pipeline Function
# ===========================================================================

def voice_rag_query(
    user_input: Union[str, bytes],
    input_mode: str = DEFAULT_INPUT_MODE,
    input_lang: str = DEFAULT_INPUT_LANG,
    output_mode: str = DEFAULT_OUTPUT_MODE,
    output_lang: str = DEFAULT_OUTPUT_LANG,
    fast_mode: bool = DEFAULT_FAST_MODE,
    top_k: int = DEFAULT_TOP_K,
    topic_filter: Optional[str] = None,
    verbose: bool = False,
    return_metadata: bool = True
) -> Dict[str, Any]:
    """
    Complete voice-enabled multilingual RAG query pipeline.
    
    This function orchestrates:
    1. Input processing (sarvam_code): user_input → English text
    2. RAG pipeline (notebooks): English query → English answer  
    3. Output processing (sarvam_code): English answer → desired format
    
    Args:
        user_input: Text string OR audio bytes (WAV format)
        input_mode: "text" or "voice" - how user provides input
        input_lang: Language code of input (e.g., "hi-IN", "ta-IN", "en-IN")
        output_mode: "text" or "voice" - how user wants response
        output_lang: Language code of output (e.g., "hi-IN", "ta-IN", "en-IN")
        fast_mode: If True, use fast STT translation; if False, use accurate mode
        top_k: Number of document chunks to retrieve from vector search
        topic_filter: Optional filter by topic (e.g., "education", "employment")
        verbose: If True, print progress information
        return_metadata: If True, include detailed metadata in response
        
    Returns:
        Dictionary with:
        {
            "answer": str,              # Final answer in output language
            "audio": bytes or None,     # Audio bytes if output_mode="voice"
            "query_original": str,      # Original query (for text input)
            "query_english": str,       # English translation of query
            "answer_english": str,      # English answer from RAG
            "input_mode": str,          # Echo of input_mode
            "output_mode": str,         # Echo of output_mode
            "input_lang": str,          # Echo of input_lang
            "output_lang": str,         # Echo of output_lang
            "latency": {                # Latency breakdown
                "input_processing": float,
                "rag_pipeline": float,
                "output_processing": float,
                "total": float
            }
        }
        
    Raises:
        RuntimeError: If RAG pipeline not loaded or components unavailable
        ValueError: If invalid parameters
        
    Examples:
        # Text to text (Hindi to English)
        >>> result = voice_rag_query(
        ...     user_input="विकलांग बच्चों के अधिकार?",
        ...     input_mode="text",
        ...     input_lang="hi-IN",
        ...     output_mode="text",
        ...     output_lang="en-IN"
        ... )
        
        # Voice to voice (Tamil to Telugu)
        >>> result = voice_rag_query(
        ...     user_input=audio_bytes,
        ...     input_mode="voice",
        ...     input_lang="ta-IN",
        ...     output_mode="voice",
        ...     output_lang="te-IN",
        ...     fast_mode=True
        ... )
    """
    
    # -----------------------------------------------------------------------
    # Validation
    # -----------------------------------------------------------------------
    if not SARVAM_AVAILABLE:
        raise RuntimeError("sarvam_code module not available")
    
    if not _rag_pipeline_loaded:
        raise RuntimeError(
            "RAG pipeline not loaded. Call load_rag_pipeline() first."
        )
    
    if input_mode not in ("text", "voice"):
        raise ValueError(f"input_mode must be 'text' or 'voice', got '{input_mode}'")
    
    if output_mode not in ("text", "voice"):
        raise ValueError(f"output_mode must be 'text' or 'voice', got '{output_mode}'")
    
    if input_lang not in SUPPORTED_LANGUAGES:
        raise ValueError(f"Unsupported input_lang: {input_lang}")
    
    if output_lang not in SUPPORTED_LANGUAGES:
        raise ValueError(f"Unsupported output_lang: {output_lang}")
    
    # -----------------------------------------------------------------------
    # Step 1: Input Processing (sarvam_code)
    # Convert any input (voice/text, any language) → English text
    # -----------------------------------------------------------------------
    if verbose:
        print("=" * 80)
        print("INTEGRATED VOICE RAG PIPELINE")
        print("=" * 80)
        print(f"\n📥 INPUT")
        print(f"   Mode: {input_mode}")
        print(f"   Language: {SUPPORTED_LANGUAGES[input_lang]} ({input_lang})")
        if input_mode == "text":
            print(f"   Query: {user_input[:100]}...")
        print()
    
    t_start = time.time()
    
    try:
        english_query = process_input(
            user_input=user_input,
            input_mode=input_mode,
            input_lang=input_lang,
            fast_mode=fast_mode
        )
        t_input = time.time() - t_start
        
        if verbose:
            print(f"✅ Input processed ({t_input:.2f}s)")
            print(f"   English query: {english_query[:100]}...")
            print()
            
    except Exception as e:
        raise RuntimeError(f"Input processing failed: {e}")
    
    # -----------------------------------------------------------------------
    # Step 2: RAG Pipeline (English → English)
    # -----------------------------------------------------------------------
    if verbose:
        print("🔍 RAG PIPELINE")
        print(f"   Retrieving top {top_k} chunks...")
    
    t_rag_start = time.time()
    
    try:
        english_answer = _call_rag_pipeline(
            english_query=english_query,
            top_k=top_k,
            topic_filter=topic_filter,
            verbose=verbose
        )
        t_rag = time.time() - t_rag_start
        
        if verbose:
            print(f"\n✅ RAG completed ({t_rag:.2f}s)")
            print(f"   English answer: {english_answer[:100]}...")
            print()
            
    except Exception as e:
        raise RuntimeError(f"RAG pipeline failed: {e}")
    
    # -----------------------------------------------------------------------
    # Step 3: Output Processing (sarvam_code)
    # Convert English answer → desired format (any language, text/voice)
    # -----------------------------------------------------------------------
    if verbose:
        print("📤 OUTPUT PROCESSING")
        print(f"   Mode: {output_mode}")
        print(f"   Language: {SUPPORTED_LANGUAGES[output_lang]} ({output_lang})")
    
    t_output_start = time.time()
    
    try:
        output_result = process_output(
            english_text=english_answer,
            output_mode=output_mode,
            output_lang=output_lang
        )
        t_output = time.time() - t_output_start
        
        if verbose:
            print(f"\n✅ Output processed ({t_output:.2f}s)")
            if output_mode == "text":
                print(f"   Final text: {output_result['text'][:100]}...")
            else:
                audio_size = len(output_result['audio']) if output_result['audio'] else 0
                print(f"   Audio generated: {audio_size} bytes")
            print()
            
    except Exception as e:
        raise RuntimeError(f"Output processing failed: {e}")
    
    # -----------------------------------------------------------------------
    # Prepare result
    # -----------------------------------------------------------------------
    t_total = time.time() - t_start
    
    result = {
        "answer": output_result["text"],
        "audio": output_result.get("audio"),
        "query_english": english_query,
        "answer_english": english_answer,
        "input_mode": input_mode,
        "output_mode": output_mode,
        "input_lang": input_lang,
        "output_lang": output_lang,
    }
    
    # Add original query for text inputs
    if input_mode == "text":
        result["query_original"] = user_input
    
    # Add metadata if requested
    if return_metadata:
        result["latency"] = {
            "input_processing": round(t_input, 3),
            "rag_pipeline": round(t_rag, 3),
            "output_processing": round(t_output, 3),
            "total": round(t_total, 3),
        }
        result["config"] = {
            "top_k": top_k,
            "topic_filter": topic_filter,
            "fast_mode": fast_mode,
        }
    
    if verbose:
        print("=" * 80)
        print(f"✅ COMPLETED in {t_total:.2f}s")
        print("=" * 80)
        print()
    
    return result


# ===========================================================================
# Helper Functions
# ===========================================================================

def format_result(result: Dict[str, Any], show_metadata: bool = True) -> str:
    """
    Format result dictionary as readable string.
    
    Args:
        result: Result from voice_rag_query()
        show_metadata: Include metadata in output
        
    Returns:
        Formatted string
    """
    lines = []
    lines.append("=" * 80)
    lines.append("RAG QUERY RESULT")
    lines.append("=" * 80)
    
    if "query_original" in result:
        lines.append(f"\n📝 Original Query:")
        lines.append(f"   {result['query_original']}")
    
    lines.append(f"\n🔤 English Query:")
    lines.append(f"   {result['query_english']}")
    
    lines.append(f"\n💬 Answer ({result['output_lang']}):")
    lines.append(f"   {result['answer']}")
    
    if result.get('audio'):
        lines.append(f"\n🔊 Audio: {len(result['audio'])} bytes")
    
    if show_metadata and 'latency' in result:
        lines.append(f"\n⏱️  Latency:")
        for step, duration in result['latency'].items():
            lines.append(f"   {step:20s}: {duration:.3f}s")
    
    lines.append("\n" + "=" * 80)
    
    return "\n".join(lines)


def save_audio(audio_bytes: bytes, filepath: str):
    """
    Save audio bytes to file.
    
    Args:
        audio_bytes: WAV audio bytes
        filepath: Output file path
    """
    with open(filepath, 'wb') as f:
        f.write(audio_bytes)
    print(f"✅ Audio saved to {filepath}")


# ===========================================================================
# Module Info
# ===========================================================================

__version__ = "1.0.0"
__all__ = [
    "voice_rag_query",
    "load_rag_pipeline",
    "format_result",
    "save_audio",
]

if __name__ == "__main__":
    print("=" * 80)
    print("INTEGRATED VOICE RAG PIPELINE")
    print("=" * 80)
    print(f"\nVersion: {__version__}")
    print(f"Sarvam Code Available: {SARVAM_AVAILABLE}")
    print(f"RAG Pipeline Loaded: {_rag_pipeline_loaded}")
    print("\nUsage:")
    print("  from integrated_pipeline import voice_rag_query, load_rag_pipeline")
    print("  load_rag_pipeline()  # After %run notebook")
    print("  result = voice_rag_query(...)")
    print("=" * 80)
