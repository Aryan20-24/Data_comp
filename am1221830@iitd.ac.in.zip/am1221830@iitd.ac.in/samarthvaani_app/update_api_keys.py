# API Key Update Script
# Run this after getting your keys from https://www.sarvam.ai/

import os

def update_api_keys(stt_key, tts_key):
    """
    Update the .env file with your Sarvam API keys.
    
    Args:
        stt_key: Your Saarika (Speech-to-Text) API key
        tts_key: Your Bulbul (Text-to-Speech) API key
    """
    env_path = "/Workspace/Users/am1221830@iitd.ac.in/samarthvaani_app/sarvam_code/.env"
    
    env_content = f"""# Sarvam AI API Keys
# Get your keys from: https://www.sarvam.ai/

# Speech-to-Text API Key (Saarika)
SARVAM_STT_API_KEY={stt_key}

# Text-to-Speech API Key (Bulbul)
SARVAM_TTS_API_KEY={tts_key}

# Instructions:
# 1. These keys enable voice features in SamarthVaani
# 2. Keep this file private - do NOT commit to version control
# 3. Restart the app after updating keys
"""
    
    with open(env_path, 'w') as f:
        f.write(env_content)
    
    print("✅ API keys updated successfully!")
    print(f"📁 File: {env_path}")
    print("\n🔄 Next step: Restart your SamarthVaani app to apply changes")

# USAGE EXAMPLE:
# Once you have your keys, uncomment and run:
# 
# update_api_keys(
#     stt_key="your_actual_saarika_key_here",
#     tts_key="your_actual_bulbul_key_here"
# )
