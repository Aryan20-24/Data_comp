#!/bin/bash
# SamarthVaani Deployment Script
# Prepares and deploys the complete application

set -e  # Exit on error

echo "================================================================================"
echo "🚀 SAMARTHVAANI DEPLOYMENT PREPARATION"
echo "================================================================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "📁 Working directory: $SCRIPT_DIR"
echo ""

# Step 1: Check Prerequisites
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📋 Step 1: Checking Prerequisites"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check for required files
echo "Checking required files..."
required_files=("app_full.py" "backend_api.py" "app.yaml" "requirements.txt")
for file in "${required_files[@]}"; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
    else
        echo -e "${RED}✗${NC} $file - MISSING!"
        exit 1
    fi
done

# Check for sarvam_code
if [ -d "sarvam_code" ]; then
    echo -e "${GREEN}✓${NC} sarvam_code/"
else
    echo -e "${YELLOW}⚠${NC} sarvam_code/ - Not found (voice features will be disabled)"
fi

echo ""

# Step 2: Build Frontend
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🎨 Step 2: Building Frontend"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

cd samarth-vaani-ui

if [ ! -f "package.json" ]; then
    echo -e "${RED}✗${NC} package.json not found in samarth-vaani-ui/"
    exit 1
fi

echo "📦 Installing dependencies..."
npm install

echo ""
echo "🔨 Building production bundle..."
npm run build

if [ -d "dist" ]; then
    echo -e "${GREEN}✓${NC} Frontend built successfully!"
    echo "   Build output: samarth-vaani-ui/dist/"
    
    # Show build stats
    du -sh dist/ | awk '{print "   Size: " $1}'
else
    echo -e "${RED}✗${NC} Build failed - dist/ folder not created"
    exit 1
fi

cd ..

echo ""

# Step 3: Verify Configuration
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "⚙️  Step 3: Verifying Configuration"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo "Checking app.yaml..."
if grep -q "app_full.py" app.yaml; then
    echo -e "${GREEN}✓${NC} app.yaml configured correctly (app_full.py)"
else
    echo -e "${YELLOW}⚠${NC} app.yaml not using app_full.py"
    echo "   Update command to: python app_full.py"
fi

echo ""
echo "Checking environment variables..."
if [ -f "sarvam_code/.env" ]; then
    echo -e "${GREEN}✓${NC} sarvam_code/.env exists"
    # Don't print the keys for security
    echo "   (API keys configured - not displayed for security)"
else
    echo -e "${YELLOW}⚠${NC} sarvam_code/.env not found"
    echo "   Voice features will be disabled"
    echo "   To enable: Copy .env.template and add your Sarvam API keys"
fi

echo ""

# Step 4: Deployment Summary
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ DEPLOYMENT PREPARATION COMPLETE"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📋 Summary:"
echo "   ✓ Backend: backend_api.py (FastAPI with 5 endpoints)"
echo "   ✓ Frontend: React built to samarth-vaani-ui/dist/"
echo "   ✓ Unified App: app_full.py"
echo "   ✓ Configuration: app.yaml"
echo ""
echo "🚀 NEXT STEPS:"
echo ""
echo "Deploy to Databricks Apps:"
echo ""
echo "   1. Go to: Databricks Workspace → Compute → Apps"
echo ""
echo "   2. Click: 'Create App' or 'Edit' existing app"
echo ""
echo "   3. Configure:"
echo "      • Name: samarthvaani-chatbot"
echo "      • Source code path: /Users/am1221830@iitd.ac.in/samarthvaani_app"
echo ""
echo "   4. Add Resources:"
echo "      • Vector Search Index: samarthvaani.gold.rpwd_chunks_index"
echo "      • Serving Endpoint: databricks-meta-llama-3-3-70b-instruct"
echo ""
echo "   5. Click: 'Start app'"
echo ""
echo "   6. Monitor logs for successful startup"
echo ""
echo "================================================================================"
