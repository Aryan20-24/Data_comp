#!/usr/bin/env python3
"""
SamarthVaani FastAPI Backend
Provides RAG, scheme matching, and application generation endpoints
"""
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Dict
import sys
import os
import traceback
import base64
from datetime import datetime

print("="*80)
print("🚀 SAMARTHVAANI FASTAPI BACKEND STARTING")
print("="*80)

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import Databricks components
try:
    print("📦 Importing Databricks components...")
    from databricks.vector_search.client import VectorSearchClient
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.serving import ChatMessage, ChatMessageRole
    print("✅ Databricks SDK imported")
except Exception as e:
    print(f"❌ Databricks import failed: {e}")
    VectorSearchClient = None
    WorkspaceClient = None

# Import sarvam_code (voice + translation)
try:
    print("📦 Importing sarvam_code (STT/TTS/Translation)...")
    from sarvam_code import process_input, process_output
    from sarvam_code.config import SUPPORTED_LANGUAGES
    SARVAM_AVAILABLE = True
    print(f"✅ Sarvam code imported - {len(SUPPORTED_LANGUAGES)} languages supported")
except Exception as e:
    print(f"⚠️  Sarvam code not available: {e}")
    SARVAM_AVAILABLE = False
    SUPPORTED_LANGUAGES = {
        "en-IN": "English",
        "hi-IN": "Hindi (हिंदी)",
    }

# Configuration
ENDPOINT_NAME = "samarthvaani_vs_endpoint"
INDEX_NAME = "samarthvaani.gold.rpwd_chunks_index"
LLM_MODEL = "databricks-meta-llama-3-3-70b-instruct"

# Initialize clients
vsc_client = None
ws_client = None
vs_index = None

if VectorSearchClient:
    try:
        print(f"🔗 Connecting to Vector Search: {ENDPOINT_NAME}")
        vsc_client = VectorSearchClient(disable_notice=True)
        vs_index = vsc_client.get_index(endpoint_name=ENDPOINT_NAME, index_name=INDEX_NAME)
        print(f"✅ Connected to index: {INDEX_NAME}")
    except Exception as e:
        print(f"❌ Vector Search connection failed: {e}")

if WorkspaceClient:
    try:
        print("🔗 Connecting to Workspace for LLM...")
        ws_client = WorkspaceClient()
        print("✅ Workspace client initialized")
    except Exception as e:
        print(f"❌ Workspace connection failed: {e}")

# Initialize FastAPI
app = FastAPI(title="SamarthVaani API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =============================================================================
# DATA MODELS
# =============================================================================

class QueryRequest(BaseModel):
    text: Optional[str] = None
    input_language: str = "en-IN"
    output_language: str = "en-IN"
    fast_mode: bool = True

class VoiceQueryRequest(BaseModel):
    audio_base64: str
    input_language: str = "en-IN"
    output_language: str = "en-IN"
    fast_mode: bool = True

class ApplicationRequest(BaseModel):
    scheme_name: str
    user_details: Dict
    language: str = "en-IN"

class SchemeQuery(BaseModel):
    query: Optional[str] = None
    disability_type: Optional[str] = None
    state: Optional[str] = None
    language: str = "en-IN"

# =============================================================================
# RAG FUNCTIONS
# =============================================================================

def retrieve_context(query: str, top_k: int = 5):
    """Retrieve from Vector Search."""
    if not vs_index:
        print("⚠️ Vector Search not available")
        return []
    
    try:
        results = vs_index.similarity_search(
            query_text=query,
            columns=["chunk_text", "topic", "source", "section_title"],
            num_results=top_k
        )
        
        chunks = []
        if results and 'result' in results and 'data_array' in results['result']:
            for row in results['result']['data_array']:
                chunks.append({
                    'text': row[0],
                    'topic': row[1],
                    'source': row[2],
                    'section': row[3]
                })
        print(f"✅ Retrieved {len(chunks)} chunks")
        return chunks
    except Exception as e:
        print(f"❌ Retrieval error: {e}")
        return []

def generate_answer(prompt: str, max_tokens: int = 700):
    """Generate using LLM."""
    if not ws_client:
        return "⚠️ LLM service unavailable."
    
    try:
        response = ws_client.serving_endpoints.query(
            name=LLM_MODEL,
            messages=[
                ChatMessage(
                    role=ChatMessageRole.SYSTEM,
                    content="You are SamarthVaani, an AI assistant helping persons with disabilities in India. You provide information about RPWD Act 2016, government schemes, rights, and benefits."
                ),
                ChatMessage(
                    role=ChatMessageRole.USER,
                    content=prompt
                )
            ],
            max_tokens=max_tokens,
            temperature=0.1
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"❌ Generation error: {e}")
        return f"Error generating answer: {str(e)[:200]}"

def build_prompt(question: str, chunks: list) -> str:
    """Build RAG prompt."""
    if not chunks:
        return f"Question: {question}\n\nAnswer based on RPWD Act 2016 and government schemes for persons with disabilities."
    
    context = "\n\n".join([f"[{c['source']}]\n{c['text'][:500]}" for c in chunks[:3]])
    return f"""Context from official documents:
{context}

Question: {question}

Provide a helpful, accurate answer based on the context. Cite sources."""

def detect_query_intent(query: str) -> str:
    """Detect if user wants information, schemes, or application."""
    query_lower = query.lower()
    
    # Application intent keywords
    if any(word in query_lower for word in ['apply', 'application', 'form', 'enroll', 'register', 'certificate']):
        return "application"
    
    # Scheme discovery keywords
    if any(word in query_lower for word in ['scheme', 'benefit', 'subsidy', 'eligible', 'qualify', 'programs']):
        return "schemes"
    
    # Default to information
    return "information"

# =============================================================================
# APPLICATION TEMPLATES
# =============================================================================

APPLICATION_TEMPLATES = {
    "disability_certificate": {
        "title": "Application for Disability Certificate",
        "authority": "Chief Medical Officer / District Medical Board",
        "template": """To,
{authority}
{district}
{state}

Subject: Application for Disability Certificate

Respected Sir/Madam,

I, {name}, {age} years old, resident of {address}, {district}, {state}, humbly submit that I am suffering from {disability_type} disability.

I request you to kindly issue me a Disability Certificate under the Rights of Persons with Disabilities Act, 2016, so that I may avail various benefits and schemes provided by the Government.

I have enclosed the following documents:
{documents}

Thanking you,

Date: {date}
Place: {place}

Yours faithfully,
{name}
{contact}"""
    },
    "udid_card": {
        "title": "Application for UDID Card",
        "authority": "UDID Portal (Online Application)",
        "template": """Application for Unique Disability ID (UDID) Card

Personal Details:
Name: {name}
Father's/Guardian's Name: {guardian_name}
Date of Birth: {dob}
Gender: {gender}
Address: {address}
District: {district}
State: {state}
Pin Code: {pincode}
Mobile: {contact}
Email: {email}

Disability Details:
Type of Disability: {disability_type}
Percentage of Disability: {percentage}
(As certified by Medical Authority)

Documents Attached:
{documents}

Declaration: I hereby declare that the information provided above is true to the best of my knowledge.

Date: {date}
Signature: {name}"""
    },
    "pension_scheme": {
        "title": "Application for Disability Pension",
        "authority": "District Social Welfare Officer",
        "template": """To,
The District Social Welfare Officer
{district}
{state}

Subject: Application for Disability Pension under {scheme_name}

Respected Sir/Madam,

I, {name}, {age} years old, holding Disability Certificate No. {cert_number}, with {disability_type} disability ({percentage}% disability), residing at {address}, request you to kindly enroll me in the Disability Pension Scheme.

I belong to {category} category and my family's annual income is Rs. {annual_income}.

Enclosed documents:
{documents}

I request you to process my application at the earliest.

Thanking you,

Date: {date}
Place: {place}

Yours faithfully,
{name}
{contact}"""
    },
    "employment_rights": {
        "title": "Application for Employment Rights/Accommodation",
        "authority": "Human Resources Department / Employer",
        "template": """To,
{employer_name}
{employer_address}

Subject: Request for Reasonable Accommodation under RPwD Act 2016

Respected Sir/Madam,

I, {name}, employee ID {emp_id}, working as {designation} in your esteemed organization, am a person with {disability_type} disability ({percentage}% as per disability certificate).

Under Section 20 of the Rights of Persons with Disabilities Act, 2016, I request the following reasonable accommodations to enable me to perform my duties effectively:

{accommodations}

I have attached my Disability Certificate and relevant medical documents for your reference.

I hope you will consider my request favorably.

Thanking you,

Date: {date}

Yours faithfully,
{name}
{contact}"""
    }
}

# =============================================================================
# API ENDPOINTS
# =============================================================================

@app.get("/")
async def root():
    """Health check endpoint."""
    return {
        "app": "SamarthVaani",
        "status": "running",
        "version": "1.0.0",
        "endpoints": {
            "query": "/api/query",
            "schemes": "/api/schemes",
            "generate_application": "/api/generate-application",
            "voice_query": "/api/voice-query",
            "supported_languages": "/api/languages"
        }
    }

@app.get("/api/languages")
async def get_languages():
    """Get supported languages."""
    return {
        "languages": SUPPORTED_LANGUAGES,
        "voice_available": SARVAM_AVAILABLE
    }

@app.post("/api/query")
async def process_query(request: QueryRequest):
    """
    Process text query with RAG pipeline.
    Returns answer with sources and intent detection.
    """
    try:
        if not request.text or not request.text.strip():
            raise HTTPException(status_code=400, detail="Text input is required")
        
        print(f"\n💬 Query: {request.text}")
        
        # Step 1: Translate to English if needed
        english_query = request.text
        if request.input_language != "en-IN" and SARVAM_AVAILABLE:
            try:
                result = process_input(
                    user_input=request.text,
                    input_mode="text",
                    input_lang=request.input_language,
                    verbose=False
                )
                english_query = result.get("english_text", request.text)
            except Exception as e:
                print(f"⚠️ Translation failed: {e}")
        
        # Step 2: Detect intent
        intent = detect_query_intent(english_query)
        print(f"🎯 Intent: {intent}")
        
        # Step 3: Retrieve context
        chunks = retrieve_context(english_query, top_k=5)
        
        # Step 4: Generate answer
        prompt = build_prompt(english_query, chunks)
        english_answer = generate_answer(prompt)
        
        # Step 5: Extract schemes if intent is schemes
        schemes = []
        if intent == "schemes":
            schemes = extract_schemes_from_chunks(chunks)
        
        # Step 6: Translate answer to output language
        final_answer = english_answer
        if request.output_language != "en-IN" and SARVAM_AVAILABLE:
            try:
                result = process_output(
                    english_text=english_answer,
                    output_mode="text",
                    output_lang=request.output_language,
                    verbose=False
                )
                final_answer = result.get("translated_text", english_answer)
            except Exception as e:
                print(f"⚠️ Translation failed: {e}")
        
        # Step 7: Format response
        sources = [{"source": c['source'], "topic": c['topic']} for c in chunks[:3]]
        
        return {
            "answer": final_answer,
            "sources": sources,
            "intent": intent,
            "schemes": schemes,
            "language": request.output_language
        }
    
    except Exception as e:
        print(f"❌ Error: {e}")
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/voice-query")
async def process_voice_query(
    audio: UploadFile = File(...),
    input_language: str = Form("en-IN"),
    output_language: str = Form("en-IN"),
    fast_mode: bool = Form(True)
):
    """
    Process voice query with STT, RAG, and TTS.
    """
    try:
        if not SARVAM_AVAILABLE:
            raise HTTPException(status_code=503, detail="Voice processing unavailable")
        
        # Read audio
        audio_bytes = await audio.read()
        print(f"🎤 Audio received: {len(audio_bytes)} bytes")
        
        # Step 1: STT + Translation
        result = process_input(
            user_input=audio_bytes,
            input_mode="voice",
            input_lang=input_language,
            fast_mode=fast_mode,
            verbose=True
        )
        
        english_query = result.get("english_text")
        transcribed = result.get("transcribed_text", english_query)
        
        # Step 2: RAG pipeline
        intent = detect_query_intent(english_query)
        chunks = retrieve_context(english_query, top_k=5)
        prompt = build_prompt(english_query, chunks)
        english_answer = generate_answer(prompt)
        
        # Step 3: Translation + TTS
        voice_result = process_output(
            english_text=english_answer,
            output_mode="voice",
            output_lang=output_language,
            verbose=True
        )
        
        audio_bytes = voice_result.get("audio")
        translated_answer = voice_result.get("translated_text", english_answer)
        
        # Convert audio to base64
        audio_base64 = base64.b64encode(audio_bytes).decode() if audio_bytes else None
        
        sources = [{"source": c['source'], "topic": c['topic']} for c in chunks[:3]]
        
        return {
            "transcribed": transcribed,
            "answer": translated_answer,
            "audio_base64": audio_base64,
            "sources": sources,
            "intent": intent,
            "language": output_language
        }
    
    except Exception as e:
        print(f"❌ Voice processing error: {e}")
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/schemes")
async def discover_schemes(request: SchemeQuery):
    """
    Discover relevant schemes based on query, disability type, or state.
    """
    try:
        # Build search query
        search_terms = []
        if request.query:
            search_terms.append(request.query)
        if request.disability_type:
            search_terms.append(f"schemes for {request.disability_type} disability")
        if request.state:
            search_terms.append(f"schemes in {request.state}")
        
        query = " ".join(search_terms) if search_terms else "government schemes for persons with disabilities"
        
        print(f"🔍 Scheme search: {query}")
        
        # Retrieve relevant chunks
        chunks = retrieve_context(query, top_k=10)
        
        # Extract and deduplicate schemes
        schemes = extract_schemes_from_chunks(chunks)
        
        return {
            "schemes": schemes,
            "count": len(schemes),
            "language": request.language
        }
    
    except Exception as e:
        print(f"❌ Scheme discovery error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/generate-application")
async def generate_application(request: ApplicationRequest):
    """
    Generate application letter/form for a specific scheme or right.
    """
    try:
        print(f"📄 Generating application for: {request.scheme_name}")
        
        # Determine template based on scheme name
        template_key = determine_template(request.scheme_name)
        
        if template_key not in APPLICATION_TEMPLATES:
            # Generate custom application using LLM
            return generate_custom_application(request.scheme_name, request.user_details, request.language)
        
        template_info = APPLICATION_TEMPLATES[template_key]
        
        # Fill template with user details
        filled_application = fill_template(
            template_info["template"],
            request.user_details,
            request.scheme_name
        )
        
        # Translate if needed
        if request.language != "en-IN" and SARVAM_AVAILABLE:
            try:
                result = process_output(
                    english_text=filled_application,
                    output_mode="text",
                    output_lang=request.language,
                    verbose=False
                )
                filled_application = result.get("translated_text", filled_application)
            except Exception as e:
                print(f"⚠️ Translation failed: {e}")
        
        return {
            "title": template_info["title"],
            "authority": template_info["authority"],
            "application_text": filled_application,
            "language": request.language,
            "required_documents": get_required_documents(template_key)
        }
    
    except Exception as e:
        print(f"❌ Application generation error: {e}")
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def extract_schemes_from_chunks(chunks: List[Dict]) -> List[Dict]:
    """Extract scheme information from retrieved chunks."""
    schemes = []
    seen = set()
    
    # Common scheme keywords
    scheme_keywords = ['scheme', 'abhiyan', 'yojana', 'card', 'pension', 'subsidy', 'benefit']
    
    for chunk in chunks:
        text = chunk['text'].lower()
        
        # Check if chunk mentions a scheme
        if any(keyword in text for keyword in scheme_keywords):
            # Extract scheme name (simplified - could use NER)
            lines = chunk['text'].split('\n')
            for line in lines:
                line_lower = line.lower()
                if any(keyword in line_lower for keyword in scheme_keywords) and len(line) < 200:
                    scheme_name = line.strip()
                    if scheme_name and scheme_name not in seen and len(scheme_name) > 10:
                        schemes.append({
                            "name": scheme_name,
                            "description": chunk['text'][:200],
                            "source": chunk['source'],
                            "topic": chunk['topic']
                        })
                        seen.add(scheme_name)
                        break
    
    return schemes[:5]  # Return top 5

def determine_template(scheme_name: str) -> str:
    """Determine which template to use based on scheme name."""
    scheme_lower = scheme_name.lower()
    
    if 'udid' in scheme_lower or 'unique disability' in scheme_lower:
        return "udid_card"
    elif 'pension' in scheme_lower:
        return "pension_scheme"
    elif 'certificate' in scheme_lower:
        return "disability_certificate"
    elif 'employment' in scheme_lower or 'job' in scheme_lower:
        return "employment_rights"
    else:
        return "disability_certificate"  # Default

def fill_template(template: str, user_details: Dict, scheme_name: str) -> str:
    """Fill application template with user details."""
    # Set defaults
    defaults = {
        "name": user_details.get("name", "[Your Name]"),
        "age": user_details.get("age", "[Your Age]"),
        "address": user_details.get("address", "[Your Address]"),
        "district": user_details.get("district", "[District]"),
        "state": user_details.get("state", "[State]"),
        "contact": user_details.get("contact", "[Mobile Number]"),
        "email": user_details.get("email", "[Email]"),
        "disability_type": user_details.get("disability_type", "[Disability Type]"),
        "percentage": user_details.get("percentage", "[Percentage]"),
        "date": datetime.now().strftime("%d-%m-%Y"),
        "place": user_details.get("place", user_details.get("district", "[Place]")),
        "documents": user_details.get("documents", "1. Disability Certificate\n2. Aadhaar Card\n3. Passport size photograph\n4. Address proof"),
        "authority": user_details.get("authority", "Chief Medical Officer"),
        "scheme_name": scheme_name,
        "cert_number": user_details.get("cert_number", "[Certificate Number]"),
        "category": user_details.get("category", "[Category - SC/ST/OBC/General]"),
        "annual_income": user_details.get("annual_income", "[Annual Income]"),
        "guardian_name": user_details.get("guardian_name", "[Father's/Guardian's Name]"),
        "dob": user_details.get("dob", "[Date of Birth]"),
        "gender": user_details.get("gender", "[Gender]"),
        "pincode": user_details.get("pincode", "[Pin Code]"),
        "employer_name": user_details.get("employer_name", "[Employer Name]"),
        "employer_address": user_details.get("employer_address", "[Employer Address]"),
        "emp_id": user_details.get("emp_id", "[Employee ID]"),
        "designation": user_details.get("designation", "[Designation]"),
        "accommodations": user_details.get("accommodations", "[List of accommodations needed]")
    }
    
    try:
        return template.format(**defaults)
    except KeyError as e:
        print(f"⚠️ Missing template key: {e}")
        return template

def generate_custom_application(scheme_name: str, user_details: Dict, language: str) -> Dict:
    """Generate custom application using LLM when no template exists."""
    prompt = f"""Generate a formal application letter for the following:

Scheme: {scheme_name}
Applicant Details:
{chr(10).join([f'{k}: {v}' for k, v in user_details.items()])}

Create a professional application letter in proper format with:
1. Appropriate addressing to the authority
2. Subject line
3. Body with relevant details
4. List of documents to be attached
5. Formal closing

Keep it concise and formal."""
    
    application_text = generate_answer(prompt, max_tokens=1000)
    
    return {
        "title": f"Application for {scheme_name}",
        "authority": "Concerned Authority",
        "application_text": application_text,
        "language": language,
        "required_documents": ["Disability Certificate", "Aadhaar Card", "Passport photograph", "Address proof"]
    }

def get_required_documents(template_key: str) -> List[str]:
    """Get list of required documents for each template type."""
    docs_map = {
        "disability_certificate": [
            "Recent passport size photographs",
            "Aadhaar Card copy",
            "Address proof",
            "Medical reports/prescriptions",
            "Identity proof"
        ],
        "udid_card": [
            "Disability Certificate",
            "Aadhaar Card",
            "Passport size photograph",
            "Address proof",
            "Date of Birth proof"
        ],
        "pension_scheme": [
            "Disability Certificate",
            "Aadhaar Card",
            "Bank passbook/cancelled cheque",
            "Income certificate",
            "Caste certificate (if applicable)",
            "Address proof"
        ],
        "employment_rights": [
            "Disability Certificate",
            "Medical reports",
            "Employee ID proof",
            "Relevant medical recommendations"
        ]
    }
    return docs_map.get(template_key, ["Disability Certificate", "Aadhaar Card", "Relevant documents"])

# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    print("="*80)
    print("🚀 Starting SamarthVaani FastAPI Backend on port 8000")
    print("="*80)
    uvicorn.run(app, host="0.0.0.0", port=8000)
