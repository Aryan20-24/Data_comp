# 📝 .ENV FILE EDITING - ONE PAGE GUIDE

## 🎯 File Location
```
/Users/am1221830@iitd.ac.in/samarthvaani_app/sarvam_code/.env
```

## 🔧 Quick Steps
1. **Navigate**: Workspace → Users → am1221830@iitd.ac.in → samarthvaani_app → sarvam_code
2. **Open**: Click on `.env` file
3. **Edit**: Replace placeholders with your keys
4. **Save**: Ctrl+S (Windows/Linux) or Cmd+S (Mac)
5. **Deploy**: Stop and start your app

## 📋 Format
```bash
SARVAM_STT_API_KEY=your_actual_saarika_key
SARVAM_TTS_API_KEY=your_actual_bulbul_key
```

**NO quotes, NO spaces, just the key after =**

## ⚠️ Common Mistakes
- ❌ Editing `.env.template` instead of `.env`
- ❌ Adding quotes: `="key"`
- ❌ Adding spaces: ` = key`
- ❌ Forgetting to save
- ❌ Not restarting app

## ✅ Success Check
After restarting app, logs should show:
```
✅ Sarvam code imported - 11 languages supported
```
