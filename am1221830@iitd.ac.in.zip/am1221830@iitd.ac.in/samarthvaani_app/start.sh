#!/bin/bash
echo "Starting SamarthVaani..."
python app_production.py
