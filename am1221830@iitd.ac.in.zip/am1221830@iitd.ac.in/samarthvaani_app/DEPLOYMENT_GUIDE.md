# SamarthVaani Voice-Enabled Deployment Guide

## 🎉 Integration Complete!

Your SamarthVaani app has been successfully enhanced with:
- 🎤 Voice input (microphone recording)
- 🌐 11 Indian languages support
- 🔊 Voice output (Text-to-Speech)
- 💬 Enhanced multilingual UI

---

## 🏗️ Architecture

```
User → Voice/Text Input (11 languages)
     ↓
  STT + Translation (Sarvam API + IndicTrans2)
     ↓
  English Text Query
     ↓
  RAG Pipeline (Vector Search + Llama 3.3 70B)
     ↓
  English Answer
     ↓
  Translation + TTS
     ↓
User ← Text + Audio Output (any language)
```

---

## 🚀 DEPLOYMENT STEPS

### Step 1: (Optional) Add API Keys for Voice Features

**If you want voice input/output:**
1. Get API keys from [Sarvam AI](https://www.sarvam.ai/)
2. Edit file: `samarthvaani_app/sarvam_code/.env`
3. Add your keys:
   ```
   SARVAM_STT_API_KEY=your_actual_key_here
   SARVAM_TTS_API_KEY=your_actual_key_here
   ```

**To run in text-only mode:**
- Skip this step
- App will still support 11 languages via text translation
- No voice features

### Step 2: Go to Your App

1. Navigate to: **Compute → Apps**
2. Find: **samarthvaani-chatbot**
3. Click: **"Stop app"** (if running)

### Step 3: Verify Configuration

1. Click: **"Edit"**
2. **Step 1: Edit metadata**
   - Name: samarthvaani-chatbot
   - Description: Voice-enabled AI assistant for disability rights
   
3. **Step 2: Configure Git repository**
   - Source code path: `/Users/am1221830@iitd.ac.in/samarthvaani_app`
   - Click **"Next"**

4. **Step 3: Configure resources**
   - Ensure these are added:
     ✅ **Vector Search Index**: `samarthvaani.gold.rpwd_chunks_index`
     ✅ **Serving Endpoint**: `databricks-meta-llama-3-3-70b-instruct`

### Step 4: Start the App

1. Click: **"Start app"**
2. Wait: **5-10 minutes** (first time)
   - PyTorch and transformers download (~1-2 GB)
   - IndicTrans2 models download (~2 GB)
   - Subsequent starts will be faster (~2-3 minutes)

### Step 5: Monitor Logs

While the app is starting, click **"Logs"** tab to monitor:

**Look for these success messages:**
```
✅ SAMARTHVAANI VOICE-ENABLED CHATBOT STARTING
✅ Databricks SDK imported
✅ Sarvam code imported - 11 languages supported
✅ Connected to index: samarthvaani.gold.rpwd_chunks_index
✅ Workspace client initialized
✅ Interface created
✅ Launching on 0.0.0.0:8080
```

**If you see warnings (still works in text-only mode):**
```
⚠️  Sarvam code not available: [error message]
```

### Step 6: Test the App

Once running, click the app URL and test:

**Test 1: Text Input (English)**
- Input: "What are employment rights for disabled persons?"
- Select: Input Language = English, Output Language = English
- Expected: Answer with source citations

**Test 2: Text Input (Hindi → Tamil)**
- Input: "विकलांग बच्चों के अधिकार क्या हैं?"
- Select: Input = Hindi, Output = Tamil
- Expected: Tamil text answer

**Test 3: Voice Input (if API keys added)**
- Click microphone icon
- Speak in any language
- Select correct input language
- Expected: Transcription → Answer

**Test 4: Voice Output (if API keys added)**
- Ask any question
- Toggle: "Enable voice output"
- Expected: Text answer + audio player

---

## 🌐 Supported Languages (11)

| Code | Language | Native |
|------|----------|--------|
| en-IN | English | English |
| hi-IN | Hindi | हिंदी |
| ta-IN | Tamil | தமிழ் |
| te-IN | Telugu | తెలుగు |
| mr-IN | Marathi | मराठी |
| bn-IN | Bengali | বাংলা |
| kn-IN | Kannada | ಕನ್ನಡ |
| ml-IN | Malayalam | മലയാളം |
| gu-IN | Gujarati | ગુજરાતી |
| pa-IN | Punjabi | ਪੰਜਾਬੀ |
| od-IN | Odia | ଓଡ଼ିଆ |

---

## 🎯 Features Summary

### ✅ What's New

1. **Voice Input**
   - Microphone recording
   - Speech-to-Text (Sarvam Saarika)
   - Works with all 11 languages

2. **Multilingual Text**
   - Input in any of 11 languages
   - Output in any of 11 languages
   - Translation via IndicTrans2

3. **Voice Output**
   - Optional Text-to-Speech
   - Uses Sarvam Bulbul
   - Audio playback in browser

4. **Enhanced UI**
   - Language selection dropdowns
   - Voice output toggle
   - Audio player for responses

5. **Robust Design**
   - Works without API keys (text-only)
   - Graceful error handling
   - Detailed logging

### ✅ What's Preserved

1. **RAG Pipeline**
   - 1,414 chunks from 8 government documents
   - Vector Search with BGE embeddings
   - Llama 3.3 70B for generation
   - Source citations

2. **Knowledge Base**
   - RPWD Act 2016
   - Employment schemes
   - Education rights
   - Healthcare benefits
   - Disability certification

---

## 🔧 Two Operating Modes

### Mode 1: Text-Only (No API Keys)
**What Works:**
- ✅ Text input in all 11 languages
- ✅ Text output in all 11 languages
- ✅ Translation via IndicTrans2
- ✅ RAG pipeline with source citations
- ❌ No voice input
- ❌ No voice output

### Mode 2: Full Voice-Enabled (With API Keys)
**What Works:**
- ✅ Everything from Mode 1
- ✅ Voice input via microphone
- ✅ Voice output with TTS
- ✅ Speech-to-Text in 11 languages

---

## ⚠️ Troubleshooting

### App Takes Long to Start
**Cause:** First-time package and model downloads
**Solution:** Wait 5-10 minutes. Subsequent starts are faster.

### "App Not Available" Error
**Check:**
1. Resources added (Vector Search + Serving Endpoint)?
2. Logs show any error messages?
3. Try stopping and starting again

### Voice Features Not Working
**Check:**
1. API keys added to `sarvam_code/.env`?
2. Logs show "Sarvam code imported"?
3. Browser allows microphone access?

### Translation is Slow
**Cause:** IndicTrans2 models download on first use (~2GB)
**Solution:** Wait once. Models are cached afterward.

### "Vector Search index not found"
**Solution:** Ensure resource is added:
- Go to: Edit → Configure resources
- Add: Vector Search Index
- Select: samarthvaani.gold.rpwd_chunks_index

### "LLM service unavailable"
**Solution:** Ensure serving endpoint is added:
- Go to: Edit → Configure resources
- Add: Serving Endpoint
- Select: databricks-meta-llama-3-3-70b-instruct

---

## 📊 Files Overview

**Main Application:**
- `app_voice.py` - Voice-enabled Gradio app (14.9 KB)
- `app.yaml` - App configuration
- `requirements.txt` - Python dependencies

**Voice & Translation:**
- `sarvam_code/` - STT/TTS/Translation modules
  - `stt.py` - Speech-to-Text
  - `tts.py` - Text-to-Speech
  - `translate.py` - IndicTrans2 translation
  - `input_processor.py` - Input handling
  - `output_processor.py` - Output handling

**RAG Pipeline:**
- `integrated_pipeline.py` - Orchestration layer
- `pipeline_config.py` - Configuration

**Configuration:**
- `sarvam_code/.env` - API keys (add yours here)
- `.env.template` - Template for API keys
- `API_KEYS_README.md` - Setup instructions

---

## 🎓 Example Workflows

### Workflow 1: English Text → English Text
1. Type: "What are education rights for disabled children?"
2. Input Language: English
3. Output Language: English
4. Result: English answer with sources

### Workflow 2: Hindi Voice → Hindi Voice
1. Click microphone
2. Speak in Hindi: "विकलांग बच्चों के अधिकार क्या हैं?"
3. Input Language: Hindi
4. Output Language: Hindi
5. Toggle: "Enable voice output"
6. Result: Hindi text + Hindi audio

### Workflow 3: Tamil Text → Telugu Text
1. Type: "மாற்றுத்திறனாளிகளுக்கான வேலை திட்டங்கள் என்ன?"
2. Input Language: Tamil
3. Output Language: Telugu
4. Result: Telugu text answer

### Workflow 4: Bengali Voice → English Text
1. Click microphone
2. Speak in Bengali
3. Input Language: Bengali
4. Output Language: English
5. Result: English text answer

---

## 📞 Support

**App Not Working?**
1. Check logs for error messages
2. Verify resources are added
3. Try text-only mode first
4. Add API keys for voice features

**Need Help?**
- Review this guide
- Check `API_KEYS_README.md`
- Monitor app logs for diagnostics

---

## 🎉 You're Ready!

Go to: **Compute → Apps → samarthvaani-chatbot → Edit → Start app**

Your voice-enabled multilingual RAG chatbot is ready to serve India's 26 million Persons with Disabilities! 🤝
