# SamarthVaani - Backend Integration Guide

## 📋 Overview

This guide documents the integration of the SamarthVaani React UI with the FastAPI backend, including the new **Application Generation** feature.

## 🏗️ Architecture

```
┌──────────────────────────────────────────────────────────┐
│                     React UI (Vite + TypeScript)          │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────────┐  │
│  │ InputConsole │  │  OutputArea  │  │ Application    │  │
│  │ (Voice/Text) │  │  (Schemes)   │  │ Generator      │  │
│  └──────────────┘  └──────────────┘  └────────────────┘  │
└────────────────┬─────────────────────────────────────────┘
                 │
                 │ HTTP/REST API
                 ▼
┌──────────────────────────────────────────────────────────┐
│              FastAPI Backend (backend_api.py)            │
│                                                          │
│  ┌─────────────────────────────────────────────────┐   │
│  │ Endpoints:                                       │   │
│  │  • POST /api/query          - Text RAG          │   │
│  │  • POST /api/voice-query    - Voice RAG         │   │
│  │  • POST /api/schemes        - Scheme Discovery  │   │
│  │  • POST /api/generate-app   - Application Gen   │   │
│  └─────────────────────────────────────────────────┘   │
└────────────────┬─────────────────────────────────────────┘
                 │
   ┌─────────────┼─────────────────────────┐
   │             │                         │
   ▼             ▼                         ▼
┌────────┐  ┌──────────┐  ┌─────────────────────────┐
│ Vector │  │   LLM    │  │  Sarvam API (Optional)  │
│ Search │  │ Llama 3.3│  │  • STT (Speech to Text) │
│  Index │  │   70B    │  │  • TTS (Text to Speech) │
└────────┘  └──────────┘  └─────────────────────────┘
```

## 📁 Project Structure

```
samarthvaani_app/
├── backend_api.py              ← 🆕 FastAPI backend with application generation
├── app_voice.py                ← Gradio UI (legacy, can be replaced)
├── integrated_pipeline.py      ← RAG pipeline logic
├── pipeline_config.py          ← Configuration
├── requirements.txt            ← Python dependencies (updated with FastAPI)
├── app.yaml                    ← Databricks App config
│
├── sarvam_code/                ← Voice & Translation modules
│   ├── stt.py                  ← Speech-to-Text
│   ├── tts.py                  ← Text-to-Speech
│   ├── translate.py            ← Translation (IndicTrans2)
│   ├── input_processor.py
│   ├── output_processor.py
│   ├── config.py
│   └── .env                    ← API keys
│
└── samarth-vaani-ui/           ← 🆕 React UI (to be copied from parent folder)
    ├── src/
    │   ├── components/
    │   │   └── samarth/
    │   │       ├── InputConsole.tsx
    │   │       ├── OutputArea.tsx
    │   │       └── Header.tsx
    │   ├── pages/
    │   │   └── Index.tsx
    │   └── App.tsx
    └── package.json
```

## 🎯 New Features

### 1. Application Generation

**Backend**: `backend_api.py`
* Endpoint: `POST /api/generate-application`
* Templates: 4 pre-built application templates
  - Disability Certificate Application
  - UDID Card Application
  - Pension Scheme Application
  - Employment Rights Application
* Custom generation via LLM for non-template schemes

**Request Format**:
```json
{
  "scheme_name": "UDID Card",
  "user_details": {
    "name": "Rajesh Kumar",
    "age": "35",
    "disability_type": "Visual",
    "percentage": "60",
    "address": "123 MG Road",
    "district": "Bangalore",
    "state": "Karnataka",
    "contact": "+91-9876543210"
  },
  "language": "en-IN"
}
```

**Response Format**:
```json
{
  "title": "Application for UDID Card",
  "authority": "UDID Portal (Online Application)",
  "application_text": "Full formatted application...",
  "language": "en-IN",
  "required_documents": [
    "Disability Certificate",
    "Aadhaar Card",
    "Passport size photograph"
  ]
}
```

### 2. Scheme Discovery

**Backend**: `POST /api/schemes`
* RAG-based scheme matching
* Filter by disability type, state
* Returns top 5 relevant schemes

**Request Format**:
```json
{
  "query": "pension schemes",
  "disability_type": "physical",
  "state": "Maharashtra",
  "language": "en-IN"
}
```

### 3. Intent Detection

Backend automatically detects query intent:
* **Information**: General questions about rights, laws
* **Schemes**: Looking for schemes/benefits
* **Application**: Wants to apply/generate forms

## 🔄 API Endpoints

### 1. Text Query
```http
POST /api/query
Content-Type: application/json

{
  "text": "What are employment rights for disabled persons?",
  "input_language": "en-IN",
  "output_language": "hi-IN",
  "fast_mode": true
}
```

**Response**:
```json
{
  "answer": "According to RPWD Act 2016...",
  "sources": [
    {"source": "RPWD_Act_2016.pdf", "topic": "Employment"}
  ],
  "intent": "information",
  "schemes": [],
  "language": "hi-IN"
}
```

### 2. Voice Query
```http
POST /api/voice-query
Content-Type: multipart/form-data

audio: <audio file>
input_language: hi-IN
output_language: hi-IN
fast_mode: true
```

**Response**:
```json
{
  "transcribed": "मुझे पेंशन योजना के बारे में बताओ",
  "answer": "पेंशन योजना...",
  "audio_base64": "base64_encoded_audio",
  "sources": [...],
  "intent": "schemes",
  "language": "hi-IN"
}
```

### 3. Generate Application
```http
POST /api/generate-application
Content-Type: application/json

{
  "scheme_name": "Disability Certificate",
  "user_details": { ... },
  "language": "en-IN"
}
```

### 4. Discover Schemes
```http
POST /api/schemes
Content-Type: application/json

{
  "query": "education schemes",
  "disability_type": "visual",
  "language": "en-IN"
}
```

## 🚀 Deployment Steps

### Step 1: Copy UI to samarthvaani_app folder

```bash
# From workspace terminal
cd /Workspace/Users/am1221830@iitd.ac.in/
cp -r samarth-vaani-ui-main samarthvaani_app/samarth-vaani-ui
```

### Step 2: Update app.yaml

```yaml
command: ["uvicorn", "backend_api:app", "--host", "0.0.0.0", "--port", "8000"]

# Or for hybrid deployment (FastAPI + serving static React build):
# command: ["python", "backend_api.py"]
```

### Step 3: Build React UI (if needed)

```bash
cd samarthvaani_app/samarth-vaani-ui
npm install
npm run build
# Build output goes to dist/ folder
```

### Step 4: Update backend_api.py to serve static files

Add after line 82:
```python
# Serve static React build
app.mount("/", StaticFiles(directory="samarth-vaani-ui/dist", html=True), name="static")
```

### Step 5: Deploy as Databricks App

```bash
# From samarthvaani_app folder
databricks apps deploy samarthvaani-app \
  --source-code-path . \
  --config-file app.yaml
```

## 🔌 Frontend Integration

### Connect React UI to Backend API

**Example API client** (`src/api/client.ts`):
```typescript
const API_BASE = "/api";  // Or your backend URL

export async function queryRAG(text: string, inputLang: string, outputLang: string) {
  const response = await fetch(`${API_BASE}/query`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      text,
      input_language: inputLang,
      output_language: outputLang,
      fast_mode: true
    })
  });
  return response.json();
}

export async function generateApplication(schemeName: string, userDetails: object, language: string) {
  const response = await fetch(`${API_BASE}/generate-application`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      scheme_name: schemeName,
      user_details: userDetails,
      language
    })
  });
  return response.json();
}

export async function discoverSchemes(query: string, language: string) {
  const response = await fetch(`${API_BASE}/schemes`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, language })
  });
  return response.json();
}
```

## 📝 Application Templates

### Available Templates

1. **Disability Certificate** (`disability_certificate`)
   - For: Initial disability certification
   - Authority: CMO / District Medical Board
   
2. **UDID Card** (`udid_card`)
   - For: Unique Disability ID registration
   - Authority: UDID Portal (online)
   
3. **Pension Scheme** (`pension_scheme`)
   - For: Disability pension enrollment
   - Authority: District Social Welfare Officer
   
4. **Employment Rights** (`employment_rights`)
   - For: Workplace accommodations
   - Authority: HR Department / Employer

### Required Fields

All templates support these fields:
* `name`, `age`, `address`, `district`, `state`
* `contact`, `email`
* `disability_type`, `percentage`
* `documents` (custom list)

Additional fields per template:
* **UDID**: `guardian_name`, `dob`, `gender`, `pincode`
* **Pension**: `cert_number`, `category`, `annual_income`
* **Employment**: `employer_name`, `emp_id`, `designation`, `accommodations`

## 🧪 Testing

### Test Backend API

```bash
# Start backend
cd samarthvaani_app
python backend_api.py

# Test query endpoint
curl -X POST http://localhost:8000/api/query \
  -H "Content-Type: application/json" \
  -d '{"text": "What are my employment rights?", "input_language": "en-IN", "output_language": "en-IN"}'

# Test application generation
curl -X POST http://localhost:8000/api/generate-application \
  -H "Content-Type: application/json" \
  -d '{
    "scheme_name": "UDID Card",
    "user_details": {"name": "Test User", "disability_type": "Visual"},
    "language": "en-IN"
  }'
```

## 🎨 UI Components

### InputConsole.tsx
* Voice/Text toggle
* Fast mode switch
* Language selection
* Send button → calls `/api/query` or `/api/voice-query`

### OutputArea.tsx
* **Smart Scheme Finder** → calls `/api/schemes`
* **Simple Explanation** → from `/api/query` response
* **Application Generator** → modal/page → calls `/api/generate-application`

### Application Generator Flow
1. User clicks "Generate Application" in OutputArea
2. Modal/page opens with form for user details
3. On submit → POST `/api/generate-application`
4. Display formatted application with:
   - Title, authority
   - Application text (editable)
   - Required documents list
   - Download/Copy buttons

## 🌍 Multilingual Support

Supported languages (11):
* English, Hindi, Tamil, Telugu, Marathi
* Bengali, Kannada, Malayalam, Gujarati, Punjabi, Odia

**Translation flow**:
```
User Input (Any language) 
  → Translate to English (if needed)
  → RAG in English
  → Translate answer to output language
  → TTS in output language (optional)
```

## 🔐 Environment Variables

Required for voice features:
```env
SARVAM_API_KEY=your_key_here
```

Optional (defaults exist):
```env
VECTOR_SEARCH_ENDPOINT=samarthvaani_vs_endpoint
INDEX_NAME=samarthvaani.gold.rpwd_chunks_index
LLM_MODEL=databricks-meta-llama-3-3-70b-instruct
```

## 📚 Next Steps

1. ✅ Copy UI folder to `samarthvaani_app/`
2. ✅ Update backend to serve static files
3. ⬜ Build React UI (`npm run build`)
4. ⬜ Test API endpoints
5. ⬜ Connect frontend to backend APIs
6. ⬜ Deploy to Databricks Apps

## 🐛 Troubleshooting

**Issue**: Backend not connecting to Vector Search
* **Fix**: Check catalog/schema permissions, verify index name

**Issue**: Sarvam API calls failing
* **Fix**: Verify API key in `.env` file, check quota

**Issue**: React build fails
* **Fix**: Check Node version (>= 18), clear `node_modules`, reinstall

**Issue**: CORS errors
* **Fix**: CORS is enabled for all origins in backend_api.py (line 84-91)

## 📞 Support

For issues:
1. Check logs: `databricks apps logs samarthvaani-app`
2. Verify Vector Search status
3. Test LLM endpoint availability
4. Check Sarvam API balance (if using voice)
