"""
Configuration for Integrated Voice-Enabled RAG Pipeline

This module imports all configuration from sarvam_code and adds
RAG-specific configuration (Vector Search, LLM endpoints).

Architecture:
- sarvam_code/config.py: Handles multilingual + voice config
- final_work/config.py (this file): Handles RAG config
"""

import sys
import os

# Add parent directory to path to import sarvam_code
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import all configuration from sarvam_code
try:
    from sarvam_code.config import (
        SARVAM_STT_API_KEY,
        SARVAM_TTS_API_KEY,
        SARVAM_STT_URL,
        SARVAM_TTS_URL,
        SARVAM_STT_MODEL,
        SARVAM_TTS_MODEL,
        SUPPORTED_LANGUAGES,
        INDICTRANS2_LANG_MAP,
    )
    SARVAM_CODE_AVAILABLE = True
except ImportError as e:
    print(f"⚠️  Warning: Could not import sarvam_code configuration: {e}")
    print("   Make sure sarvam_code folder exists in parent directory")
    SARVAM_CODE_AVAILABLE = False
    SARVAM_STT_API_KEY = None
    SARVAM_TTS_API_KEY = None

# ===========================================================================
# RAG Pipeline Configuration (English Input → English Output)
# ===========================================================================

# Databricks Vector Search Configuration
VECTOR_SEARCH_ENDPOINT = "samarthvaani_vs_endpoint"
VECTOR_SEARCH_INDEX = "samarthvaani.gold.rpwd_chunks_index"

# LLM Configuration
LLM_MODEL = "databricks-meta-llama-3-3-70b-instruct"
LLM_ENDPOINT = "https://your-workspace.databricks.com/serving-endpoints/databricks-meta-llama-3-3-70b-instruct/invocations"

# RAG Default Parameters
DEFAULT_TOP_K = 3  # Number of chunks to retrieve
DEFAULT_MAX_TOKENS = 500  # Max tokens in LLM response
DEFAULT_TEMPERATURE = 0.1  # LLM temperature (0=focused, 1=creative)

# ===========================================================================
# Integrated Pipeline Default Parameters
# ===========================================================================

# Default input/output modes
DEFAULT_INPUT_MODE = "text"  # "text" or "voice"
DEFAULT_OUTPUT_MODE = "text"  # "text" or "voice"
DEFAULT_INPUT_LANG = "en-IN"  # Default input language
DEFAULT_OUTPUT_LANG = "en-IN"  # Default output language
DEFAULT_FAST_MODE = True  # Fast mode for voice processing

# ===========================================================================
# Validation Helpers
# ===========================================================================

def validate_config():
    """
    Validate that all required configuration is present.
    
    Returns:
        tuple: (is_valid, error_messages)
    """
    errors = []
    
    # Check sarvam_code availability
    if not SARVAM_CODE_AVAILABLE:
        errors.append("sarvam_code module not found or not importable")
    
    # Check API keys
    if not SARVAM_STT_API_KEY or SARVAM_STT_API_KEY == "":
        errors.append("SARVAM_STT_API_KEY not configured in sarvam_code/.env")
    
    if not SARVAM_TTS_API_KEY or SARVAM_TTS_API_KEY == "":
        errors.append("SARVAM_TTS_API_KEY not configured in sarvam_code/.env")
    
    # Check RAG configuration
    if not VECTOR_SEARCH_ENDPOINT:
        errors.append("VECTOR_SEARCH_ENDPOINT not configured")
    
    if not VECTOR_SEARCH_INDEX:
        errors.append("VECTOR_SEARCH_INDEX not configured")
    
    is_valid = len(errors) == 0
    return is_valid, errors


def get_config_summary():
    """
    Get a summary of current configuration.
    
    Returns:
        dict: Configuration summary
    """
    return {
        "sarvam_code_available": SARVAM_CODE_AVAILABLE,
        "api_keys_configured": bool(SARVAM_STT_API_KEY and SARVAM_TTS_API_KEY),
        "supported_languages": len(SUPPORTED_LANGUAGES) if SARVAM_CODE_AVAILABLE else 0,
        "vector_search_endpoint": VECTOR_SEARCH_ENDPOINT,
        "vector_search_index": VECTOR_SEARCH_INDEX,
        "llm_model": LLM_MODEL,
        "default_top_k": DEFAULT_TOP_K,
    }


if __name__ == "__main__":
    # Print configuration summary when run directly
    print("=" * 80)
    print("INTEGRATED VOICE RAG PIPELINE - CONFIGURATION")
    print("=" * 80)
    
    is_valid, errors = validate_config()
    
    if is_valid:
        print("\n✅ Configuration is valid!\n")
    else:
        print("\n❌ Configuration has errors:\n")
        for error in errors:
            print(f"   • {error}")
        print()
    
    summary = get_config_summary()
    print("Configuration Summary:")
    print("-" * 80)
    for key, value in summary.items():
        print(f"  {key:30s}: {value}")
    
    if SARVAM_CODE_AVAILABLE:
        print(f"\n  Supported Languages ({len(SUPPORTED_LANGUAGES)}):")
        for code, name in sorted(SUPPORTED_LANGUAGES.items(), key=lambda x: x[1]):
            print(f"    • {name:15s} ({code})")
    
    print("\n" + "=" * 80)
