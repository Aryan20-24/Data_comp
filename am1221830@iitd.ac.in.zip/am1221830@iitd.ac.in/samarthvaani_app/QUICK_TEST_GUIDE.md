# 🚀 Quick Test Guide - After Deployment

**Use this as a checklist after clicking "Deploy"**

---

## ⏱️ 1-Minute Quick Test

✅ **Step 1:** Open public URL  
✅ **Step 2:** Type: "What are employment rights for disabled persons?"  
✅ **Step 3:** Click "🔍 Ask (Text)"  
✅ **Expected:** Answer with sources appears in 2-4 seconds  

**If this works → Your app is working! 🎉**

---

## 🎤 5-Minute Voice Test

### English Voice Test
1. Click microphone button
2. Say: "What is the RPWD Act?"
3. Click "🎙️ Ask (Voice)"
4. ✅ Should show transcription + answer + audio

### Hindi Voice Test
1. Select "Hindi (हिंदी)" for both languages
2. Click microphone
3. Say: "मुझे योजनाओं के बारे में बताओ"
4. ✅ Should work in Hindi end-to-end

---

## 📝 2-Minute Application Test

1. Go to Tab 2: "Generate Applications"
2. Select "Disability Certificate"
3. Fill: Name, Age, Gender, Contact, Address, Disability
4. Click "📝 Generate Application"
5. ✅ Should get formatted letter instantly

---

## 🌐 Try Other Languages

Quick phrases to test (use voice input):

**Bengali:** "আমাকে সাহায্য করুন"  
**Tamil:** "எனக்கு உதவி செய்யுங்கள்"  
**Telugu:** "నాకు సహాయం చేయండి"  
**Marathi:** "मला मदत करा"  

---

## ⚠️ If Something Doesn't Work

### Voice doesn't work?
- Check browser microphone permission
- Try clicking anywhere on page first (autoplay policy)

### Slow responses?
- First query is slower (cold start)
- Subsequent queries are faster

### Wrong answers?
- Try rephrasing question
- Be more specific

---

## 📊 What to Look For

✅ **Good signs:**
- Answers appear in 2-10 seconds
- Audio plays automatically
- Transcriptions are accurate
- Languages work correctly
- Applications generate instantly

❌ **Red flags:**
- Errors in UI
- Queries timeout (>30 seconds)
- Audio never plays
- Transcriptions are gibberish

---

## 🎯 Full Feature Checklist

After deployment, check off:

- [ ] Text queries work (English)
- [ ] Voice input works (English)
- [ ] Voice output works (audio plays)
- [ ] Hindi voice works end-to-end
- [ ] At least 2 other languages work
- [ ] Application generator works
- [ ] All 3 tabs visible
- [ ] Keyboard navigation works (Tab key)
- [ ] Mobile responsive (if you have phone)

**If 8/9 items work → You're good to go! 🚀**

---

## 📞 Quick Troubleshooting

 Problem | Quick Fix |
---------|-----------|
 "No API found" | Already fixed - shouldn't happen |
 "RAG unavailable" | Check Resources in Apps UI |
 No audio | Click page first, check volume |
 No microphone | Allow browser permission |
 Slow | Normal for first query |

---

## 🎉 Success!

If text queries work and at least 1 voice test works, your deployment is **successful!** 

The app is production-ready for India's disabled community! 🤝♿🇮🇳

---

**Next:** Share with real users and gather feedback!
