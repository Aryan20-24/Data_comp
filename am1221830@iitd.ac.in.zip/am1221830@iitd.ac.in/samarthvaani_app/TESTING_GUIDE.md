# 🧪 VOICE FEATURES - QUICK TESTING GUIDE

## After App Starts Successfully

### ✅ Test 1: Basic Text Query (English)
1. Type in text box: "What are employment rights for disabled persons?"
2. Click "Ask SamarthVaani"
3. **Expected:** Text answer with sources in ~3 seconds

---

### 🎤 Test 2: Voice Input (English)
1. Set **Input Language:** English
2. Set **Output Language:** English
3. Click microphone icon 🎤
4. **Speak:** "What are the education rights for disabled children?"
5. Stop recording
6. Click "Ask SamarthVaani"

**Expected:**
- Audio transcribed to text
- Text answer appears
- Sources cited

---

### 🔊 Test 3: Voice Output
1. Type: "What benefits are available for disabled persons?"
2. Set **Output Language:** Hindi
3. **Check:** "Enable voice output" ✅
4. Click "Ask SamarthVaani"

**Expected:**
- Text answer in Hindi
- Audio player with Hindi speech
- Can play/download audio

---

### 🌐 Test 4: Full Multilingual (Voice → Voice)
1. Set **Input Language:** Hindi
2. Set **Output Language:** Tamil
3. Click microphone 🎤
4. **Speak in Hindi:** "विकलांग व्यक्तियों के लिए क्या योजनाएं हैं?"
5. **Check:** "Enable voice output" ✅
6. Click "Ask SamarthVaani"

**Expected:**
- Hindi speech → text
- Hindi → English (internal)
- RAG processing
- English → Tamil (translation)
- Tamil text + Tamil audio

---

### 🧪 Test 5: All 11 Languages

Try each language:

1. **Hindi** - हिंदी
   - Input: "क्या है आरपीडब्ल्यूडी अधिनियम?"

2. **Tamil** - தமிழ்
   - Input: "RPWD சட்டம் என்றால் என்ன?"

3. **Telugu** - తెలుగు
   - Input: "RPWD చట్టం అంటే ఏమిటి?"

4. **Marathi** - मराठी
   - Input: "आरपीडब्ल्यूडी कायदा म्हणजे काय?"

5. **Bengali** - বাংলা
   - Input: "RPWD আইন কি?"

6. **Kannada** - ಕನ್ನಡ
   - Input: "RPWD ಕಾಯ್ದೆ ಎಂದರೇನು?"

7. **Malayalam** - മലയാളം
   - Input: "RPWD നിയമം എന്താണ്?"

8. **Gujarati** - ગુજરાતી
   - Input: "RPWD કાયદો શું છે?"

9. **Punjabi** - ਪੰਜਾਬੀ
   - Input: "RPWD ਕਾਨੂੰਨ ਕੀ ਹੈ?"

10. **Odia** - ଓଡ଼ିଆ
    - Input: "RPWD ଆଇନ କଣ?"

11. **English**
    - Input: "What is RPWD Act?"

---

## 📊 Success Criteria

### ✅ Voice Input Working
- Microphone records audio
- Audio transcribed correctly
- Translation works (if non-English)

### ✅ Voice Output Working
- Audio player appears
- Can play audio
- Speech is clear and correct language

### ✅ Translation Working
- Input language detected
- Translated to English for RAG
- Output translated to target language

### ✅ RAG Working
- Relevant context retrieved
- Answer generated
- Sources cited correctly

---

## 🐛 Common Issues

### Issue: Microphone not working
**Cause:** Browser permissions
**Fix:** Allow microphone access in browser

### Issue: Audio not playing
**Cause:** Browser audio blocked
**Fix:** Check browser audio settings

### Issue: Translation not working
**Cause:** IndicTrans2 models not loaded
**Fix:** Wait 2-3 minutes for first-time model download

### Issue: Voice quality poor
**Cause:** Sarvam API rate limits or connectivity
**Fix:** Try again after a few seconds

---

## 📝 Sample Questions (All Languages)

### Employment Rights
- English: "What are employment rights for disabled persons?"
- Hindi: "विकलांग व्यक्तियों के लिए रोजगार के अधिकार क्या हैं?"
- Tamil: "மாற்றுத்திறனாளிகளுக்கான வேலை உரிமைகள் என்ன?"

### Education Rights
- English: "What are education benefits for disabled children?"
- Hindi: "विकलांग बच्चों के लिए शिक्षा लाभ क्या हैं?"
- Telugu: "వికలాంగ పిల్లలకు విద్యా ప్రయోజనాలు ఏమిటి?"

### Certification Process
- English: "How to get disability certificate?"
- Marathi: "अपंगत्व प्रमाणपत्र कसे मिळवायचे?"
- Kannada: "ಅಂಗವಿಕಲತೆ ಪ್ರಮಾಣಪತ್ರ ಹೇಗೆ ಪಡೆಯುವುದು?"

### Government Schemes
- English: "What schemes are available for disabled persons?"
- Bengali: "প্রতিবন্ধী ব্যক্তিদের জন্য কী কী প্রকল্প আছে?"
- Malayalam: "വികലാംഗർക്കായി എന്തൊക്കെ പദ്ധതികളുണ്ട്?"

---

## 🎯 Performance Benchmarks

### Expected Response Times
- **Text only:** 2-3 seconds
- **Voice input:** 5-7 seconds (STT + processing)
- **Voice output:** 8-10 seconds (+ TTS)
- **Full voice-to-voice:** 10-15 seconds

### First-time Model Loading
- **IndicTrans2:** ~2-3 minutes (2GB download)
- **Subsequent runs:** Fast (cached)

---

## ✅ FINAL CHECKLIST

Before declaring success:
- [ ] Text query works
- [ ] Voice recording works
- [ ] Voice playback works
- [ ] English input/output works
- [ ] At least 3 other languages tested
- [ ] Translation accuracy acceptable
- [ ] Sources cited correctly
- [ ] No errors in logs

---

**Status:** Ready for testing 🎤
**Languages:** 11 Indian languages ✅
**Features:** Voice + Text + Translation ✅
