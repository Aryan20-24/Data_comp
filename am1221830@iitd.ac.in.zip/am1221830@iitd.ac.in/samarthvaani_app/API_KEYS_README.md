# API Keys Setup

## Required API Keys

SamarthVaani uses Sarvam AI for speech-to-text and text-to-speech:

1. **SARVAM_STT_API_KEY** - For speech-to-text (Saarika model)
2. **SARVAM_TTS_API_KEY** - For text-to-speech (Bulbul model)

## Setup Instructions

1. Get your API keys from [Sarvam AI](https://www.sarvam.ai/)

2. Edit the file: `sarvam_code/.env`

3. Replace the placeholder values:
   ```
   SARVAM_STT_API_KEY=your_actual_key_here
   SARVAM_TTS_API_KEY=your_actual_key_here
   ```

4. Save the file

5. Restart the app

## Note

If you don't have API keys, the app will still work in **text-only mode** with English and other Indian languages. Voice features will be disabled.

## Testing

To verify your keys are working, the app logs will show:
- ✅ Sarvam code imported - 11 languages supported (if keys are valid)
- ⚠️  Sarvam code not available (if keys are missing/invalid)
