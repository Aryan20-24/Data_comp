# SamarthVaani - Complete Deployment Guide

## 🎯 Deployment Options

You have **THREE deployment options**, each with different features and complexity:

| Option | UI | Features | Complexity | Build Required |
|--------|----|---------|-----------| ---------------|
| **Option 1: Gradio App** | ✅ Built-in Gradio | Voice, Text, 11 languages, RAG | ⭐ Simple | ❌ No |
| **Option 2: FastAPI Backend** | ❌ API only | All features (5 endpoints) | ⭐⭐ Moderate | ❌ No |
| **Option 3: Full Stack** | ✅ React UI | All features + modern UI | ⭐⭐⭐ Complex | ✅ Yes |

---

## 📦 What's Ready

### ✅ Backend Components
* `app_voice.py` - Gradio standalone app (ready to deploy)
* `backend_api.py` - FastAPI with 5 endpoints (ready to deploy)
* `app_full.py` - Unified FastAPI + React (needs frontend build)
* `integrated_pipeline.py` - RAG pipeline integration
* `sarvam_code/` - Voice and translation modules
* `pipeline_config.py` - Configuration

### ✅ Frontend Components (needs build)
* `samarth-vaani-ui/` - React + TypeScript application
* 91 source files with complete UI
* Voice recording, scheme cards, application generator

### ✅ Configuration
* `app.yaml` - Databricks Apps config (currently set to app_full.py)
* `requirements.txt` - Python dependencies
* `.env.template` - Environment variable template

---

## 🚀 OPTION 1: Quick Deploy - Gradio App (RECOMMENDED for quick start)

### ✨ Features
* ✅ Voice input/output (11 languages)
* ✅ Text queries with RAG
* ✅ Built-in Gradio UI
* ✅ No frontend build needed
* ⚠️ No scheme discovery
* ⚠️ No application generation

### Steps

1. **Update app.yaml** to use Gradio:
   ```yaml
   command: ["python", "app_voice.py"]
   env:
     - name: GRADIO_SERVER_NAME
       value: "0.0.0.0"
     - name: GRADIO_SERVER_PORT
       value: "8080"
   ```

2. **Go to Databricks Apps**:
   * Navigate to: **Compute → Apps**
   * Click: **Create App** (or Edit existing)

3. **Configure**:
   * Name: `samarthvaani-chatbot`
   * Source code path: `/Users/am1221830@iitd.ac.in/samarthvaani_app`
   * Description: Voice-enabled AI assistant for disability rights

4. **Add Resources** (CRITICAL):
   * ✅ Vector Search Index: `samarthvaani.gold.rpwd_chunks_index`
   * ✅ Serving Endpoint: `databricks-meta-llama-3-3-70b-instruct`

5. **Start App**:
   * Click "Start app"
   * Wait 5-10 minutes (first time - downloads models)
   * Monitor logs for:
     ```
     ✅ SAMARTHVAANI VOICE-ENABLED CHATBOT STARTING
     ✅ Connected to index: samarthvaani.gold.rpwd_chunks_index
     ✅ Workspace client initialized
     🌐 Launching on 0.0.0.0:8080...
     ```

6. **Test**:
   * Open the app URL
   * Try: "What are employment rights for disabled persons?"
   * Select languages and test voice features

---

## 🚀 OPTION 2: API-Only Deploy - FastAPI Backend

### ✨ Features
* ✅ 5 RESTful API endpoints
* ✅ Scheme discovery
* ✅ Application generation
* ✅ Voice query endpoint
* ✅ Multilingual support
* ❌ No UI (API only)

### Steps

1. **Update app.yaml** to use FastAPI:
   ```yaml
   command: ["python", "backend_api.py"]
   env:
     - name: GRADIO_SERVER_NAME
       value: "0.0.0.0"
     - name: GRADIO_SERVER_PORT
       value: "8080"
   ```

2. **Follow same deployment steps as Option 1**

3. **Test API Endpoints**:
   ```bash
   # Health check
   curl https://your-app-url.databricks.com/

   # Get languages
   curl https://your-app-url.databricks.com/api/languages

   # Query
   curl -X POST https://your-app-url.databricks.com/api/query \
     -H "Content-Type: application/json" \
     -d '{"text": "What are disability rights?", "input_language": "en-IN"}'
   ```

### API Endpoints
* `GET /` - Health check
* `GET /api/languages` - List supported languages
* `POST /api/query` - Text RAG query
* `POST /api/voice-query` - Voice query with audio I/O
* `POST /api/schemes` - Discover schemes
* `POST /api/generate-application` - Generate application letters

---

## 🚀 OPTION 3: Full Stack Deploy - React + FastAPI

### ✨ Features
* ✅ All FastAPI endpoints
* ✅ Modern React UI
* ✅ Voice recording in browser
* ✅ Scheme cards with confidence scores
* ✅ Application generator dialog
* ⚠️ Requires frontend build

### Prerequisites
* Node.js 18+ and npm (for building frontend)
* Can be done locally or on a cluster with Node.js

### Steps

#### A. Build Frontend (Do this locally or on Node.js-enabled environment)

```bash
# 1. Clone/download the samarthvaani_app folder to your local machine

# 2. Navigate to frontend
cd samarthvaani_app/samarth-vaani-ui

# 3. Install dependencies (takes 2-3 minutes)
npm install

# 4. Build production bundle (takes 1-2 minutes)
npm run build

# 5. Verify dist/ folder was created
ls -la dist/

# 6. Upload the dist/ folder back to Databricks at:
#    /Users/am1221830@iitd.ac.in/samarthvaani_app/samarth-vaani-ui/dist/
```

#### B. Deploy to Databricks

1. **Ensure app.yaml** uses full stack app (already configured):
   ```yaml
   command: ["python", "app_full.py"]
   env:
     - name: GRADIO_SERVER_NAME
       value: "0.0.0.0"
     - name: GRADIO_SERVER_PORT
       value: "8080"
   ```

2. **Verify dist/ folder exists**:
   * Path: `samarthvaani_app/samarth-vaani-ui/dist/`
   * Contains: `index.html`, `assets/` folder

3. **Deploy** following Option 1 steps

4. **Test Full Stack**:
   * Open app URL → See React UI
   * Test voice recording
   * Test scheme discovery
   * Test application generation

---

## ⚙️ Configuration

### Vector Search Index
```
Endpoint: samarthvaani_vs_endpoint
Index: samarthvaani.gold.rpwd_chunks_index
Chunks: 1,414 documents
```

### LLM Endpoint
```
Model: databricks-meta-llama-3-3-70b-instruct
Max Tokens: 700
Temperature: 0.1
```

### Voice Features (Optional)
To enable voice input/output:

1. Get API keys from [Sarvam AI](https://www.sarvam.ai/)
2. Create/edit: `sarvam_code/.env`
3. Add:
   ```
   SARVAM_STT_API_KEY=your_key_here
   SARVAM_TTS_API_KEY=your_key_here
   ```

Without API keys:
* ✅ Text translation works (IndicTrans2)
* ❌ Voice input disabled
* ❌ Voice output disabled

---

## 📋 Deployment Checklist

### Before Deployment
- [ ] Choose deployment option (1, 2, or 3)
- [ ] Update `app.yaml` for chosen option
- [ ] If Option 3: Build frontend and upload dist/
- [ ] (Optional) Add Sarvam API keys for voice features
- [ ] Verify `sarvam_code/` module exists

### During Deployment
- [ ] Go to Compute → Apps
- [ ] Create/Edit app with correct source path
- [ ] Add Vector Search Index resource
- [ ] Add Serving Endpoint resource
- [ ] Start app
- [ ] Wait 5-10 minutes for first start

### After Deployment
- [ ] Check logs for successful startup
- [ ] Test health endpoint
- [ ] Test text query in English
- [ ] Test multilingual query
- [ ] (If Option 1) Test Gradio UI
- [ ] (If Option 2) Test API endpoints
- [ ] (If Option 3) Test React UI
- [ ] (Optional) Test voice features

---

## 🔧 Troubleshooting

### App Won't Start
* **Check:** Resources added (Vector Search + LLM endpoint)?
* **Check:** Source code path correct?
* **Check:** App logs for error messages

### "Vector Search index not found"
* **Solution:** Add resource in app configuration
* **Verify:** Index exists at `samarthvaani.gold.rpwd_chunks_index`

### "LLM service unavailable"
* **Solution:** Add serving endpoint resource
* **Verify:** Endpoint `databricks-meta-llama-3-3-70b-instruct` is enabled

### Voice Features Not Working
* **Check:** API keys in `sarvam_code/.env`?
* **Check:** Logs show "Sarvam code imported"?
* **Fallback:** App works in text-only mode

### Frontend Shows White Screen (Option 3)
* **Check:** dist/ folder exists and uploaded?
* **Check:** dist/index.html exists?
* **Check:** Browser console for errors
* **Solution:** Rebuild frontend or use Option 1/2

### Slow First Start
* **Normal:** First start takes 5-10 minutes
* **Reason:** Downloading PyTorch, IndicTrans2 models (~4GB)
* **After:** Subsequent starts are faster (2-3 minutes)

---

## 🎯 Recommended Deployment Path

### For Quick Demo
→ **Option 1: Gradio App**
* Fastest to deploy
* Built-in UI
* All voice features work

### For API Integration
→ **Option 2: FastAPI Backend**
* Use if building custom frontend
* Full API capabilities
* Easy to integrate

### For Production (Best UX)
→ **Option 3: Full Stack**
* Modern React UI
* Best user experience
* Requires frontend build step

---

## 📞 Support

**Issues?**
1. Check logs in Databricks Apps console
2. Verify all resources are added
3. Test with Option 1 first (simplest)
4. Review error messages in logs

**Files Overview:**
* `app_voice.py` - Gradio app (Option 1)
* `backend_api.py` - FastAPI backend (Option 2)
* `app_full.py` - Full stack app (Option 3)
* `app.yaml` - Deployment configuration
* `requirements.txt` - Python dependencies

---

## 🎉 Ready to Deploy!

**Current Configuration:** `app.yaml` is set to `app_full.py` (Option 3)

**To switch to Option 1 (Gradio - RECOMMENDED):**
1. Edit `app.yaml`
2. Change command to: `["python", "app_voice.py"]`
3. Deploy!

**To switch to Option 2 (API only):**
1. Edit `app.yaml`
2. Change command to: `["python", "backend_api.py"]`
3. Deploy!
