# SamarthVaani - System Architecture

## 🏗️ Complete System Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           USER INTERFACE LAYER                           │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │         React UI (Vite + TypeScript + Tailwind CSS)             │  │
│  │                                                                  │  │
│  │  ┌────────────────┐  ┌────────────────┐  ┌──────────────────┐  │  │
│  │  │ InputConsole   │  │  OutputArea    │  │  Application     │  │  │
│  │  │                │  │                │  │  Generator       │  │  │
│  │  │ • Voice Input  │  │ • Scheme Cards │  │  Modal/Page      │  │  │
│  │  │ • Text Input   │  │ • Explanations │  │                  │  │  │
│  │  │ • Language     │  │ • Sources      │  │ • Form Inputs    │  │  │
│  │  │   Selection    │  │ • Voice Output │  │ • Template Fill  │  │  │
│  │  │ • Fast Mode    │  │                │  │ • Download/Copy  │  │  │
│  │  └────────────────┘  └────────────────┘  └──────────────────┘  │  │
│  │                                                                  │  │
│  │  📁 Location: samarthvaani_app/samarth-vaani-ui/src/            │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────┬───────────────────────────────────────────┘
                               │
                               │ HTTP/REST API
                               │ (JSON requests/responses)
                               ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                          BACKEND API LAYER                               │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │              FastAPI Backend (backend_api.py)                    │  │
│  │                                                                  │  │
│  │  🔌 Endpoints:                                                   │  │
│  │  ├─ POST /api/query                                             │  │
│  │  │  └─ Text-based RAG query with multilingual support          │  │
│  │  │                                                              │  │
│  │  ├─ POST /api/voice-query                                       │  │
│  │  │  └─ Voice input (STT) → RAG → Voice output (TTS)           │  │
│  │  │                                                              │  │
│  │  ├─ POST /api/schemes                                           │  │
│  │  │  └─ Discover schemes by query, disability type, state       │  │
│  │  │                                                              │  │
│  │  ├─ POST /api/generate-application                             │  │
│  │  │  └─ Generate application letters from templates or LLM      │  │
│  │  │                                                              │  │
│  │  └─ GET /api/languages                                          │  │
│  │     └─ Get supported languages (11 Indian languages)           │  │
│  │                                                                  │  │
│  │  📁 Location: samarthvaani_app/backend_api.py                   │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │                    Core Components                               │  │
│  │                                                                  │  │
│  │  ┌──────────────────┐  ┌──────────────────┐  ┌───────────────┐ │  │
│  │  │  Intent Detector │  │  RAG Pipeline    │  │  Application  │ │  │
│  │  │                  │  │                  │  │  Templates    │ │  │
│  │  │ • Information    │  │ • retrieve()     │  │               │ │  │
│  │  │ • Schemes        │  │ • build_prompt() │  │ • Disability  │ │  │
│  │  │ • Application    │  │ • generate()     │  │   Certificate │ │  │
│  │  └──────────────────┘  └──────────────────┘  │ • UDID Card   │ │  │
│  │                                               │ • Pension     │ │  │
│  │                                               │ • Employment  │ │  │
│  │                                               └───────────────┘ │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└──────────┬─────────────┬──────────────┬──────────────────────────────────┘
           │             │              │
           │             │              └──────────────┐
           │             │                             │
           ▼             ▼                             ▼
┌─────────────────┐ ┌──────────────────────┐ ┌─────────────────────────┐
│ Vector Search   │ │   LLM Serving        │ │ Sarvam AI (Optional)    │
│ (Databricks)    │ │   (Databricks)       │ │                         │
│                 │ │                      │ │                         │
│ • Endpoint:     │ │ • Model:             │ │ • Speech-to-Text (STT)  │
│   samarthvaani_ │ │   databricks-meta-   │ │   - Saarika ASR         │
│   vs_endpoint   │ │   llama-3-3-70b-     │ │                         │
│                 │ │   instruct           │ │ • Text-to-Speech (TTS)  │
│ • Index:        │ │                      │ │   - Bulbul Voice        │
│   samarthvaani. │ │ • Max Tokens: 700    │ │                         │
│   gold.rpwd_    │ │ • Temperature: 0.1   │ │ • Translation:          │
│   chunks_index  │ │                      │ │   - IndicTrans2         │
│                 │ │ • Hybrid Search:     │ │   - 11 languages        │
│ • Chunks: 1,414 │ │   - Semantic (BGE)   │ │                         │
│ • Embeddings:   │ │   - Keyword (BM25)   │ │ 📁 sarvam_code/         │
│   BGE-large     │ │                      │ │                         │
└─────────────────┘ └──────────────────────┘ └─────────────────────────┘
```

## 🔄 Request Flow Diagrams

### 1. Text Query Flow

```
User Types Question in UI
         │
         ▼
┌──────────────────────┐
│ InputConsole.tsx     │
│ • Text: "What are   │
│   my employment     │
│   rights?"          │
│ • Language: hi-IN   │
│ • Fast Mode: ON     │
└──────────┬───────────┘
           │ HTTP POST
           ▼
┌──────────────────────────────────────────────┐
│ POST /api/query                              │
│ {                                            │
│   text: "What are my employment rights?",   │
│   input_language: "hi-IN",                  │
│   output_language: "hi-IN",                 │
│   fast_mode: true                           │
│ }                                            │
└──────────┬───────────────────────────────────┘
           │
           ▼
┌────────────────────────────────────┐
│ Backend Processing                 │
│                                    │
│ 1. Translate to English (if needed)│
│    "What are my employment rights?"│
│                                    │
│ 2. Detect Intent → "information"  │
│                                    │
│ 3. Vector Search (top 5 chunks)   │
│    ├─ Query: English text         │
│    └─ Results: RPWD Act sections  │
│                                    │
│ 4. Build RAG Prompt                │
│    Context + Question              │
│                                    │
│ 5. LLM Generation                  │
│    Answer in English               │
│                                    │
│ 6. Translate Answer to Hindi       │
│    (if output_language != en-IN)   │
│                                    │
│ 7. Return Response                 │
└────────────┬───────────────────────┘
             │
             ▼
┌────────────────────────────────────┐
│ Response:                          │
│ {                                  │
│   answer: "आपके रोजगार अधिकार...", │
│   sources: [...],                  │
│   intent: "information",           │
│   schemes: [],                     │
│   language: "hi-IN"                │
│ }                                  │
└────────────┬───────────────────────┘
             │
             ▼
┌──────────────────────┐
│ OutputArea.tsx       │
│ • Display answer     │
│ • Show sources       │
│ • Voice output (opt) │
└──────────────────────┘
```

### 2. Application Generation Flow

```
User Clicks "Generate Application" in UI
         │
         ▼
┌──────────────────────┐
│ Application Modal    │
│ Opens with Form:     │
│ • Name               │
│ • Disability Type    │
│ • Percentage         │
│ • Address            │
│ • Contact            │
│ • ...                │
└──────────┬───────────┘
           │
           ▼
User Fills Form & Submits
           │
           ▼ HTTP POST
┌────────────────────────────────────────────┐
│ POST /api/generate-application            │
│ {                                          │
│   scheme_name: "UDID Card",               │
│   user_details: {                         │
│     name: "Rajesh Kumar",                 │
│     disability_type: "Visual",            │
│     percentage: "60",                     │
│     address: "123 MG Road, Bangalore"     │
│   },                                      │
│   language: "en-IN"                       │
│ }                                          │
└──────────┬─────────────────────────────────┘
           │
           ▼
┌────────────────────────────────────┐
│ Backend Processing                 │
│                                    │
│ 1. Determine Template              │
│    "UDID Card" → udid_card template│
│                                    │
│ 2. Fill Template                   │
│    Replace {name}, {disability_   │
│    type}, etc. with user details   │
│                                    │
│ 3. Translate (if language != en)   │
│    Template → Target language      │
│                                    │
│ 4. Get Required Documents          │
│    Based on template type          │
│                                    │
│ 5. Return Formatted Application    │
└────────────┬───────────────────────┘
             │
             ▼
┌────────────────────────────────────┐
│ Response:                          │
│ {                                  │
│   title: "Application for UDID    │
│           Card",                   │
│   authority: "UDID Portal",        │
│   application_text: "Full letter..."│
│   required_documents: [...]        │
│ }                                  │
└────────────┬───────────────────────┘
             │
             ▼
┌──────────────────────┐
│ UI Displays:         │
│ • Title              │
│ • Full application   │
│ • Document list      │
│ • Download button    │
│ • Copy button        │
└──────────────────────┘
```

## 🗃️ Data Layer

### Vector Search Index Structure

```
samarthvaani.gold.rpwd_chunks_index
│
├─ Primary Key: chunk_id
├─ Vector Column: embedding (BGE-large, 1024 dim)
├─ Text Column: chunk_text
├─ Metadata:
│  ├─ topic (e.g., "Employment", "Education")
│  ├─ source (e.g., "RPWD_Act_2016.pdf")
│  ├─ section_title
│  ├─ page_number
│  └─ doc_type
│
└─ Search Types:
   ├─ Semantic Search (vector similarity)
   └─ Keyword Search (BM25)
```

### Application Templates

```
APPLICATION_TEMPLATES = {
  "disability_certificate": {
    title: "Application for Disability Certificate"
    authority: "Chief Medical Officer"
    template: "Formal letter with fields..."
    required_docs: [...]
  },
  "udid_card": { ... },
  "pension_scheme": { ... },
  "employment_rights": { ... }
}
```

## 🌍 Multilingual Pipeline

```
Input Language (11 options)
        │
        ├─ en-IN (English) ────────────┐
        ├─ hi-IN (Hindi)               │
        ├─ ta-IN (Tamil)               │
        ├─ te-IN (Telugu)              │
        ├─ mr-IN (Marathi)             │
        ├─ bn-IN (Bengali)             │ Translation
        ├─ kn-IN (Kannada)             │ (if needed)
        ├─ ml-IN (Malayalam)           │ Via:
        ├─ gu-IN (Gujarati)            │ • Sarvam API (Fast Mode)
        ├─ pa-IN (Punjabi)             │ • IndicTrans2 (High Accuracy)
        └─ or-IN (Odia)                │
                │                       │
                ▼                       │
        ┌───────────────┐              │
        │  Translation  │──────────────┘
        │  to English   │
        └───────┬───────┘
                │
                ▼
        ┌───────────────┐
        │  RAG Pipeline │
        │  (English)    │
        └───────┬───────┘
                │
                ▼
        ┌───────────────┐
        │  Translation  │
        │  to Output    │
        │  Language     │
        └───────┬───────┘
                │
                ▼
        Output Language (11 options)
```

## 🔌 API Integration Points

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **Frontend** | React + Vite + TypeScript | User interface |
| **Backend** | FastAPI + Python | API endpoints, orchestration |
| **Vector Search** | Databricks Vector Search | Semantic similarity search |
| **LLM** | Llama 3.3 70B (Databricks) | Answer generation |
| **STT** | Sarvam Saarika ASR | Voice to text |
| **TTS** | Sarvam Bulbul | Text to voice |
| **Translation** | Sarvam API / IndicTrans2 | 11 Indian languages |

## 📊 Deployment Architecture

```
Databricks Apps Platform
        │
        ├─ Container with:
        │  ├─ FastAPI backend (backend_api.py)
        │  ├─ React build (samarth-vaani-ui/dist/)
        │  ├─ Sarvam code (STT/TTS/Translation)
        │  └─ Requirements installed
        │
        ├─ Exposed Port: 8000
        │
        └─ Routes:
           ├─ / → React UI (static files)
           └─ /api/* → FastAPI endpoints
```

## 🎯 Feature Matrix

| Feature | UI Component | Backend Endpoint | External Service |
|---------|-------------|------------------|------------------|
| Text Query | InputConsole | `/api/query` | Vector Search + LLM |
| Voice Query | InputConsole | `/api/voice-query` | Sarvam STT + Vector Search + LLM + Sarvam TTS |
| Scheme Discovery | OutputArea | `/api/schemes` | Vector Search + LLM |
| Application Gen | OutputArea | `/api/generate-application` | Templates + LLM |
| Translation | All | Built-in | Sarvam API / IndicTrans2 |
| Intent Detection | - | Automatic | Pattern matching |

## 📁 File Organization

```
samarthvaani_app/
│
├─ Backend
│  ├─ backend_api.py          (747 lines) ← Main FastAPI app
│  ├─ integrated_pipeline.py  (legacy)
│  └─ pipeline_config.py      (config)
│
├─ Voice & Translation
│  └─ sarvam_code/
│     ├─ stt.py, tts.py, translate.py
│     ├─ input_processor.py, output_processor.py
│     └─ config.py, .env
│
├─ Frontend
│  └─ samarth-vaani-ui/
│     ├─ src/
│     │  ├─ api/client.ts     (API functions)
│     │  ├─ components/samarth/
│     │  ├─ pages/Index.tsx
│     │  └─ App.tsx
│     └─ package.json
│
├─ Configuration
│  ├─ requirements.txt         (Python deps)
│  └─ app.yaml                 (Databricks App config)
│
└─ Documentation
   ├─ INTEGRATION_GUIDE.md     (13 KB - API docs)
   ├─ DEPLOYMENT_SUMMARY.md    (9 KB - Deployment guide)
   └─ ARCHITECTURE.md          (This file)
```
