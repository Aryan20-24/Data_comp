#!/usr/bin/env python3
"""
SamarthVaani Full Application - Production Deployment
Serves both FastAPI backend and React frontend
"""
import os
import sys
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

print("="*80)
print("🚀 SAMARTHVAANI FULL APPLICATION STARTING")
print("="*80)

# Add current directory to path
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

# Import the complete backend API
print("📦 Loading backend API...")
try:
    # We'll import the app directly from backend_api
    # This ensures all endpoints and configurations are included
    from backend_api import (
        app as backend_app, 
        vs_index, 
        ws_client,
        SARVAM_AVAILABLE,
        SUPPORTED_LANGUAGES
    )
    print("✅ Backend API loaded successfully")
    print(f"   Vector Search: {'✅ Connected' if vs_index else '❌ Not connected'}")
    print(f"   LLM Client: {'✅ Connected' if ws_client else '❌ Not connected'}")
    print(f"   Voice Features: {'✅ Available' if SARVAM_AVAILABLE else '⚠️  Disabled'}")
    print(f"   Languages: {len(SUPPORTED_LANGUAGES)}")
except Exception as e:
    print(f"❌ Failed to load backend API: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Configure frontend static files
frontend_dist = current_dir / "samarth-vaani-ui" / "dist"

if frontend_dist.exists():
    print(f"✅ Frontend build found at: {frontend_dist}")
    
    # Mount static assets (JS, CSS, images, etc.)
    static_assets = frontend_dist / "assets"
    if static_assets.exists():
        backend_app.mount("/assets", StaticFiles(directory=str(static_assets)), name="assets")
        print("✅ Static assets mounted at /assets")
    
    # Serve index.html for all non-API routes (SPA routing)
    @backend_app.get("/{full_path:path}")
    async def serve_frontend(request: Request, full_path: str):
        """
        Serve the React frontend for all routes except API routes.
        This enables proper SPA routing.
        """
        # Skip if it's an API request
        if full_path.startswith("api/"):
            return {"error": "Endpoint not found"}
        
        # Serve index.html for the React app
        index_file = frontend_dist / "index.html"
        if index_file.exists():
            return FileResponse(str(index_file))
        else:
            return HTMLResponse(
                content="<h1>Frontend not built</h1><p>Run: cd samarth-vaani-ui && npm install && npm run build</p>",
                status_code=503
            )
    
    print("✅ SPA routing configured")
else:
    print(f"⚠️  Frontend build not found at: {frontend_dist}")
    print("   To build frontend:")
    print("   1. cd samarthvaani_app/samarth-vaani-ui")
    print("   2. npm install")
    print("   3. npm run build")
    print()
    print("   App will start with backend API only (no frontend UI)")
    
    @backend_app.get("/")
    async def root():
        return HTMLResponse(content="""
        <html>
            <head><title>SamarthVaani Backend</title></head>
            <body style="font-family: system-ui; padding: 2rem; max-width: 800px; margin: 0 auto;">
                <h1>🤝 SamarthVaani Backend API</h1>
                <p>The backend API is running, but the frontend hasn't been built yet.</p>
                
                <h2>Available Endpoints:</h2>
                <ul>
                    <li><strong>GET</strong> <code>/api/languages</code> - Get supported languages</li>
                    <li><strong>POST</strong> <code>/api/query</code> - Text-based RAG query</li>
                    <li><strong>POST</strong> <code>/api/voice-query</code> - Voice input/output query</li>
                    <li><strong>POST</strong> <code>/api/schemes</code> - Discover relevant schemes</li>
                    <li><strong>POST</strong> <code>/api/generate-application</code> - Generate application letters</li>
                </ul>
                
                <h2>To Build Frontend:</h2>
                <pre style="background: #f5f5f5; padding: 1rem; border-radius: 4px;">
cd samarthvaani_app/samarth-vaani-ui
npm install
npm run build
                </pre>
                
                <p><small>SamarthVaani v1.0 - AI Assistant for Persons with Disabilities</small></p>
            </body>
        </html>
        """)

# App configuration for Databricks Apps
app = backend_app

# Print startup summary
print()
print("="*80)
print("📋 STARTUP SUMMARY")
print("="*80)
print(f"🌐 Server: FastAPI")
print(f"📁 Frontend: {'✅ Available' if frontend_dist.exists() else '⚠️  Not built'}")
print(f"🔍 Vector Search: {'✅ Ready' if vs_index else '❌ Not connected'}")
print(f"🤖 LLM Service: {'✅ Ready' if ws_client else '❌ Not connected'}")
print(f"🎤 Voice Features: {'✅ Enabled' if SARVAM_AVAILABLE else '⚠️  Disabled (text-only)'}")
print(f"🌐 Languages: {len(SUPPORTED_LANGUAGES)}")
print()
print("📍 Endpoints:")
print("   • GET  / - Frontend UI (if built) or API info")
print("   • GET  /api/languages - Get supported languages")
print("   • POST /api/query - Text RAG query")
print("   • POST /api/voice-query - Voice query with audio I/O")
print("   • POST /api/schemes - Scheme discovery")
print("   • POST /api/generate-application - Application generation")
print("="*80)
print()

if __name__ == "__main__":
    import uvicorn
    
    print("🚀 Starting server on 0.0.0.0:8080...")
    print("="*80)
    
    try:
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=8080,
            log_level="info"
        )
    except Exception as e:
        print(f"❌ Server failed to start: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
