# 🔑 SARVAM API KEYS - QUICK REFERENCE

## 📍 File Location
```
/Users/am1221830@iitd.ac.in/samarthvaani_app/sarvam_code/.env
```

## 🔧 How to Edit

### Method 1: Databricks Workspace (Easiest)
1. Open Databricks workspace sidebar
2. Navigate: Workspace → Users → am1221830@iitd.ac.in → samarthvaani_app → sarvam_code
3. Click: `.env`
4. Replace placeholders with your actual keys
5. Save (Ctrl+S)

### Method 2: Python Script
```python
from samarthvaani_app.update_api_keys import update_api_keys

update_api_keys(
    stt_key="your_actual_saarika_key",
    tts_key="your_actual_bulbul_key"
)
```

## 🔗 Getting API Keys

**Visit:** https://www.sarvam.ai/

**Steps:**
1. Sign up / Log in
2. Go to API Keys section
3. Generate:
   - Saarika API key (Speech-to-Text)
   - Bulbul API key (Text-to-Speech)
4. Copy both keys
5. Add to `.env` file

## 📝 .env File Format

```bash
# Speech-to-Text API Key (Saarika)
SARVAM_STT_API_KEY=abc123xyz456789...

# Text-to-Speech API Key (Bulbul)
SARVAM_TTS_API_KEY=def789uvw012345...
```

**Important:**
- No quotes around the keys
- No spaces before/after the `=` sign
- Keep this file private

## ✅ Verify Keys Are Working

After adding keys and restarting app, check logs for:
```
✅ Sarvam code imported - 11 languages supported
```

## 🚀 Deployment Options

### Option A: Text-Only Mode (No Keys Needed)
- Works immediately
- 11 languages via text translation
- No voice features

### Option B: Full Voice Mode (Keys Required)
- Microphone voice input
- Audio voice output
- All text features included

## 💡 Recommendation

**Deploy text-only FIRST, add voice LATER:**
1. Deploy app now without keys → Test immediately
2. Get API keys later → Add when ready
3. Restart app → Voice features enabled

This way you have a working app TODAY! 🎉

---

**Need Help?**
- Read: `DEPLOYMENT_GUIDE.md`
- Check: `API_KEYS_README.md`
- Monitor: App logs for errors
