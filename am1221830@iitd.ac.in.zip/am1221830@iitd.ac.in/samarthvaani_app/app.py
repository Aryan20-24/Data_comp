#!/usr/bin/env python3
"""
SamarthVaani - Voice-Enabled Multilingual RAG Chatbot
Supports 11 Indian languages with voice and text input/output
"""
import gradio as gr
import sys
import os
import traceback
from typing import Optional, Tuple

print("="*80)
print("🚀 SAMARTHVAANI VOICE-ENABLED CHATBOT STARTING")
print("="*80)

# Add paths for sarvam_code and final_work
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sarvam_path = os.path.join(parent_dir, "sarvam_code")
final_work_path = os.path.join(parent_dir, "final_work (1)")

for path in [parent_dir, sarvam_path, final_work_path]:
    if path not in sys.path:
        sys.path.insert(0, path)

# Import integrated pipeline
try:
    print("📦 Importing integrated pipeline...")
    from integrated_pipeline import voice_rag_query, load_rag_pipeline
    from sarvam_code.config import SUPPORTED_LANGUAGES
    print("✅ Integrated pipeline imported")
    VOICE_AVAILABLE = True
except Exception as e:
    print(f"❌ Voice pipeline import failed: {e}")
    traceback.print_exc()
    VOICE_AVAILABLE = False
    SUPPORTED_LANGUAGES = {"en-IN": "English"}

# Import RAG components
try:
    print("📦 Importing Databricks components...")
    from databricks.vector_search.client import VectorSearchClient
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.serving import ChatMessage, ChatMessageRole
    print("✅ Databricks components imported")
except Exception as e:
    print(f"❌ Databricks import failed: {e}")
    VectorSearchClient = None
    WorkspaceClient = None

# Configuration
ENDPOINT_NAME = "samarthvaani_vs_endpoint"
INDEX_NAME = "samarthvaani.gold.rpwd_chunks_index"
LLM_MODEL = "databricks-meta-llama-3-3-70b-instruct"

# Initialize RAG clients
vsc_client = None
ws_client = None
vs_index = None

if VectorSearchClient:
    try:
        print(f"🔗 Connecting to Vector Search: {ENDPOINT_NAME}")
        vsc_client = VectorSearchClient(disable_notice=True)
        vs_index = vsc_client.get_index(endpoint_name=ENDPOINT_NAME, index_name=INDEX_NAME)
        print(f"✅ Connected to index: {INDEX_NAME}")
    except Exception as e:
        print(f"❌ Vector Search failed: {e}")

if WorkspaceClient:
    try:
        print("🔗 Connecting to Workspace...")
        ws_client = WorkspaceClient()
        print("✅ Workspace client initialized")
    except Exception as e:
        print(f"❌ Workspace failed: {e}")

# Define RAG pipeline function for integration
def rag_pipeline(query: str, top_k: int = 3, topic_filter: Optional[str] = None, verbose: bool = False) -> dict:
    """RAG pipeline function for integrated_pipeline.py"""
    if not vs_index or not ws_client:
        raise RuntimeError("RAG components not initialized")
    
    # Retrieve chunks
    results = vs_index.similarity_search(
        query_text=query,
        columns=["chunk_text", "topic", "source", "section_title"],
        num_results=top_k
    )
    
    chunks = []
    if results and 'result' in results and 'data_array' in results['result']:
        for row in results['result']['data_array']:
            chunks.append({
                'text': row[0],
                'topic': row[1],
                'source': row[2],
                'section': row[3]
            })
    
    # Build prompt
    context = "\n\n".join([f"[{c['source']}]\n{c['text'][:500]}" for c in chunks[:top_k]])
    prompt = f"""Context from official documents:
{context}

Question: {query}

Provide a helpful answer based on the context. Be concise and empathetic."""
    
    # Generate answer
    response = ws_client.serving_endpoints.query(
        name=LLM_MODEL,
        messages=[
            ChatMessage(role=ChatMessageRole.SYSTEM, content="You are SamarthVaani, helping with RPWD Act 2016."),
            ChatMessage(role=ChatMessageRole.USER, content=prompt)
        ],
        max_tokens=700,
        temperature=0.1
    )
    
    answer = response.choices[0].message.content
    
    # Add sources
    sources = "\n\n**Sources:** " + ", ".join([f"{c['source']} ({c['topic']})" for c in chunks[:3]])
    
    return {"answer": answer + sources, "chunks": chunks}

# Load RAG pipeline into integrated_pipeline module
if VOICE_AVAILABLE:
    import __main__
    __main__.rag_pipeline = rag_pipeline
    load_rag_pipeline()
    print("✅ RAG pipeline loaded into integrated module")

# Language options for dropdown
LANGUAGE_OPTIONS = [(f"{name} ({code})", code) for code, name in SUPPORTED_LANGUAGES.items()]

def process_query(
    text_input: str,
    audio_input: Optional[Tuple],
    input_language: str,
    output_language: str,
    enable_voice_output: bool
) -> Tuple[str, Optional[Tuple]]:
    """
    Process user query with text or voice input, return text and optional audio.
    
    Args:
        text_input: Text query
        audio_input: Audio tuple (sample_rate, audio_array) from microphone
        input_language: Language code for input
        output_language: Language code for output
        enable_voice_output: Whether to generate voice response
        
    Returns:
        (text_response, audio_output)
    """
    print(f"\n{'='*60}")
    print(f"📥 New Query")
    print(f"   Input Language: {SUPPORTED_LANGUAGES.get(input_language, input_language)}")
    print(f"   Output Language: {SUPPORTED_LANGUAGES.get(output_language, output_language)}")
    print(f"   Voice Output: {enable_voice_output}")
    
    # Determine input mode and content
    if audio_input is not None:
        input_mode = "voice"
        # Convert audio tuple to bytes (basic conversion - may need adjustment)
        sample_rate, audio_array = audio_input
        # For now, pass audio_array directly (integrated_pipeline handles it)
        user_input = audio_array
        print(f"   Mode: Voice (sample rate: {sample_rate})")
    elif text_input and text_input.strip():
        input_mode = "text"
        user_input = text_input.strip()
        print(f"   Mode: Text")
        print(f"   Query: {user_input[:100]}")
    else:
        return "⚠️ Please provide either text or voice input.", None
    
    # Check if voice pipeline available
    if not VOICE_AVAILABLE:
        return "⚠️ Voice pipeline not available. Please check configuration.", None
    
    # Determine output mode
    output_mode = "voice" if enable_voice_output else "text"
    
    try:
        # Call integrated voice RAG pipeline
        result = voice_rag_query(
            user_input=user_input,
            input_mode=input_mode,
            input_lang=input_language,
            output_mode=output_mode,
            output_lang=output_language,
            fast_mode=True,
            top_k=3,
            verbose=True
        )
        
        # Extract response
        text_response = result["answer"]
        audio_output = None
        
        if result.get("audio"):
            # Convert audio bytes to tuple format expected by Gradio
            # (sample_rate, audio_array)
            audio_output = (16000, result["audio"])  # Assuming 16kHz sample rate
        
        print(f"✅ Response generated")
        print(f"{'='*60}")
        
        return text_response, audio_output
        
    except Exception as e:
        error_msg = f"❌ Error: {str(e)}"
        print(error_msg)
        traceback.print_exc()
        return error_msg, None

# Create Gradio Interface
print("\n🎨 Creating Gradio interface...")

with gr.Blocks(
    title="🤝 SamarthVaani",
    theme=gr.themes.Soft(),
    css=".gradio-container {max-width: 1200px; margin: auto;}"
) as demo:
    
    gr.Markdown("""
    # 🤝 SamarthVaani - Voice-Enabled AI Assistant
    
    **Accessible Information System for India's Persons with Disabilities**
    
    Ask questions about RPWD Act 2016, government schemes, employment, education, and healthcare 
    in **11 Indian languages** using **text or voice** input!
    """)
    
    with gr.Row():
        with gr.Column(scale=1):
            gr.Markdown("### 📥 Input Options")
            
            input_language = gr.Dropdown(
                choices=LANGUAGE_OPTIONS,
                value="en-IN",
                label="Input Language",
                info="Language of your question"
            )
            
            text_input = gr.Textbox(
                label="Type your question",
                placeholder="What are the education rights for disabled children?",
                lines=3
            )
            
            gr.Markdown("**OR**")
            
            audio_input = gr.Audio(
                label="Speak your question",
                sources=["microphone"],
                type="numpy"
            )
            
        with gr.Column(scale=1):
            gr.Markdown("### 📤 Output Options")
            
            output_language = gr.Dropdown(
                choices=LANGUAGE_OPTIONS,
                value="en-IN",
                label="Output Language",
                info="Language for the answer"
            )
            
            enable_voice = gr.Checkbox(
                label="Enable voice output (Text-to-Speech)",
                value=False,
                info="Generate spoken response"
            )
    
    submit_btn = gr.Button("🔍 Get Answer", variant="primary", size="lg")
    
    gr.Markdown("---")
    gr.Markdown("### 💬 Response")
    
    with gr.Row():
        with gr.Column(scale=2):
            text_output = gr.Textbox(
                label="Answer",
                lines=10,
                show_copy_button=True
            )
        with gr.Column(scale=1):
            audio_output = gr.Audio(
                label="Voice Response",
                type="numpy",
                visible=True
            )
    
    # Examples
    gr.Markdown("---")
    gr.Markdown("### 💡 Example Questions")
    
    gr.Examples(
        examples=[
            ["What are the education rights for children with disabilities?", "en-IN", "en-IN", False],
            ["विकलांग बच्चों के शिक्षा अधिकार क्या हैं?", "hi-IN", "hi-IN", False],
            ["What employment schemes are available?", "en-IN", "ta-IN", True],
            ["How do I get a disability certificate?", "en-IN", "te-IN", False],
            ["What is the reservation quota in government jobs?", "en-IN", "en-IN", False],
        ],
        inputs=[text_input, input_language, output_language, enable_voice],
        label="Click to try"
    )
    
    gr.Markdown("""
    ---
    ### 📚 Knowledge Base
    
    * **1,414 curated chunks** from 8 official government documents (2,146 pages)
    * **RPWD Act 2016** complete text with sections and provisions
    * **Government schemes** and financial support programs
    * **Employment, education, healthcare** guidelines
    
    ### 🌍 Supported Languages (11)
    
    English, Hindi, Tamil, Telugu, Marathi, Bengali, Kannada, Malayalam, Gujarati, Punjabi, Odia
    """)
    
    # Connect button
    submit_btn.click(
        fn=process_query,
        inputs=[text_input, audio_input, input_language, output_language, enable_voice],
        outputs=[text_output, audio_output]
    )

print("✅ Gradio interface created")

# Launch
if __name__ == "__main__":
    print("\n🌐 Launching on 0.0.0.0:8080...")
    print("="*80)
    
    try:
        demo.launch(
            server_name="0.0.0.0",
            server_port=8080,
            share=False,
            show_error=True,
            show_api=False
        )
    except Exception as e:
        print(f"❌ Launch failed: {e}")
        traceback.print_exc()
        sys.exit(1)
