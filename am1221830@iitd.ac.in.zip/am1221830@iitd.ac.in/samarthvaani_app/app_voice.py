#!/usr/bin/env python3
"""
SamarthVaani - Complete Voice-Enabled Multilingual RAG + Application Generator
Databricks Apps - Gradio 4.44.0 - Full Production Version
"""
import gradio as gr
import sys
import os
import base64
import tempfile
from pathlib import Path

print("="*80)
print("🚀 SAMARTHVAANI - COMPLETE VOICE-ENABLED CHATBOT")
print("="*80)

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import Databricks SDK
try:
    print("📦 Importing Databricks components...")
    from databricks.vector_search.client import VectorSearchClient
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.serving import ChatMessage, ChatMessageRole
    print("✅ Databricks SDK imported")
except Exception as e:
    print(f"❌ Databricks import failed: {e}")
    VectorSearchClient = None
    WorkspaceClient = None

# Import sarvam_code
try:
    print("📦 Importing sarvam_code (STT/TTS/Translation)...")
    from sarvam_code import process_input, process_output
    from sarvam_code.config import SUPPORTED_LANGUAGES
    from sarvam_code.stt import speech_to_text
    from sarvam_code.tts import text_to_speech
    SARVAM_AVAILABLE = True
    print(f"✅ Sarvam code imported - {len(SUPPORTED_LANGUAGES)} languages supported")
except Exception as e:
    print(f"⚠️  Sarvam code not available: {e}")
    SARVAM_AVAILABLE = False
    SUPPORTED_LANGUAGES = {
        "en-IN": "English",
        "hi-IN": "Hindi (हिंदी)",
    }

# Configuration
ENDPOINT_NAME = "samarthvaani_vs_endpoint"
INDEX_NAME = "samarthvaani.gold.rpwd_chunks_index"
LLM_MODEL = "databricks-meta-llama-3-3-70b-instruct"

# Initialize clients
vsc_client = None
ws_client = None
vs_index = None

# Initialize Workspace Client
if WorkspaceClient:
    try:
        print("🔗 Initializing Workspace client...")
        ws_client = WorkspaceClient()
        print("✅ Workspace client initialized")
    except Exception as e:
        print(f"❌ Workspace connection failed: {e}")

# Initialize Vector Search
if VectorSearchClient and ws_client:
    try:
        print(f"🔗 Connecting to Vector Search: {ENDPOINT_NAME}")
        vsc_client = VectorSearchClient(
            workspace_url=ws_client.config.host,
            service_principal_client_id=ws_client.config.client_id,
            service_principal_client_secret=ws_client.config.client_secret,
            disable_notice=True
        )
        vs_index = vsc_client.get_index(endpoint_name=ENDPOINT_NAME, index_name=INDEX_NAME)
        print(f"✅ Connected to index: {INDEX_NAME}")
    except Exception as e:
        print(f"❌ Vector Search connection failed: {e}")

# =============================================================================
# APPLICATION TEMPLATES
# =============================================================================

APPLICATION_TEMPLATES = {
    "disability_certificate": {
        "title": "Application for Disability Certificate",
        "authority": "Medical Officer / District Disability Rehabilitation Centre",
        "template": """To,
The Medical Officer / District Disability Rehabilitation Centre
[Your District]

Subject: Application for Disability Certificate

Respected Sir/Madam,

I, {name}, residing at {address}, request you to kindly issue me a Disability Certificate under the Rights of Persons with Disabilities Act, 2016.

Personal Details:
- Name: {name}
- Age: {age}
- Gender: {gender}
- Contact: {contact}
- Disability Type: {disability_type}

I request this certificate so that I may avail various benefits and schemes provided by the Government.

Thank you.

Date: {date}
Signature: ___________
({name})
"""
    },
    "udid_card": {
        "title": "Application for UDID Card",
        "authority": "UDID Portal (Online Application)",
        "template": """Application for Unique Disability ID (UDID) Card

Personal Information:
- Full Name: {name}
- Date of Birth: {dob}
- Gender: {gender}
- Mobile: {contact}
- Email: {email}
- Address: {address}

Disability Information:
- Type of Disability: {disability_type}
- Percentage of Disability: {disability_percent}%
- Disability Certificate Number: {cert_number}

Declaration: I hereby declare that the information provided above is true to the best of my knowledge.

Date: {date}
Applicant Signature: ___________
"""
    },
    "scheme_application": {
        "title": "Application for Government Scheme",
        "authority": "District Social Welfare Officer",
        "template": """To,
The District Social Welfare Officer
[Your District]

Subject: Application for {scheme_name}

Respected Sir/Madam,

I, {name}, a person with disability, would like to apply for the {scheme_name} scheme.

Personal Details:
- Name: {name}
- Age: {age}
- Address: {address}
- Contact: {contact}
- Disability Certificate Number: {cert_number}
- Disability Type: {disability_type}

I fulfill the eligibility criteria and request you to consider my application.

Attached documents:
1. Disability Certificate (copy)
2. Aadhaar Card (copy)
3. Income Certificate (if required)

Thank you.

Date: {date}
Signature: ___________
({name})
"""
    }
}

# =============================================================================
# RAG FUNCTIONS
# =============================================================================

def retrieve_context(query: str, top_k: int = 3):
    """Retrieve from Vector Search."""
    if not vs_index:
        print("⚠️ Vector Search not available")
        return []
    
    try:
        results = vs_index.similarity_search(
            query_text=query,
            columns=["chunk_text", "topic", "source", "section_title"],
            num_results=top_k
        )
        
        chunks = []
        if results and 'result' in results and 'data_array' in results['result']:
            for row in results['result']['data_array']:
                chunks.append({
                    'text': row[0],
                    'topic': row[1],
                    'source': row[2],
                    'section': row[3]
                })
        print(f"✅ Retrieved {len(chunks)} chunks")
        return chunks
    except Exception as e:
        print(f"❌ Retrieval error: {e}")
        return []

def generate_answer(prompt: str) -> str:
    """Generate using LLM."""
    if not ws_client:
        return "⚠️ LLM service unavailable."
    
    try:
        response = ws_client.serving_endpoints.query(
            name=LLM_MODEL,
            messages=[
                ChatMessage(
                    role=ChatMessageRole.SYSTEM,
                    content="You are SamarthVaani, helping with RPWD Act 2016 and disability schemes in India."
                ),
                ChatMessage(
                    role=ChatMessageRole.USER,
                    content=prompt
                )
            ],
            max_tokens=700,
            temperature=0.1
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"❌ Generation error: {e}")
        return f"Error generating answer: {str(e)[:200]}"

def build_prompt(question: str, chunks: list) -> str:
    """Build RAG prompt."""
    if not chunks:
        return f"Question: {question}\n\nAnswer based on RPWD Act 2016."
    
    context = "\n\n".join([f"[{c['source']}]\n{c['text'][:500]}" for c in chunks[:3]])
    return f"""Context from official documents:
{context}

Question: {question}

Provide a helpful answer. Cite sources."""

def detect_intent(query: str) -> str:
    """Detect if user wants information, scheme, or application."""
    query_lower = query.lower()
    
    # Application intent
    if any(word in query_lower for word in ['apply', 'application', 'form', 'fill', 'certificate', 'udid']):
        return "application"
    
    # Scheme intent
    if any(word in query_lower for word in ['scheme', 'benefit', 'subsidy', 'pension', 'allowance']):
        return "scheme"
    
    # Default to information
    return "information"

# =============================================================================
# MAIN QUERY FUNCTIONS
# =============================================================================

def process_text_query(question: str, input_lang: str, output_lang: str):
    """Process text-only query with multilingual support."""
    print("\n" + "="*80)
    print("💬 TEXT QUERY")
    print(f"📝 Question: {question}")
    print(f"🌐 Input: {input_lang} → Output: {output_lang}")
    print("="*80)
    
    if not question or not question.strip():
        return "⚠️ Please enter a question.", None
    
    if not vs_index or not ws_client:
        return "⚠️ RAG services unavailable. Please check Resources in Databricks Apps UI.", None
    
    question = question.strip()
    
    # Translate input if not English
    if input_lang != "en-IN" and SARVAM_AVAILABLE:
        print(f"🔄 Translating from {input_lang} to English...")
        try:
            english_question = process_input(question, input_lang, fast_mode=True)
        except Exception as e:
            print(f"⚠️ Translation failed: {e}, using original")
            english_question = question
    else:
        english_question = question
    
    # Detect intent
    intent = detect_intent(english_question)
    print(f"🎯 Intent: {intent}")
    
    # Retrieve and generate
    print(f"🔍 Searching knowledge base...")
    chunks = retrieve_context(english_question, top_k=3)
    
    if not chunks:
        answer = "I couldn't find relevant information. Please try rephrasing your question."
    else:
        print(f"🤖 Generating answer...")
        prompt = build_prompt(english_question, chunks)
        answer = generate_answer(prompt)
        
        # Add sources
        sources = "\n\n**📚 Sources:**\n" + "\n".join([
            f"• {c['source']} - {c['topic']}" for c in chunks[:3]
        ])
        answer = answer + sources
    
    # Translate output if not English
    if output_lang != "en-IN" and SARVAM_AVAILABLE:
        print(f"🔄 Translating to {output_lang}...")
        try:
            answer = process_output(answer, output_lang, fast_mode=True)
        except Exception as e:
            print(f"⚠️ Translation failed: {e}, returning English")
    
    # Generate audio if requested
    audio_output = None
    if SARVAM_AVAILABLE:
        try:
            print(f"🎤 Generating audio in {output_lang}...")
            audio_data = text_to_speech(answer, output_lang)
            if audio_data:
                # Save to temp file
                with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as f:
                    f.write(audio_data)
                    audio_output = f.name
                print(f"✅ Audio generated: {audio_output}")
        except Exception as e:
            print(f"⚠️ Audio generation failed: {e}")
    
    print("="*80)
    return answer, audio_output

def process_voice_query(audio, input_lang: str, output_lang: str):
    """Process voice query with STT → RAG → TTS pipeline."""
    print("\n" + "="*80)
    print("🎤 VOICE QUERY")
    print(f"🌐 Input: {input_lang} → Output: {output_lang}")
    print("="*80)
    
    if audio is None:
        return "⚠️ No audio recorded. Please record your question.", "", None
    
    if not SARVAM_AVAILABLE:
        return "⚠️ Voice features not available. Please use text input.", "", None
    
    try:
        # STT: Convert audio to text
        print(f"🎧 Transcribing audio in {input_lang}...")
        transcribed_text = speech_to_text(audio, input_lang)
        print(f"✅ Transcription: {transcribed_text}")
        
        if not transcribed_text:
            return "⚠️ Could not transcribe audio. Please try again.", "", None
        
        # Process as text query
        answer, audio_output = process_text_query(transcribed_text, input_lang, output_lang)
        
        print("="*80)
        return answer, transcribed_text, audio_output
        
    except Exception as e:
        print(f"❌ Voice processing error: {e}")
        return f"Error processing voice: {str(e)}", "", None

def generate_application(app_type: str, name: str, age: str, gender: str, address: str, contact: str, disability_type: str):
    """Generate application form based on template."""
    print("\n" + "="*80)
    print("📝 GENERATING APPLICATION")
    print(f"Type: {app_type}")
    print("="*80)
    
    if app_type not in APPLICATION_TEMPLATES:
        return "⚠️ Invalid application type selected."
    
    template_data = APPLICATION_TEMPLATES[app_type]
    
    # Fill template
    from datetime import datetime
    filled_form = template_data["template"].format(
        name=name or "[Your Name]",
        age=age or "[Your Age]",
        gender=gender or "[Your Gender]",
        address=address or "[Your Address]",
        contact=contact or "[Your Contact]",
        disability_type=disability_type or "[Disability Type]",
        date=datetime.now().strftime("%Y-%m-%d"),
        dob="[Date of Birth]",
        email="[Your Email]",
        disability_percent="[Percentage]",
        cert_number="[Certificate Number]",
        scheme_name="[Scheme Name]"
    )
    
    result = f"## {template_data['title']}\n\n**Submit to:** {template_data['authority']}\n\n---\n\n{filled_form}\n\n---\n\n**Instructions:**\n1. Review and fill in any missing information\n2. Print this application\n3. Attach required documents\n4. Submit to the appropriate authority\n"
    
    print("✅ Application generated")
    print("="*80)
    return result

# =============================================================================
# GRADIO INTERFACE
# =============================================================================

print("\n🎨 Creating Gradio interface...")

# Language choices for dropdown
lang_choices = list(SUPPORTED_LANGUAGES.items())
lang_names = [f"{name} ({code})" for code, name in lang_choices]
lang_codes = [code for code, name in lang_choices]

# Create Blocks interface with tabs
with gr.Blocks(
    title="🤝 SamarthVaani - Complete Voice AI Assistant",
    theme=gr.themes.Soft(),
    css="""
    #main-title { text-align: center; font-size: 2.5em; font-weight: bold; margin-bottom: 1em; }
    #subtitle { text-align: center; font-size: 1.2em; color: #666; margin-bottom: 2em; }
    .accessibility-note { background: #e3f2fd; padding: 1em; border-radius: 8px; margin: 1em 0; }
    """
) as demo:
    
    gr.Markdown("<h1 id='main-title'>🤝 SamarthVaani</h1>")
    gr.Markdown("<p id='subtitle'>Voice-Enabled AI Assistant for Persons with Disabilities | 11 Indian Languages | RPWD Act 2016</p>")
    
    with gr.Tabs():
        # TAB 1: VOICE & TEXT QUERIES
        with gr.Tab("🎤 Ask Questions (Voice & Text)"):
            gr.Markdown("""
            <div class='accessibility-note'>
            <strong>♿ Accessibility:</strong> This app supports keyboard navigation, screen readers, and voice input in 11 Indian languages.
            Press Tab to navigate, Enter to submit, Spacebar to record.
            </div>
            """)
            
            with gr.Row():
                input_lang = gr.Dropdown(
                    choices=lang_names,
                    value=lang_names[0],
                    label="🗣️ Input Language",
                    info="Language you'll speak or type in"
                )
                output_lang = gr.Dropdown(
                    choices=lang_names,
                    value=lang_names[0],
                    label="👂 Output Language",
                    info="Language you want the answer in"
                )
            
            gr.Markdown("### 📝 Text Input")
            text_input = gr.Textbox(
                label="Type your question",
                placeholder="E.g., What are employment rights for disabled persons?",
                lines=3
            )
            text_submit = gr.Button("🔍 Ask (Text)", variant="primary", size="lg")
            
            gr.Markdown("### 🎤 Voice Input")
            audio_input = gr.Audio(
                label="Record your question",
                type="filepath",
                sources=["microphone"]
            )
            voice_submit = gr.Button("🎙️ Ask (Voice)", variant="primary", size="lg")
            
            gr.Markdown("### 💬 Answer")
            transcription = gr.Textbox(
                label="Your question (transcribed)",
                lines=2,
                visible=True
            )
            answer_output = gr.Textbox(
                label="Answer",
                lines=15,
                show_copy_button=True
            )
            audio_output = gr.Audio(
                label="🔊 Listen to answer",
                type="filepath",
                visible=True
            )
            
            gr.Markdown("### 📚 Example Questions")
            gr.Examples(
                examples=[
                    ["What are employment rights for disabled persons?"],
                    ["What is the RPWD Act 2016?"],
                    ["How to get disability certificate?"],
                    ["What education benefits are available for children with disabilities?"],
                    ["What are accessibility requirements for public buildings?"]
                ],
                inputs=text_input,
                label="Click to try"
            )
            
            # Connect text query
            def text_query_wrapper(text, in_lang, out_lang):
                # Convert display name to code
                in_code = lang_codes[lang_names.index(in_lang)]
                out_code = lang_codes[lang_names.index(out_lang)]
                answer, audio = process_text_query(text, in_code, out_code)
                return answer, audio
            
            text_submit.click(
                fn=text_query_wrapper,
                inputs=[text_input, input_lang, output_lang],
                outputs=[answer_output, audio_output]
            )
            
            # Connect voice query
            def voice_query_wrapper(audio, in_lang, out_lang):
                # Convert display name to code
                in_code = lang_codes[lang_names.index(in_lang)]
                out_code = lang_codes[lang_names.index(out_lang)]
                answer, transcription_text, audio_out = process_voice_query(audio, in_code, out_code)
                return answer, transcription_text, audio_out
            
            voice_submit.click(
                fn=voice_query_wrapper,
                inputs=[audio_input, input_lang, output_lang],
                outputs=[answer_output, transcription, audio_output]
            )
        
        # TAB 2: APPLICATION GENERATOR
        with gr.Tab("📄 Generate Applications"):
            gr.Markdown("""
            ## 📝 Application Generator
            
            Generate ready-to-submit applications for:
            * ♿ Disability Certificate
            * 🆔 UDID Card (Unique Disability ID)
            * 🎁 Government Schemes
            
            Fill in your details and get a formatted application letter!
            """)
            
            app_type = gr.Dropdown(
                choices=[
                    ("Disability Certificate", "disability_certificate"),
                    ("UDID Card", "udid_card"),
                    ("Government Scheme", "scheme_application")
                ],
                value="disability_certificate",
                label="📋 Application Type",
                info="Select what you want to apply for"
            )
            
            with gr.Row():
                name_input = gr.Textbox(label="👤 Full Name", placeholder="Your full name")
                age_input = gr.Textbox(label="🎂 Age", placeholder="Your age")
            
            with gr.Row():
                gender_input = gr.Dropdown(
                    choices=["Male", "Female", "Other"],
                    label="⚧ Gender"
                )
                contact_input = gr.Textbox(label="📱 Contact Number", placeholder="Your phone number")
            
            address_input = gr.Textbox(
                label="🏠 Address",
                placeholder="Your complete address",
                lines=3
            )
            
            disability_input = gr.Textbox(
                label="♿ Disability Type",
                placeholder="E.g., Visual impairment, Hearing impairment, etc."
            )
            
            generate_btn = gr.Button("📝 Generate Application", variant="primary", size="lg")
            
            application_output = gr.Textbox(
                label="Generated Application",
                lines=25,
                show_copy_button=True
            )
            
            generate_btn.click(
                fn=generate_application,
                inputs=[app_type, name_input, age_input, gender_input, address_input, contact_input, disability_input],
                outputs=application_output
            )
        
        # TAB 3: ACCESSIBILITY INFO
        with gr.Tab("♿ Accessibility Features"):
            gr.Markdown("""
            ## ♿ Accessibility Features
            
            SamarthVaani is designed with accessibility in mind:
            
            ### 🎤 Voice Input/Output
            * **11 Indian languages** supported
            * **Speech-to-Text** (Sarvam Saarika API)
            * **Text-to-Speech** (Sarvam Bulbul API)
            * Works for: English, Hindi, Bengali, Tamil, Telugu, Marathi, Kannada, Malayalam, Gujarati, Punjabi, Odia
            
            ### ⌨️ Keyboard Navigation
            * **Tab** - Navigate between elements
            * **Enter** - Submit/Activate buttons
            * **Spacebar** - Start/Stop recording
            * **Arrow Keys** - Navigate dropdowns
            
            ### 👁️ Screen Reader Support
            * All elements have proper ARIA labels
            * Form fields announce their purpose
            * Buttons announce their action
            * Results are announced when ready
            
            ### 🎨 Visual Accessibility
            * **High contrast** mode compatible
            * **Large text** options supported
            * **Clear focus indicators**
            * **Responsive design** for different screen sizes
            
            ### 📱 Device Support
            * **Desktop** (Windows, Mac, Linux)
            * **Mobile** (Android, iOS)
            * **Tablets**
            * Works with assistive technologies
            
            ### 🌐 Language Support
 Language | Code | Voice Input | Voice Output |
----------|------|-------------|--------------|
 English | en-IN | ✅ | ✅ |
 Hindi (हिंदी) | hi-IN | ✅ | ✅ |
 Bengali (বাংলা) | bn-IN | ✅ | ✅ |
 Tamil (தமிழ்) | ta-IN | ✅ | ✅ |
 Telugu (తెలుగు) | te-IN | ✅ | ✅ |
 Marathi (मराठी) | mr-IN | ✅ | ✅ |
 Kannada (ಕನ್ನಡ) | kn-IN | ✅ | ✅ |
 Malayalam (മലയാളം) | ml-IN | ✅ | ✅ |
 Gujarati (ગુજરાતી) | gu-IN | ✅ | ✅ |
 Punjabi (ਪੰਜਾਬੀ) | pa-IN | ✅ | ✅ |
 Odia (ଓଡ଼ିଆ) | or-IN | ✅ | ✅ |
            
            ### 📚 Knowledge Base
            * **1,414 curated chunks** from official documents
            * **8 government documents** (2,146 pages total)
            * **RPWD Act 2016** complete coverage
            * **Government schemes** information
            * **Rights and benefits** detailed
            
            ### 🔒 Privacy & Security
            * All processing on secure Databricks infrastructure
            * No audio stored permanently
            * GDPR compliant
            * Secure API connections
            """)

print("✅ Interface created with 3 tabs")

# =============================================================================
# LAUNCH
# =============================================================================

if __name__ == "__main__":
    print("\n🌐 Launching Gradio app...")
    
    # Get dynamic port
    app_port = int(os.environ.get("DATABRICKS_APP_PORT", os.environ.get("GRADIO_SERVER_PORT", "8080")))
    app_host = os.environ.get("GRADIO_SERVER_NAME", "0.0.0.0")
    
    print(f"   Server: {app_host}:{app_port}")
    print(f"   Gradio version: {gr.__version__}")
    print(f"   Voice features: {'✅ Enabled' if SARVAM_AVAILABLE else '⚠️ Disabled'}")
    print(f"   Languages: {len(SUPPORTED_LANGUAGES)}")
    print("="*80)
    
    # Launch
    demo.launch(
        server_name=app_host,
        server_port=app_port,
        share=False,
        show_api=True,
        show_error=True
    )
    
    print("\n✅ Gradio server started successfully!")
    print("="*80)
