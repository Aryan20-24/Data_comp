import gradio as gr

def chat(message, history):
    """Simple echo bot for testing."""
    return f"Echo: {message}"

# Minimal interface
demo = gr.ChatInterface(
    fn=chat,
    title="🧪 SamarthVaani Test",
    description="Minimal test app to verify deployment works"
)

if __name__ == "__main__":
    print("Starting minimal test app on port 8080...")
    demo.launch(
        server_name="0.0.0.0",
        server_port=8080,
        share=False,
        show_error=True
    )
