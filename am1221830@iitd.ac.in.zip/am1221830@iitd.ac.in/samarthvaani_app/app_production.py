#!/usr/bin/env python3
"""
SamarthVaani Chatbot - AI Assistant for Persons with Disabilities
"""
import gradio as gr
import sys
import traceback

print("="*80)
print("🚀 SAMARTHVAANI CHATBOT STARTING")
print("="*80)

# Step 1: Import dependencies with error handling
try:
    print("📦 Importing databricks-vectorsearch...")
    from databricks.vector_search.client import VectorSearchClient
    print("✅ Vector Search imported")
except Exception as e:
    print(f"❌ Vector Search import failed: {e}")
    VectorSearchClient = None

try:
    print("📦 Importing databricks-sdk...")
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.serving import ChatMessage, ChatMessageRole
    print("✅ Databricks SDK imported")
except Exception as e:
    print(f"❌ Databricks SDK import failed: {e}")
    WorkspaceClient = None

# Configuration
ENDPOINT_NAME = "samarthvaani_vs_endpoint"
INDEX_NAME = "samarthvaani.gold.rpwd_chunks_index"
LLM_MODEL = "databricks-meta-llama-3-3-70b-instruct"

# Step 2: Initialize clients
vsc_client = None
ws_client = None
vs_index = None

if VectorSearchClient:
    try:
        print(f"🔗 Connecting to Vector Search endpoint: {ENDPOINT_NAME}")
        # In Databricks Apps, authentication is automatic
        vsc_client = VectorSearchClient(disable_notice=True, workspace_url=None)
        vs_index = vsc_client.get_index(endpoint_name=ENDPOINT_NAME, index_name=INDEX_NAME)
        print(f"✅ Connected to index: {INDEX_NAME}")
    except Exception as e:
        print(f"❌ Vector Search connection failed: {e}")
        traceback.print_exc()

if WorkspaceClient:
    try:
        print("🔗 Connecting to Workspace...")
        ws_client = WorkspaceClient()
        print("✅ Workspace client initialized")
    except Exception as e:
        print(f"❌ Workspace connection failed: {e}")
        traceback.print_exc()

# Step 3: Define chat functions
def retrieve_context(query: str, top_k: int = 3):
    """Retrieve from Vector Search."""
    if not vs_index:
        print("⚠️ Vector Search not available")
        return []
    
    try:
        results = vs_index.similarity_search(
            query_text=query,
            columns=["chunk_text", "topic", "source", "section_title"],
            num_results=top_k
        )
        
        chunks = []
        if results and 'result' in results and 'data_array' in results['result']:
            for row in results['result']['data_array']:
                chunks.append({
                    'text': row[0],
                    'topic': row[1],
                    'source': row[2],
                    'section': row[3]
                })
        print(f"✅ Retrieved {len(chunks)} chunks")
        return chunks
    except Exception as e:
        print(f"❌ Retrieval error: {e}")
        return []

def generate_answer(prompt: str):
    """Generate using LLM."""
    if not ws_client:
        return "⚠️ LLM service unavailable. Please check app configuration."
    
    try:
        response = ws_client.serving_endpoints.query(
            name=LLM_MODEL,
            messages=[
                ChatMessage(
                    role=ChatMessageRole.SYSTEM,
                    content="You are SamarthVaani, helping with RPWD Act 2016 and disability schemes in India."
                ),
                ChatMessage(
                    role=ChatMessageRole.USER,
                    content=prompt
                )
            ],
            max_tokens=700,
            temperature=0.1
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"❌ Generation error: {e}")
        return f"I encountered an error: {str(e)[:200]}"

def build_prompt(question: str, chunks: list) -> str:
    """Build RAG prompt."""
    if not chunks:
        return f"Question: {question}\n\nPlease answer based on your knowledge of RPWD Act 2016."
    
    context = "\n\n".join([f"[{c['source']}]\n{c['text'][:500]}" for c in chunks[:3]])
    return f"""Context from official documents:
{context}

Question: {question}

Provide a helpful answer based on the context. Cite sources."""

def chat(message: str, history):
    """Main chat function."""
    if not message or not message.strip():
        yield "Please ask a question."
        return
    
    print(f"\n💬 User: {message}")
    
    # Check if services available
    if not vs_index:
        yield "⚠️ Retrieval service unavailable. Vector Search not connected."
        return
    
    if not ws_client:
        yield "⚠️ Answer generation unavailable. LLM service not connected."
        return
    
    # Retrieve
    chunks = retrieve_context(message, top_k=3)
    
    if not chunks:
        yield "I couldn't find relevant information. Try rephrasing your question."
        return
    
    # Generate
    prompt = build_prompt(message, chunks)
    answer = generate_answer(prompt)
    
    # Add sources
    sources = "\n\n**📚 Sources:**\n" + "\n".join([
        f"• {c['source']} ({c['topic']})" for c in chunks[:3]
    ])
    
    result = answer + sources
    print(f"✅ Response generated ({len(result)} chars)")
    yield result

# Step 4: Create Gradio UI
print("\n🎨 Creating Gradio interface...")

demo = gr.ChatInterface(
    fn=chat,
    title="🤝 SamarthVaani",
    description="""
**AI Assistant for India's Persons with Disabilities**

Ask about RPWD Act 2016, schemes, employment, education, healthcare, and benefits.

*Knowledge Base: 1,414 chunks from 8 official government documents*
    """,
    examples=[
        "What education rights do disabled children have?",
        "What employment schemes are available?",
        "How do I get a disability certificate?",
        "What is the reservation quota in jobs?",
        "What healthcare benefits are available?"
    ],
    theme=gr.themes.Soft(),
    chatbot=gr.Chatbot(height=450, show_label=False)
)

print("✅ Gradio interface created")

# Step 5: Launch
if __name__ == "__main__":
    print("\n🌐 Launching on 0.0.0.0:8080...")
    print("="*80)
    
    try:
        demo.launch(
            server_name="0.0.0.0",
            server_port=8080,
            share=False,
            show_error=True,
            show_api=False
        )
    except Exception as e:
        print(f"❌ Launch failed: {e}")
        traceback.print_exc()
        sys.exit(1)
