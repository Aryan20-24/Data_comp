import { createContext, useContext, useState, ReactNode } from "react";
import type { QueryResponse, Scheme, Source } from "@/api/client";

interface QueryContextType {
  // Current query state
  currentQuery: string;
  setCurrentQuery: (query: string) => void;
  
  // Response data
  currentResponse: QueryResponse | null;
  setCurrentResponse: (response: QueryResponse | null) => void;
  
  // Loading state
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  
  // Error state
  error: string | null;
  setError: (error: string | null) => void;
  
  // Language settings
  inputLanguage: string;
  setInputLanguage: (lang: string) => void;
  outputLanguage: string;
  setOutputLanguage: (lang: string) => void;
  
  // Audio output
  audioUrl: string | null;
  setAudioUrl: (url: string | null) => void;
  
  // Enable voice output
  enableVoiceOutput: boolean;
  setEnableVoiceOutput: (enable: boolean) => void;
}

const QueryContext = createContext<QueryContextType | undefined>(undefined);

export function QueryProvider({ children }: { children: ReactNode }) {
  const [currentQuery, setCurrentQuery] = useState("");
  const [currentResponse, setCurrentResponse] = useState<QueryResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [inputLanguage, setInputLanguage] = useState("en-IN");
  const [outputLanguage, setOutputLanguage] = useState("en-IN");
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [enableVoiceOutput, setEnableVoiceOutput] = useState(false);

  return (
    <QueryContext.Provider
      value={{
        currentQuery,
        setCurrentQuery,
        currentResponse,
        setCurrentResponse,
        isLoading,
        setIsLoading,
        error,
        setError,
        inputLanguage,
        setInputLanguage,
        outputLanguage,
        setOutputLanguage,
        audioUrl,
        setAudioUrl,
        enableVoiceOutput,
        setEnableVoiceOutput,
      }}
    >
      {children}
    </QueryContext.Provider>
  );
}

export function useQuery() {
  const context = useContext(QueryContext);
  if (context === undefined) {
    throw new Error("useQuery must be used within a QueryProvider");
  }
  return context;
}

// Helper function to convert base64 audio to blob URL
export function base64ToAudioUrl(base64: string): string {
  const byteCharacters = atob(base64);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  const blob = new Blob([byteArray], { type: "audio/wav" });
  return URL.createObjectURL(blob);
}
