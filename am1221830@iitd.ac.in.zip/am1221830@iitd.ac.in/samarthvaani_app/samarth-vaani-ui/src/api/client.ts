/**
 * SamarthVaani API Client
 * Connects React UI to FastAPI backend
 */

const API_BASE = "/api";  // Backend API base URL

// =============================================================================
// TYPE DEFINITIONS
// =============================================================================

export interface QueryRequest {
  text: string;
  input_language: string;
  output_language: string;
  fast_mode: boolean;
}

export interface Source {
  content: string;
  score?: number;
  metadata?: {
    source?: string;
    topic?: string;
    [key: string]: any;
  };
}

export interface Scheme {
  scheme_name: string;
  description: string;
  eligibility?: string;
  benefits?: string;
  how_to_apply?: string;
  confidence_score?: number;
}

export interface QueryResponse {
  answer: string;
  sources: Source[];
  intent: "information" | "schemes" | "application";
  schemes: Scheme[];
  language: string;
}

export interface VoiceQueryResponse {
  transcribed: string;
  answer: string;
  audio_base64: string | null;
  sources: Source[];
  intent: string;
  language: string;
}

export interface ApplicationRequest {
  scheme_name: string;
  user_details: {
    name?: string;
    age?: string;
    address?: string;
    district?: string;
    state?: string;
    contact_number?: string;
    email?: string;
    disability_type?: string;
    disability_percentage?: string;
    aadhar_number?: string;
    [key: string]: string | undefined;
  };
  language: string;
}

export interface ApplicationResponse {
  success: boolean;
  application_text: string;
  template_used?: string;
  language: string;
}

export interface SchemeQueryRequest {
  query?: string;
  disability_type?: string;
  state?: string;
  language: string;
}

export interface SchemeQueryResponse {
  schemes: Scheme[];
  count: number;
  language: string;
}

export interface LanguagesResponse {
  languages: { [key: string]: string };
  voice_available: boolean;
}

// =============================================================================
// API FUNCTIONS
// =============================================================================

/**
 * Query the RAG system with text input
 */
export async function queryRAG(request: QueryRequest): Promise<QueryResponse> {
  try {
    const response = await fetch(`${API_BASE}/query`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || `API error: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Query RAG error:", error);
    throw error;
  }
}

/**
 * Query with voice input (audio file)
 */
export async function queryWithVoice(
  audioFile: File,
  inputLanguage: string,
  outputLanguage: string,
  fastMode: boolean = true
): Promise<VoiceQueryResponse> {
  try {
    const formData = new FormData();
    formData.append("audio", audioFile);
    formData.append("input_language", inputLanguage);
    formData.append("output_language", outputLanguage);
    formData.append("fast_mode", fastMode.toString());

    const response = await fetch(`${API_BASE}/voice-query`, {
      method: "POST",
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || `API error: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Voice query error:", error);
    throw error;
  }
}

/**
 * Discover schemes based on query/filters
 */
export async function discoverSchemes(
  request: SchemeQueryRequest
): Promise<SchemeQueryResponse> {
  try {
    const response = await fetch(`${API_BASE}/schemes`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || `API error: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Discover schemes error:", error);
    throw error;
  }
}

/**
 * Generate application letter/form
 */
export async function generateApplication(
  request: ApplicationRequest
): Promise<ApplicationResponse> {
  try {
    const response = await fetch(`${API_BASE}/generate-application`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || `API error: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Generate application error:", error);
    throw error;
  }
}

/**
 * Get supported languages
 */
export async function getSupportedLanguages(): Promise<LanguagesResponse> {
  try {
    const response = await fetch(`${API_BASE}/languages`, {
      method: "GET",
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || `API error: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Get languages error:", error);
    throw error;
  }
}

/**
 * Health check
 */
export async function healthCheck(): Promise<any> {
  try {
    const response = await fetch("/", {
      method: "GET",
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Health check error:", error);
    throw error;
  }
}
