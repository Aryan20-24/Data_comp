import { useState, useRef } from "react";
import { Mic, Send, Volume2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAccessibility } from "@/contexts/AccessibilityContext";
import { useQuery, base64ToAudioUrl } from "@/contexts/QueryContext";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { queryRAG, queryWithVoice } from "@/api/client";
import { useToast } from "@/hooks/use-toast";

// Supported languages
const LANGUAGES = {
  "en-IN": "English",
  "hi-IN": "Hindi (हिंदी)",
  "ta-IN": "Tamil (தமிழ்)",
  "te-IN": "Telugu (తెలుగు)",
  "mr-IN": "Marathi (मराठी)",
  "bn-IN": "Bengali (বাংলা)",
  "kn-IN": "Kannada (ಕನ್ನಡ)",
  "ml-IN": "Malayalam (മലയാളം)",
  "gu-IN": "Gujarati (ગુજરાતી)",
  "pa-IN": "Punjabi (ਪੰਜਾਬੀ)",
  "or-IN": "Odia (ଓଡ଼ିଆ)",
};

const InputConsole = () => {
  const [inputMode, setInputMode] = useState<"voice" | "text">("text");
  const [message, setMessage] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const { fastMode, setFastMode } = useAccessibility();
  const {
    setCurrentQuery,
    setCurrentResponse,
    isLoading,
    setIsLoading,
    setError,
    inputLanguage,
    setInputLanguage,
    outputLanguage,
    setOutputLanguage,
    enableVoiceOutput,
    setEnableVoiceOutput,
    setAudioUrl,
  } = useQuery();
  
  const { toast } = useToast();

  // Handle text query
  const handleSend = async () => {
    if (!message.trim() || isLoading) return;

    const query = message.trim();
    setMessage("");
    setCurrentQuery(query);
    setIsLoading(true);
    setError(null);
    setCurrentResponse(null);

    try {
      const response = await queryRAG({
        text: query,
        input_language: inputLanguage,
        output_language: outputLanguage,
        fast_mode: fastMode,
      });

      setCurrentResponse(response);
      
      toast({
        title: "Query Successful",
        description: `Found ${response.sources.length} relevant sources`,
      });

      // If voice output is enabled and we got audio, set it
      if (enableVoiceOutput && response.intent === "information") {
        // Note: Text query doesn't return audio by default
        // Would need to call TTS separately or use voice query endpoint
      }
    } catch (error) {
      console.error("Query failed:", error);
      const errorMessage = error instanceof Error ? error.message : "Failed to process query";
      setError(errorMessage);
      
      toast({
        title: "Query Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle voice recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/wav" });
        await handleVoiceQuery(audioBlob);
        
        // Stop all tracks
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setIsListening(true);
      
      toast({
        title: "Recording Started",
        description: "Speak your question now...",
      });
    } catch (error) {
      console.error("Failed to start recording:", error);
      toast({
        title: "Recording Failed",
        description: "Could not access microphone. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsListening(false);
    }
  };

  const handleVoiceClick = () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  // Handle voice query
  const handleVoiceQuery = async (audioBlob: Blob) => {
    setIsLoading(true);
    setError(null);
    setCurrentResponse(null);
    setCurrentQuery("(Voice input)");

    try {
      // Convert blob to File
      const audioFile = new File([audioBlob], "recording.wav", { type: "audio/wav" });

      const response = await queryWithVoice(
        audioFile,
        inputLanguage,
        outputLanguage,
        fastMode
      );

      // Set transcribed query
      setCurrentQuery(response.transcribed || "(Voice input)");

      // Set response
      setCurrentResponse({
        answer: response.answer,
        sources: response.sources,
        intent: response.intent as any,
        schemes: [],
        language: response.language,
      });

      // Set audio URL if available
      if (response.audio_base64) {
        const audioUrl = base64ToAudioUrl(response.audio_base64);
        setAudioUrl(audioUrl);
      }

      toast({
        title: "Voice Query Successful",
        description: `Transcribed: ${response.transcribed}`,
      });
    } catch (error) {
      console.error("Voice query failed:", error);
      const errorMessage = error instanceof Error ? error.message : "Failed to process voice input";
      setError(errorMessage);
      
      toast({
        title: "Voice Query Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="rounded-2xl border bg-card p-5 shadow-sm">
      {/* Language Selection */}
      <div className="mb-4 grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1 block text-xs font-medium text-muted-foreground">
            Input Language
          </label>
          <Select value={inputLanguage} onValueChange={setInputLanguage}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(LANGUAGES).map(([code, name]) => (
                <SelectItem key={code} value={code}>
                  {name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="mb-1 block text-xs font-medium text-muted-foreground">
            Output Language
          </label>
          <Select value={outputLanguage} onValueChange={setOutputLanguage}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(LANGUAGES).map(([code, name]) => (
                <SelectItem key={code} value={code}>
                  {name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Fast Mode & Voice Output */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Switch
            checked={fastMode}
            onCheckedChange={setFastMode}
            aria-label="Toggle fast mode"
            id="fast-mode"
          />
          <label htmlFor="fast-mode" className="text-sm font-semibold text-foreground cursor-pointer">
            Fast Mode
          </label>
          <Tooltip>
            <TooltipTrigger asChild>
              <span className="text-xs text-muted-foreground underline decoration-dotted cursor-help">
                What's this?
              </span>
            </TooltipTrigger>
            <TooltipContent className="max-w-xs text-sm">
              <p><strong>ON:</strong> Direct fast translation.</p>
              <p><strong>OFF:</strong> High-accuracy Indic AI translation.</p>
            </TooltipContent>
          </Tooltip>
        </div>
        
        <div className="flex items-center gap-2">
          <Switch
            checked={enableVoiceOutput}
            onCheckedChange={setEnableVoiceOutput}
            aria-label="Enable voice output"
            id="voice-output"
          />
          <label htmlFor="voice-output" className="text-sm font-semibold text-foreground cursor-pointer">
            Voice Output
          </label>
        </div>
      </div>

      {/* Input Mode Toggle */}
      <div className="mb-4 flex rounded-xl bg-muted p-1" role="tablist">
        <button
          role="tab"
          aria-selected={inputMode === "voice"}
          onClick={() => setInputMode("voice")}
          className={`flex-1 rounded-lg py-2.5 text-sm font-semibold transition-colors ${
            inputMode === "voice" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          🎙️ Voice Input
        </button>
        <button
          role="tab"
          aria-selected={inputMode === "text"}
          onClick={() => setInputMode("text")}
          className={`flex-1 rounded-lg py-2.5 text-sm font-semibold transition-colors ${
            inputMode === "text" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          ⌨️ Text Input
        </button>
      </div>

      {/* Input Area */}
      {inputMode === "voice" ? (
        <div className="flex flex-col items-center gap-4 py-8">
          <button
            aria-label={isListening ? "Stop listening" : "Start voice input"}
            onClick={handleVoiceClick}
            disabled={isLoading}
            className={`flex h-24 w-24 items-center justify-center rounded-full bg-primary text-primary-foreground transition-transform hover:scale-105 ${
              isListening ? "animate-pulse" : ""
            } ${isLoading ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            {isLoading ? (
              <Loader2 className="h-10 w-10 animate-spin" />
            ) : (
              <Mic className="h-10 w-10" />
            )}
          </button>
          <p className="text-sm font-medium text-muted-foreground">
            {isLoading
              ? "Processing..."
              : isListening
              ? "Listening… Tap to stop"
              : "Tap to speak"}
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type your question here… e.g., 'What schemes am I eligible for?'"
            className="min-h-[120px] resize-none text-base"
            aria-label="Type your message"
            disabled={isLoading}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
          />
          <div className="flex justify-end gap-2">
            <Button
              onClick={handleSend}
              disabled={!message.trim() || isLoading}
              aria-label="Send message"
              className="gap-2"
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              {isLoading ? "Processing..." : "Send"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default InputConsole;
