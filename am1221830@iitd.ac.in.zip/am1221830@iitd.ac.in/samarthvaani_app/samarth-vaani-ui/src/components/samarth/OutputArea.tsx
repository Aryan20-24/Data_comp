import { useState, useEffect, useRef } from "react";
import { Volume2, FileText, Search, BookOpen, ChevronRight, Loader2, Download, CheckCircle, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useQuery } from "@/contexts/QueryContext";
import { generateApplication } from "@/api/client";
import { useToast } from "@/hooks/use-toast";

const OutputArea = () => {
  const {
    currentQuery,
    currentResponse,
    isLoading,
    error,
    audioUrl,
    outputLanguage,
  } = useQuery();
  
  const { toast } = useToast();
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const [showAppDialog, setShowAppDialog] = useState(false);
  const [selectedScheme, setSelectedScheme] = useState<string>("");
  const [isGeneratingApp, setIsGeneratingApp] = useState(false);
  const [generatedApplication, setGeneratedApplication] = useState<string | null>(null);
  
  // User details form
  const [userDetails, setUserDetails] = useState({
    name: "",
    address: "",
    disability_type: "",
    disability_percentage: "",
    contact_number: "",
    email: "",
    aadhar_number: "",
  });

  // Play audio when available
  useEffect(() => {
    if (audioUrl && audioRef.current) {
      audioRef.current.src = audioUrl;
      audioRef.current.play().catch((err) => {
        console.error("Failed to play audio:", err);
      });
    }
  }, [audioUrl]);

  // Handle application generation
  const handleGenerateApplication = async () => {
    if (!selectedScheme) {
      toast({
        title: "Scheme Required",
        description: "Please enter a scheme name to generate an application",
        variant: "destructive",
      });
      return;
    }

    setIsGeneratingApp(true);
    setGeneratedApplication(null);

    try {
      const response = await generateApplication({
        scheme_name: selectedScheme,
        user_details: userDetails,
        language: outputLanguage,
      });

      setGeneratedApplication(response.application_text);

      toast({
        title: "Application Generated",
        description: response.template_used
          ? `Used template: ${response.template_used}`
          : "Generated using LLM",
      });
    } catch (error) {
      console.error("Application generation failed:", error);
      const errorMessage = error instanceof Error ? error.message : "Failed to generate application";

      toast({
        title: "Generation Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsGeneratingApp(false);
    }
  };

  // Download application as text file
  const handleDownloadApplication = () => {
    if (!generatedApplication) return;

    const blob = new Blob([generatedApplication], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `application_${selectedScheme.replace(/\s+/g, "_")}_${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Downloaded",
      description: "Application saved to your device",
    });
  };

  // Play audio response
  const playAudio = () => {
    if (audioRef.current) {
      audioRef.current.play().catch((err) => {
        console.error("Failed to play audio:", err);
        toast({
          title: "Playback Error",
          description: "Could not play audio response",
          variant: "destructive",
        });
      });
    }
  };

  // Speak text using Web Speech API (fallback)
  const speakText = (text: string) => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = outputLanguage;
      window.speechSynthesis.speak(utterance);
    } else {
      toast({
        title: "Not Supported",
        description: "Text-to-speech is not supported in this browser",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Hidden audio element */}
      <audio ref={audioRef} className="hidden" />

      {/* Loading State */}
      {isLoading && (
        <Card className="border-primary/50 bg-primary/5">
          <CardContent className="flex items-center gap-4 py-6">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <div>
              <h3 className="font-semibold text-foreground">Processing Query...</h3>
              <p className="text-sm text-muted-foreground">
                Searching through disability rights and schemes database
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error State */}
      {error && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="flex items-center gap-4 py-6">
            <AlertCircle className="h-8 w-8 text-destructive" />
            <div className="flex-1">
              <h3 className="font-semibold text-foreground">Error</h3>
              <p className="text-sm text-muted-foreground">{error}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Query Response - Answer */}
      {currentResponse && currentResponse.answer && (
        <section aria-labelledby="answer-heading">
          <div className="mb-3 flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" />
            <h2 id="answer-heading" className="text-lg font-bold text-foreground">
              Answer
            </h2>
          </div>
          <Card className="border-border">
            <CardContent className="pt-5">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 space-y-2 text-sm text-foreground whitespace-pre-wrap">
                  {currentResponse.answer}
                </div>
                <div className="flex shrink-0 gap-2">
                  {audioUrl ? (
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={playAudio}
                      aria-label="Play audio response"
                    >
                      <Volume2 className="h-5 w-5" />
                    </Button>
                  ) : (
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => speakText(currentResponse.answer)}
                      aria-label="Read answer aloud"
                    >
                      <Volume2 className="h-5 w-5" />
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      )}

      {/* Query Response - Discovered Schemes */}
      {currentResponse && currentResponse.schemes && currentResponse.schemes.length > 0 && (
        <section aria-labelledby="scheme-heading">
          <div className="mb-3 flex items-center gap-2">
            <Search className="h-5 w-5 text-primary" />
            <h2 id="scheme-heading" className="text-lg font-bold text-foreground">
              Discovered Schemes ({currentResponse.schemes.length})
            </h2>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {currentResponse.schemes.map((scheme, index) => (
              <Card
                key={index}
                className="border-border hover:border-primary/40 transition-colors"
              >
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-base font-semibold leading-snug">
                      {scheme.scheme_name}
                    </CardTitle>
                    {scheme.confidence_score && (
                      <span className="shrink-0 rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
                        {Math.round(scheme.confidence_score * 100)}% match
                      </span>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="mb-3 text-sm text-muted-foreground">
                    {scheme.description}
                  </p>
                  {scheme.eligibility && (
                    <p className="mb-2 text-xs text-muted-foreground">
                      <strong>Eligibility:</strong> {scheme.eligibility}
                    </p>
                  )}
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1 text-xs"
                      onClick={() => speakText(scheme.description)}
                      aria-label={`Read aloud: ${scheme.scheme_name}`}
                    >
                      <Volume2 className="h-3.5 w-3.5" /> Read Aloud
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="gap-1 text-xs"
                      onClick={() => {
                        setSelectedScheme(scheme.scheme_name);
                        setShowAppDialog(true);
                      }}
                    >
                      Apply <ChevronRight className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Sources */}
      {currentResponse && currentResponse.sources && currentResponse.sources.length > 0 && (
        <section aria-labelledby="sources-heading">
          <div className="mb-3 flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" />
            <h2 id="sources-heading" className="text-lg font-bold text-foreground">
              Sources ({currentResponse.sources.length})
            </h2>
          </div>
          <div className="space-y-2">
            {currentResponse.sources.map((source, index) => (
              <Card key={index} className="border-border">
                <CardContent className="py-3">
                  <p className="text-sm text-foreground">{source.content}</p>
                  {source.metadata && (
                    <p className="mt-1 text-xs text-muted-foreground">
                      Score: {source.score?.toFixed(3)}
                      {source.metadata.source && ` • Source: ${source.metadata.source}`}
                    </p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Application Generator */}
      <section aria-labelledby="app-gen-heading">
        <div className="mb-3 flex items-center gap-2">
          <FileText className="h-5 w-5 text-primary" />
          <h2 id="app-gen-heading" className="text-lg font-bold text-foreground">
            Application Generator
          </h2>
        </div>

        <Dialog open={showAppDialog} onOpenChange={setShowAppDialog}>
          <DialogTrigger asChild>
            <Card className="border-dashed border-2 border-primary/30 bg-primary/5 hover:bg-primary/10 transition-colors cursor-pointer">
              <CardContent className="flex items-center gap-4 py-6">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                  <FileText className="h-7 w-7" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground">Generate Application</h3>
                  <p className="text-sm text-muted-foreground">
                    Create an official application for schemes, rights claims, or government requests.
                  </p>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </CardContent>
            </Card>
          </DialogTrigger>

          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Generate Application</DialogTitle>
              <DialogDescription>
                Fill in your details to generate an official application letter
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              {/* Scheme Name */}
              <div>
                <Label htmlFor="scheme-name">Scheme Name *</Label>
                <Input
                  id="scheme-name"
                  value={selectedScheme}
                  onChange={(e) => setSelectedScheme(e.target.value)}
                  placeholder="e.g., UDID Card, Disability Pension, Employment Scheme"
                />
              </div>

              {/* User Details */}
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={userDetails.name}
                    onChange={(e) =>
                      setUserDetails({ ...userDetails, name: e.target.value })
                    }
                    placeholder="Your full name"
                  />
                </div>
                <div>
                  <Label htmlFor="contact">Contact Number</Label>
                  <Input
                    id="contact"
                    value={userDetails.contact_number}
                    onChange={(e) =>
                      setUserDetails({ ...userDetails, contact_number: e.target.value })
                    }
                    placeholder="Your phone number"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="address">Address *</Label>
                <Textarea
                  id="address"
                  value={userDetails.address}
                  onChange={(e) =>
                    setUserDetails({ ...userDetails, address: e.target.value })
                  }
                  placeholder="Your complete address"
                  rows={2}
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="disability-type">Disability Type</Label>
                  <Input
                    id="disability-type"
                    value={userDetails.disability_type}
                    onChange={(e) =>
                      setUserDetails({ ...userDetails, disability_type: e.target.value })
                    }
                    placeholder="e.g., Visual, Physical"
                  />
                </div>
                <div>
                  <Label htmlFor="disability-percentage">Disability %</Label>
                  <Input
                    id="disability-percentage"
                    value={userDetails.disability_percentage}
                    onChange={(e) =>
                      setUserDetails({
                        ...userDetails,
                        disability_percentage: e.target.value,
                      })
                    }
                    placeholder="e.g., 40%"
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={userDetails.email}
                    onChange={(e) =>
                      setUserDetails({ ...userDetails, email: e.target.value })
                    }
                    placeholder="your.email@example.com"
                  />
                </div>
                <div>
                  <Label htmlFor="aadhar">Aadhar Number</Label>
                  <Input
                    id="aadhar"
                    value={userDetails.aadhar_number}
                    onChange={(e) =>
                      setUserDetails({ ...userDetails, aadhar_number: e.target.value })
                    }
                    placeholder="XXXX-XXXX-XXXX"
                  />
                </div>
              </div>

              {/* Generate Button */}
              <Button
                onClick={handleGenerateApplication}
                disabled={isGeneratingApp || !selectedScheme || !userDetails.name || !userDetails.address}
                className="w-full gap-2"
              >
                {isGeneratingApp ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <FileText className="h-4 w-4" />
                    Generate Application
                  </>
                )}
              </Button>

              {/* Generated Application */}
              {generatedApplication && (
                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      Generated Application
                    </Label>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleDownloadApplication}
                      className="gap-2"
                    >
                      <Download className="h-4 w-4" />
                      Download
                    </Button>
                  </div>
                  <Textarea
                    value={generatedApplication}
                    readOnly
                    rows={15}
                    className="font-mono text-sm"
                  />
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </section>
    </div>
  );
};

export default OutputArea;
