# Databricks notebook source
# DBTITLE 1,Complete RAG Pipeline
# MAGIC %md
# MAGIC # SamarthVaani - Complete RAG Pipeline
# MAGIC
# MAGIC **Goal**: End-to-end RAG system from query to answer
# MAGIC
# MAGIC ## RAG Architecture
# MAGIC ```
# MAGIC User Query (any language)
# MAGIC         ↓
# MAGIC Language Detection (lingua-py)
# MAGIC         ↓
# MAGIC Translation to English (IndicTrans2)
# MAGIC         ↓
# MAGIC Vector Search (retrieve top-k chunks)
# MAGIC         ↓
# MAGIC Build Prompt with Context
# MAGIC         ↓
# MAGIC LLM Generation (Param-1 or DBRX)
# MAGIC         ↓
# MAGIC Translation back to User Language
# MAGIC         ↓
# MAGIC Final Answer
# MAGIC ```
# MAGIC
# MAGIC ## What This Notebook Provides
# MAGIC 1. **Simple RAG**: English query → English answer (basic)
# MAGIC 2. **Full Pipeline**: Any language → RAG → Same language (production)
# MAGIC 3. **Evaluation**: Test multiple queries, measure quality
# MAGIC 4. **Demo**: Interactive testing interface

# COMMAND ----------

# DBTITLE 1,Install Required Libraries
# MAGIC %pip install databricks-vectorsearch openai --quiet
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Import Libraries and Setup
from databricks.vector_search.client import VectorSearchClient
import os

# Initialize Vector Search
vsc = VectorSearchClient(disable_notice=True)

# Configuration
ENDPOINT_NAME = "samarthvaani_vs_endpoint"
INDEX_NAME = "samarthvaani.gold.rpwd_chunks_index"

print("✅ Libraries imported and configured")

# COMMAND ----------

# DBTITLE 1,Intent Detection Function
# Intent Detection Configuration
ACTION_KEYWORDS = {
    'apply': ['apply', 'application', 'how to apply', 'application process', 'where to apply', 'applying for', 'apply for'],
    'write': ['write', 'draft', 'generate', 'fill', 'create', 'letter', 'application letter', 'write a letter'],
    'procedure': ['procedure', 'steps', 'process', 'how do i', 'what should i do', 'guide', 'how can i', 'show me how'],
    'help': ['help me', 'assist', 'show me', 'teach me', 'explain how', 'guide me', 'help in'],
    'get': ['how to get', 'how can i get', 'getting', 'obtain', 'avail']
}

def detect_intent(query_text):
    """
    Detect if query is informational or action-oriented.
    
    Args:
        query_text: User query string
    
    Returns:
        dict: {
            'type': 'info' | 'action',
            'categories': list of matched intent categories,
            'keywords_matched': list of matched keywords
        }
    """
    query_lower = query_text.lower()
    matched_keywords = []
    matched_categories = []
    
    # Check each category of action keywords
    for category, keywords in ACTION_KEYWORDS.items():
        for keyword in keywords:
            if keyword in query_lower:
                matched_keywords.append(keyword)
                if category not in matched_categories:
                    matched_categories.append(category)
    
    # Determine intent type
    if matched_keywords:
        return {
            'type': 'action',
            'categories': matched_categories,
            'keywords_matched': matched_keywords
        }
    else:
        return {
            'type': 'info',
            'categories': [],
            'keywords_matched': []
        }

print("✅ Intent detection function defined")
print(f"   Monitoring {sum(len(kws) for kws in ACTION_KEYWORDS.values())} action keywords across {len(ACTION_KEYWORDS)} categories")

# COMMAND ----------

# DBTITLE 1,RAG Retrieval Function
def retrieve_context(query_text, top_k=3, topic_filter=None, intent=None):
    """
    Retrieve relevant chunks from Vector Search.
    
    Args:
        query_text: User query in English
        top_k: Number of chunks to retrieve (default: 3)
        topic_filter: Optional topic filter (e.g., 'education', 'employment')
        intent: Intent detection result (optional, for adaptive retrieval)
    
    Returns:
        List of (chunk_text, metadata) tuples
    """
    try:
        # Adjust retrieval strategy based on intent
        actual_top_k = top_k
        if intent and intent.get('type') == 'action':
            # For action queries, retrieve more chunks to get comprehensive steps
            actual_top_k = min(top_k + 2, 10)
        
        # Build search parameters
        search_params = {
            "query_text": query_text,
            "columns": ["chunk_text", "section_title", "topic", "source"],
            "num_results": actual_top_k
        }
        
        # Add optional topic filter
        if topic_filter:
            search_params["filters"] = {"topic": topic_filter}
        
        # Perform search
        results = vsc.get_index(ENDPOINT_NAME, INDEX_NAME).similarity_search(**search_params)
        
        # Extract results
        retrieved_chunks = []
        for row in results.get('result', {}).get('data_array', []):
            chunk_text = row[0]
            metadata = {
                "section_title": row[1],
                "topic": row[2],
                "source": row[3]
            }
            retrieved_chunks.append((chunk_text, metadata))
        
        return retrieved_chunks
    
    except Exception as e:
        print(f"Error in retrieval: {e}")
        return []

print("✅ Retrieval function defined (with intent support)")

# COMMAND ----------

# DBTITLE 1,Build RAG Prompt Template
def build_rag_prompt(query, context_chunks, intent=None):
    """
    Build an adaptive prompt for the LLM based on query intent.
    
    Args:
        query: User query
        context_chunks: List of (chunk_text, metadata) tuples
        intent: Intent detection result (optional)
    
    Returns:
        Formatted prompt string
    """
    # Combine context
    context_text = "\n\n".join([
        f"[Source: {meta['source']} | Topic: {meta['topic']}]\n{text}"
        for text, meta in context_chunks
    ])
    
    # Determine if this is an action-oriented query
    is_action_query = intent and intent.get('type') == 'action'
    
    if is_action_query:
        # ACTION-ORIENTED PROMPT: Step-by-step guidance
        prompt = f"""You are SamarthVaani, an AI assistant helping Persons with Disabilities in India understand their rights and ACCESS government schemes.

The user needs ACTIONABLE HELP (not just information).

Context from RPWD Act 2016 and Government Documents:
{context_text}

Question: {query}

Provide a PRACTICAL, STEP-BY-STEP response with:

1. **What to Do**: Clear numbered steps (1, 2, 3...)
2. **Required Documents**: Bullet list of documents needed
3. **Where to Apply**: Office address, website, or contact information
4. **Eligibility**: Brief mention of who can apply
5. **Timeline**: Expected processing time (if mentioned in context)
6. **Important Notes**: Any deadlines, fees, or special requirements

Use simple language (8th grade level). Be encouraging and supportive.
If you need to write a letter/application, provide a template with [PLACEHOLDERS] for user details.

Answer:"""
    
    else:
        # INFORMATIONAL PROMPT: Factual answer
        prompt = f"""You are SamarthVaani, an AI assistant helping Persons with Disabilities in India understand their rights and access government schemes.

Context from RPWD Act 2016 and Government Documents:
{context_text}

Question: {query}

Instructions:
- Answer based ONLY on the provided context
- Be clear, compassionate, and use simple language (8th grade level)
- If the context doesn't contain the answer, say "I don't have enough information about this in the provided documents."
- Include specific scheme names, eligibility criteria, and application steps when relevant
- Use bullet points for clarity

Answer:"""
    
    return prompt

print("✅ Prompt builder function defined (with intent adaptation)")

# COMMAND ----------

# DBTITLE 1,LLM Generation Function (DBRX/DBRX-Instruct)
def generate_answer(prompt, max_tokens=500, temperature=0.1):
    """
    Generate answer using Databricks Foundation Model API.
    Using Meta Llama 3.3 70B Instruct (high-quality, instruction-tuned).
    
    Args:
        prompt: RAG prompt with context
        max_tokens: Maximum response length
        temperature: Creativity (0=focused, 1=creative)
    
    Returns:
        Generated answer string
    """
    try:
        from openai import OpenAI
        import os
        
        # Get Databricks token
        token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
        workspace_url = spark.conf.get("spark.databricks.workspaceUrl")
        
        # Initialize client
        client = OpenAI(
            api_key=token,
            base_url=f"https://{workspace_url}/serving-endpoints"
        )
        
        # Call Meta Llama 3.3 70B Instruct
        response = client.chat.completions.create(
            model="databricks-meta-llama-3-3-70b-instruct",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_tokens,
            temperature=temperature
        )
        
        return response.choices[0].message.content
    
    except Exception as e:
        print(f"Error in generation: {e}")
        return "I apologize, but I encountered an error generating the response."

print("✅ Generation function defined (using Meta Llama 3.3 70B Instruct)")

# COMMAND ----------

# DBTITLE 1,Complete RAG Pipeline Function
def rag_pipeline(query, top_k=3, topic_filter=None, verbose=True, intent=None):
    """
    Complete intent-aware RAG pipeline: query → retrieve → generate → answer.
    
    Args:
        query: User question (English)
        top_k: Number of chunks to retrieve
        topic_filter: Optional topic filter
        verbose: Print intermediate steps
        intent: Intent detection result (for adaptive behavior)
    
    Returns:
        dict with answer, context, intent, and metadata
    """
    if verbose:
        print(f"🔍 Query: {query}\n")
        if intent and intent.get('type') == 'action':
            print(f"🎯 Intent: ACTION-ORIENTED ({', '.join(intent.get('categories', []))})")
            print(f"   Providing step-by-step guidance\n")
    
    # Step 1: Retrieve context (intent-aware)
    if verbose:
        print("📚 Retrieving relevant chunks...")
    
    context_chunks = retrieve_context(
        query, 
        top_k=top_k, 
        topic_filter=topic_filter,
        intent=intent
    )
    
    if not context_chunks:
        return {
            "answer": "I couldn't find relevant information in the documents.",
            "context": [],
            "sources": [],
            "intent": intent
        }
    
    if verbose:
        print(f"   Retrieved {len(context_chunks)} chunks\n")
    
    # Step 2: Build adaptive prompt
    if verbose:
        print("📝 Building prompt...")
        if intent and intent.get('type') == 'action':
            print("   Using ACTION-ORIENTED template\n")
    
    prompt = build_rag_prompt(query, context_chunks, intent=intent)
    
    # Step 3: Generate answer
    if verbose:
        print("🤖 Generating answer...\n")
    
    answer = generate_answer(prompt)
    
    # Extract sources
    sources = list(set([meta['source'] for _, meta in context_chunks]))
    
    return {
        "answer": answer,
        "context": [text for text, _ in context_chunks],
        "sources": sources,
        "metadata": [meta for _, meta in context_chunks],
        "intent": intent
    }

print("✅ Complete RAG pipeline function defined (intent-aware)")

# COMMAND ----------

# DBTITLE 1,Test RAG Pipeline - Example 1
# Test query 1: Education rights
query1 = "What are the education rights for children with disabilities under RPWD Act?"

print("=" * 80)
print("TEST 1: Education Rights Query")
print("=" * 80)

result1 = rag_pipeline(query1, top_k=3)

print("\n💬 ANSWER:")
print(result1['answer'])

print("\n📚 SOURCES:")
for source in result1['sources']:
    print(f"  - {source}")

print("\n" + "=" * 80)

# COMMAND ----------

# DBTITLE 1,Test RAG Pipeline - Example 2
# Test query 2: Employment schemes
query2 = "What employment schemes are available for persons with disabilities?"

print("=" * 80)
print("TEST 2: Employment Schemes Query")
print("=" * 80)

result2 = rag_pipeline(query2, top_k=3, topic_filter="employment")

print("\n💬 ANSWER:")
print(result2['answer'])

print("\n📚 SOURCES:")
for source in result2['sources']:
    print(f"  - {source}")

print("\n" + "=" * 80)

# COMMAND ----------

# DBTITLE 1,Test Intent-Aware RAG - Action Query
# Test query 3: Action-oriented query (How to apply)
query3 = "How do I apply for a wheelchair under ADIP scheme?"

print("=" * 80)
print("TEST 3: Action-Oriented Query (Intent Detection)")
print("=" * 80)

# Detect intent
intent3 = detect_intent(query3)
print(f"\n🔍 Detected Intent: {intent3['type'].upper()}")
if intent3['categories']:
    print(f"   Categories: {', '.join(intent3['categories'])}")
    print(f"   Keywords: {', '.join(intent3['keywords_matched'])}")

# Run RAG with intent
result3 = rag_pipeline(query3, top_k=3, intent=intent3)

print("\n💬 ANSWER:")
print(result3['answer'])

print("\n📚 SOURCES:")
for source in result3['sources']:
    print(f"  - {source}")

print("\n" + "=" * 80)
print("✅ Notice how the answer provides step-by-step guidance!")
print("=" * 80)

# COMMAND ----------

# DBTITLE 1,Intent Detection Demo (All Query Types)
# Intent Detection Demonstration (No Vector Search Required)
print("=" * 80)
print("INTENT DETECTION DEMONSTRATION")
print("=" * 80)

# Test various query types
test_queries = [
    # Informational queries (should detect as INFO)
    "What is RPWD Act 2016?",
    "What are the 21 types of disabilities?",
    "What is ADIP scheme?",
    "Tell me about disability certificate",
    
    # Action-oriented queries (should detect as ACTION)
    "How do I apply for ADIP scheme?",
    "Help me apply for disability certificate",
    "What is the procedure to get a wheelchair?",
    "Write an application for pension",
    "Show me how to obtain UDID card",
    "What documents are required for scholarship?",
]

print("\n🔍 Testing Intent Detection on Various Queries:\n")

for query in test_queries:
    intent = detect_intent(query)
    
    # Color code the output
    if intent['type'] == 'action':
        print(f"✅ ACTION | {query}")
        print(f"           Categories: {', '.join(intent['categories'])}")
        print(f"           Keywords: {', '.join(intent['keywords_matched'][:3])}...")
    else:
        print(f"ℹ️  INFO   | {query}")
    print()

print("=" * 80)
print("📊 SUMMARY")
print("=" * 80)

info_count = sum(1 for q in test_queries if detect_intent(q)['type'] == 'info')
action_count = sum(1 for q in test_queries if detect_intent(q)['type'] == 'action')

print(f"\nTotal queries tested: {len(test_queries)}")
print(f"  • INFO queries: {info_count}")
print(f"  • ACTION queries: {action_count}")

print("\n🎯 How the System Adapts:")
print("\nINFO queries get:")
print("  → Factual, informational answers")
print("  → Standard 3 chunks retrieved")
print("  → Focuses on 'what', 'why', definitions")

print("\nACTION queries get:")
print("  → Step-by-step guidance")
print("  → 5 chunks retrieved (more context)")
print("  → Numbered steps, documents list, where to apply")
print("  → Application templates when needed")

print("\n" + "=" * 80)

# COMMAND ----------

# DBTITLE 1,Interactive RAG Demo
# Interactive testing
print("🚀 Interactive RAG Demo")
print("=" * 80)
print("Ask questions about disability rights and schemes!")
print("Type 'quit' to exit\n")

# Example questions for testing
example_questions = [
    "What is the RPWD Act 2016?",
    "What are the 21 types of disabilities recognized?",
    "How do I apply for a disability certificate?",
    "What reservation is provided in government jobs?",
    "What schemes help with assistive devices?"
]

print("💡 Example questions:")
for i, q in enumerate(example_questions, 1):
    print(f"  {i}. {q}")

print("\n" + "=" * 80)

# For demonstration, test one example
test_query = example_questions[0]
print(f"\n🔍 Testing: {test_query}\n")

result = rag_pipeline(test_query, top_k=3, verbose=False)

print("💬 Answer:")
print(result['answer'])
print(f"\n📚 Sources: {', '.join(result['sources'])}")

# COMMAND ----------

# DBTITLE 1,Evaluation Function
def evaluate_rag(test_queries):
    """
    Evaluate RAG pipeline on multiple test queries.
    
    Args:
        test_queries: List of test question strings
    
    Returns:
        Evaluation results
    """
    results = []
    
    for i, query in enumerate(test_queries, 1):
        print(f"\nTest {i}/{len(test_queries)}: {query[:60]}...")
        
        result = rag_pipeline(query, top_k=3, verbose=False)
        
        # Simple quality checks
        has_answer = len(result['answer']) > 50
        has_context = len(result['context']) > 0
        has_sources = len(result['sources']) > 0
        
        results.append({
            "query": query,
            "has_answer": has_answer,
            "has_context": has_context,
            "has_sources": has_sources,
            "answer_length": len(result['answer']),
            "num_sources": len(result['sources'])
        })
        
        print(f"   ✓ Answer: {len(result['answer'])} chars")
        print(f"   ✓ Sources: {len(result['sources'])}")
    
    return results

# Example evaluation
test_set = [
    "What is the RPWD Act 2016?",
    "What are education rights for disabled children?",
    "What employment benefits are available?",
    "How to get a disability certificate?",
    "What is UDID card?"
]

print("\n" + "=" * 80)
print("EVALUATION RUN")
print("=" * 80)

eval_results = evaluate_rag(test_set)

# Summary
print("\n" + "=" * 80)
print("EVALUATION SUMMARY")
print("=" * 80)
print(f"Total queries: {len(eval_results)}")
print(f"Successful: {sum(1 for r in eval_results if r['has_answer'])}")
print(f"Avg answer length: {sum(r['answer_length'] for r in eval_results) / len(eval_results):.0f} chars")
print(f"Avg sources per query: {sum(r['num_sources'] for r in eval_results) / len(eval_results):.1f}")

# COMMAND ----------

# DBTITLE 1,Summary and Next Steps
print("=" * 80)
print("✅ RAG PIPELINE COMPLETE")
print("=" * 80)

print("\n🎯 What You Have Now:")
print("   ✓ Vector Search with semantic retrieval")
print("   ✓ Hybrid search (semantic + keyword)")
print("   ✓ Topic-based filtering")
print("   ✓ DBRX-Instruct for generation")
print("   ✓ Complete RAG pipeline function")
print("   ✓ Evaluation framework")

print("\n🚀 Next Steps for SamarthVaani:")
print("   1. Add language detection (lingua-py)")
print("   2. Add translation layer (IndicTrans2)")
print("   3. Replace DBRX with Param-1 for Indic languages")
print("   4. Build Gradio UI with accessibility features")
print("   5. Deploy as Databricks App")

print("\n📚 How to Use This Pipeline:")
print("""   
   # Simple usage
   result = rag_pipeline("Your question here", top_k=3)
   print(result['answer'])
   
   # With topic filter
   result = rag_pipeline("employment question", topic_filter="employment")
   
   # Access metadata
   print(result['sources'])  # Source documents
   print(result['metadata'])  # Full metadata
""")

print("\n" + "=" * 80)
print("✅ RAG SYSTEM READY FOR PRODUCTION")
print("=" * 80)