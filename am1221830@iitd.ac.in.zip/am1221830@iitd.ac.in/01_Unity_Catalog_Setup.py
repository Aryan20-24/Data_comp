# Databricks notebook source
# DBTITLE 1,SamarthVaani - Unity Catalog Setup
# MAGIC %md
# MAGIC # SamarthVaani - Unity Catalog & Data Architecture Setup
# MAGIC
# MAGIC **Goal**: Create the foundational data architecture for the RAG pipeline
# MAGIC
# MAGIC ## Architecture Overview
# MAGIC ```
# MAGIC samarthvaani (catalog)
# MAGIC ├── bronze  → Raw PDF extracts, unprocessed text
# MAGIC ├── silver  → Cleaned, chunked documents with metadata
# MAGIC └── gold    → AI-ready data (Vector Search, Genie Space)
# MAGIC ```
# MAGIC
# MAGIC ## What We'll Create
# MAGIC 1. Unity Catalog with 3 schemas (bronze/silver/gold)
# MAGIC 2. UC Volume for PDF storage
# MAGIC 3. Bronze table for raw documents
# MAGIC 4. Silver table for chunks
# MAGIC 5. Gold table with CDF for Vector Search Delta Sync

# COMMAND ----------

# DBTITLE 1,Create Unity Catalog and Schemas
# MAGIC %sql
# MAGIC -- Create main catalog for SamarthVaani
# MAGIC CREATE CATALOG IF NOT EXISTS samarthvaani
# MAGIC COMMENT 'SamarthVaani AI Assistant for Persons with Disabilities';
# MAGIC
# MAGIC -- Switch to the catalog
# MAGIC USE CATALOG samarthvaani;
# MAGIC
# MAGIC -- Create Bronze Schema (Raw Data)
# MAGIC CREATE SCHEMA IF NOT EXISTS bronze
# MAGIC COMMENT 'Raw data layer - PDF extracts, unprocessed documents';
# MAGIC
# MAGIC -- Create Silver Schema (Cleaned & Structured)
# MAGIC CREATE SCHEMA IF NOT EXISTS silver
# MAGIC COMMENT 'Cleaned and chunked documents with metadata';
# MAGIC
# MAGIC -- Create Gold Schema (AI-Ready with CDF)
# MAGIC CREATE SCHEMA IF NOT EXISTS gold
# MAGIC COMMENT 'AI-ready data for Vector Search and Genie Space';
# MAGIC
# MAGIC -- Verify schemas
# MAGIC SHOW SCHEMAS IN samarthvaani;

# COMMAND ----------

# DBTITLE 1,Create UC Volume for PDF Storage
# MAGIC %sql
# MAGIC -- Create volume to store PDFs (modern approach instead of DBFS)
# MAGIC CREATE VOLUME IF NOT EXISTS samarthvaani.bronze.pdf_storage
# MAGIC COMMENT 'Storage for policy documents and scheme PDFs';
# MAGIC
# MAGIC -- Show volumes
# MAGIC SHOW VOLUMES IN samarthvaani.bronze;
# MAGIC
# MAGIC -- Display the volume path
# MAGIC SELECT 'Upload your PDFs to: /Volumes/samarthvaani/bronze/pdf_storage/' as upload_path;

# COMMAND ----------

# DBTITLE 1,Create Bronze Table for Raw Documents
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, IntegerType

# Define schema for raw documents
raw_docs_schema = StructType([
    StructField("doc_id", StringType(), False),
    StructField("filename", StringType(), False),
    StructField("doc_type", StringType(), True),  # 'rpwd_act', 'scheme', 'circular'
    StructField("raw_text", StringType(), True),
    StructField("page_count", IntegerType(), True),
    StructField("source_path", StringType(), True),
    StructField("ingestion_timestamp", TimestampType(), True)
])

# Create empty DataFrame and save as Delta table
raw_docs_df = spark.createDataFrame([], raw_docs_schema)

raw_docs_df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("samarthvaani.bronze.raw_documents")

print("✅ Created bronze.raw_documents table")
spark.sql("DESCRIBE TABLE samarthvaani.bronze.raw_documents").show(truncate=False)

# COMMAND ----------

# DBTITLE 1,Create Silver Table for Document Chunks
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, ArrayType

# Define schema for document chunks
chunks_schema = StructType([
    StructField("chunk_id", StringType(), False),
    StructField("doc_id", StringType(), False),
    StructField("chunk_index", IntegerType(), False),
    StructField("chunk_text", StringType(), False),
    StructField("word_count", IntegerType(), True),
    StructField("section_title", StringType(), True),
    StructField("topic", StringType(), True),  # 'education', 'employment', 'reservation', etc.
    StructField("source_doc", StringType(), True),
    StructField("metadata", StringType(), True)  # JSON string for additional metadata
])

# Create empty DataFrame and save as Delta table
chunks_df = spark.createDataFrame([], chunks_schema)

chunks_df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("samarthvaani.silver.document_chunks")

print("✅ Created silver.document_chunks table")
spark.sql("DESCRIBE TABLE samarthvaani.silver.document_chunks").show(truncate=False)

# COMMAND ----------

# DBTITLE 1,Create Gold Table with CDF (for Vector Search)
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# Define schema for enriched chunks (AI-ready)
enriched_schema = StructType([
    StructField("chunk_id", StringType(), False),  # Primary key for Vector Search
    StructField("chunk_text", StringType(), False),  # Text to embed
    StructField("section_title", StringType(), True),
    StructField("topic", StringType(), True),
    StructField("source", StringType(), True),
    StructField("doc_type", StringType(), True),
    StructField("word_count", IntegerType(), True)
])

# Create empty DataFrame
enriched_df = spark.createDataFrame([], enriched_schema)

# Save with Change Data Feed enabled (required for Vector Search Delta Sync)
enriched_df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .option("delta.enableChangeDataFeed", "true") \
    .saveAsTable("samarthvaani.gold.rpwd_chunks_enriched")

print("✅ Created gold.rpwd_chunks_enriched with CDF enabled")

# Verify CDF is enabled
spark.sql("SHOW TBLPROPERTIES samarthvaani.gold.rpwd_chunks_enriched").filter(
    "key = 'delta.enableChangeDataFeed'"
).show()

# COMMAND ----------

# DBTITLE 1,Summary and Next Steps
# Display summary of created assets
print("=" * 80)
print("✅ UNITY CATALOG SETUP COMPLETE")
print("=" * 80)
print("\n📦 Catalog: samarthvaani")
print("\n📂 Schemas:")
print("   - bronze (raw data)")
print("   - silver (cleaned data)")
print("   - gold (AI-ready data)")
print("\n📊 Tables Created:")
print("   - bronze.raw_documents")
print("   - silver.document_chunks")
print("   - gold.rpwd_chunks_enriched (CDF enabled for Vector Search)")
print("\n💾 Volume for PDF Storage:")
print("   - /Volumes/samarthvaani/bronze/pdf_storage/")
print("\n" + "=" * 80)
print("\n🚀 NEXT STEPS:")
print("   1. Upload your PDFs to /Volumes/samarthvaani/bronze/pdf_storage/")
print("   2. Run Notebook 02: PDF Ingestion & Text Extraction")
print("   3. Run Notebook 03: Intelligent Chunking")
print("   4. Run Notebook 04: Vector Search Setup")
print("   5. Run Notebook 05: RAG Query Pipeline")
print("=" * 80)

# Show all tables in the catalog
print("\n📋 All Tables in Catalog:")
spark.sql("SHOW TABLES IN samarthvaani.bronze").show(truncate=False)
spark.sql("SHOW TABLES IN samarthvaani.silver").show(truncate=False)
spark.sql("SHOW TABLES IN samarthvaani.gold").show(truncate=False)